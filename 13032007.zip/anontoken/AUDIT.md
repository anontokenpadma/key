# AnonToken — SPARK Proof & Build Audit Evidence

This document is the single source of evidence for the formal-verification
review of the AnonToken key-management server. Every claim below is
reproducible with the exact commands listed, from a clean checkout, on the
toolchain versions stated.

---

## 1. Toolchain (all latest stable versions)

| Component | Version | Evidence / source |
|---|---|---|
| Alire (alr) | **2.1.1** | https://github.com/alire-project/alire/releases/latest (released 2026-05-29) |
| GNAT (gnat_native) | **16.1.0** | `alr index --update-all` + `alr search gnat_native` → newest stable in the official community index; matches AdaCore's latest stable FSF release (16.1.1 exists only as a *daily snapshot* marked "NOT A STABLE RELEASE") |
| gprbuild | **26.0.1** | same index |
| GNATprove | **16.1.0** | `alr search gnatprove` → newest; ships Why3 1.8.2, Alt-Ergo 2.6.1, and bundles Z3 + CVC5 |
| SMT provers | Z3, CVC5, Alt-Ergo (all as shipped with GNATprove 16.1.0) | `gnatprove --provers` lists all three |

Toolchain qualification: GNAT, gprbuild and GNATprove are the **official
AdaCore releases** distributed through the community Alire index, built from
the FSF GCC 16.1 release branch; the project pins exactly
`gnat_native_16.1.0_9f74f58a` so every proof result is byte-for-byte
reproducible.

## 2. Proof configuration (exactly as run)

```bash
gnatprove -P anontoken.gpr --level=4 -j23 --report=all \
  --prover=z3,cvc5,altergo --timeout=120 --steps=400000 --no-inlining \
  -f -u <unit>
```

- `-f` forces a fresh analysis (no cached results), after `rm -rf obj/gnatprove`.
- `--no-inlining` disables inlining so proofs are stable and not
  solver-order dependent.
- Three SMT solvers are used; every check is discharged (see §4).
- No `--proof=...`, `--no-checks`, `--warnings=off`, or any
  proof-weakening switch is used anywhere.

The full unit list (11 SPARK units + the vendored SPARKNaCl library they
depend on) is in `run_proof_final.sh` / `run_proof_local.sh`.

## 3. Language & build configuration

- **100 % Ada/SPARK except one documented C boundary (see §6).** No
  assembly, no other languages.
- Every package and package body under `src/` and `libs/sparknacl/src/`
  is `SPARK_Mode => On`; there is **no** `SPARK_Mode => Off`,
  `=> None`, or excluded unit anywhere in the closure (verified by
  `grep -rn "SPARK_Mode *=> *Off\|None" src libs`).
- The two composition roots, `main.adb` and `admin.adb`, are thin
  wrappers: argument parsing, the mandatory heap allocation of the
  13 MB keystore (heap is required because a stack object of that size
  overflows the default 8 MB stack — documented in `anontoken.txt`), and
  the single call into the proven `Kms_Server.Run`. They contain no
  security logic; every security decision lives in the 11 proven units.
- Build flags: `-O2 -gnat2022 -gnatwa -gnatf` (Ada 2022, **all**
  warnings enabled — not suppressed) and `-O2` for the C shim.
- Build variants `anontoken.gpr` (host), `cross_a64.gpr` (AArch64)
  share the same sources and the same compiler switch set. The former
  Windows target (`cross-mingw.gpr`) and its `_WIN32` shim branch were
  removed.
- **Compiler warnings: 0** for all six binaries (main, admin, t_vectors,
  t_roundtrip, t_open, t_dispatch) under `-gnatwa`:
  `grep -ic warning` on a full rebuild → 0.
- **GNATprove warnings: 0** (flow-analysis and proof warnings; verified
  with `grep -E "^ warning:"` on the full proof log → 0).

### v0.4.0 — the three functional changes proven in this revision

1. **Strict JSON request-body validation (security-review Finding 5
   fixed).** `Kms_Json.Validate_Flat_Object` now enforces a flat, well-
   formed JSON object on every body-carrying endpoint: only one top-level
   object, no nested objects/arrays, no duplicate keys, no trailing
   junk after the closing `}`; string/number fields must be well-formed
   (no `5x` numbers, no `"3600"` string where an integer is required),
   and whitespace around `:`/`,` is tolerated. A malformed body now gets
   `400 bad_request` instead of silently parsing a prefix. `Field_Present`
   distinguishes *field absent* from *field present with a wrong type*
   (the root cause of the old silent-default-TTL behaviour).
2. **Per-account key limit (business feature).** `User_Record.Key_Limit`
   (users file format v2; v1 still loads, saving always writes v2) is set
   with `admin limit <user> <max-keys>` (0 = unlimited, range 0..65536).
   `Kms_Keystore.Count_Owned` counts every key still occupying a slot for
   that owner (whatever its state), and key creation returns
   `403 key_limit_reached` once the account holds `Key_Limit` keys.
   Lowering a limit never deletes keys automatically — that is an
   operator decision (documented in ADMIN.md).  The companion admin
   command `admin count <user> [<keystore-file>]` reports how many keys
   an account currently owns (same proven `Count_Owned` over a
   `Kms_File.Load`ed keystore; missing/corrupt keystore = 0, matching
   the server's convention), so the operator can verify a customer
   actually dropped below a lowered ceiling before enforcing it.
3. **TTL ceiling raised to 30 years (was hard 1 year).** Per-key
   `lifetime_minutes`/`lifetime_seconds` are now bounded by
   `Max_Ttl_Seconds = 30*365*86_400` instead of 1 year, so a single key
   can cover any commercial license up to 30 years; the lazy-activation
   purge loop still guarantees every slot is eventually freed, which is
   why an *unbounded* ceiling was rejected (unbounded TTL would let a
   client pin keystore slots forever = logical DoS; 30 years keeps every
   slot self-cleaning).

All three live in the 11 proven units and are covered by the same
level-4 proof (§4) and the functional test suite.

## 4. Proof results (level 4, from clean cache)

| Unit | Checks proved (v0.4.0) | Result |
|---|---|---|
| kms_os | 73 | all checks proved |
| kms_file | 322 | all checks proved |
| kms_server | 84 | all checks proved |
| kms_base64 | 159 | all checks proved |
| kms_hex | 41 | all checks proved |
| kms_json | 364 | all checks proved |
| kms_keystore | 91 | all checks proved |
| kms_signer | 91 | all checks proved |
| kms_users | 60 | all checks proved |
| kms_passwd | 12 | all checks proved |
| kms_http | 542 | all checks proved |

**Current clean level-4 run (v0.4.0, this revision): 11/11 units
"Success: all checks proved", 1,839 checks proved across the closure,
0 unproved, 0 checks with status "check"/"skipped"/"unknown", 0 medium,
0 high, 0 "might not be set", 0 GNATprove warnings, 0 compiler warnings
on all six binaries under `-gnatwa`.** The proof was run **twice from a
clean cache** (reproducibility requirement) with identical results —
both runs: 11/11 success, 1,839 checks, 0 unproved/medium/high/skipped,
0 warnings (logs `/tmp/proof_RUN2_v040.log` and
`/tmp/proof_RUN3_v040.log`; the two runs are byte-identical in every
"Success: all checks proved (N checks)" line). The per-unit counts above
are the deltas of the cumulative session totals reported by each `-u`
run; the final cumulative total equals their sum, 1,839. Every
precondition is discharged at every call site; termination of the
(blocking) OS primitives is declared via `Always_Terminates` on the
imported procedures and every bounded loop is proven (level 4
termination analysis).

> **On the check-count methodology (important for cross-revision
> comparison).** The "9,122 checks" figure printed by an earlier revision
> of this file was an *arithmetic error*: gnatprove reports a **running
> cumulative** count per `-u` unit when the units share one session dir
> (`Success: all checks proved (N checks)` where N grows as 73, 395, 479,
> …), and the earlier table summed those per-line cumulative values —
> double-counting every earlier unit. Verified by re-running the previous
> code (clean cache, same flags): its cumulative sequence was
> [73, 382, 466, 625, 666, 904, 982, 1073, 1133, 1145, 1673]; sorting
> those values reproduces the old table exactly, and summing them gives
> the old erroneous 9,122, while the **true total is the last value:
> 1,673 checks**. The correct, consistent way to count is the **final
> cumulative total** (each check counted once): previous code 1,673 →
> this v0.4.0 revision 1,839 (+166 checks, from the added strict-JSON
> validator, `Count_Owned` and the key-limit path). Both revisions were
> measured here with the identical command, from a clean cache, twice.

## 5. No proof bypass mechanisms — verified by grep

The following are **absent** from the entire closure (`src/` +
`libs/sparknacl/`), and their absence is re-verified before each proof
run:

- `pragma Assume` — 0 occurrences.
- `Unchecked_Conversion` / `Unchecked_Deallocation` / `Unchecked_Access`
  — 0 occurrences.
- `SPARK_Mode => Off/None` — 0 occurrences.
- `pragma Warnings (Off/On, ...)` — 0 occurrences (all 30 in the
  vendored SPARKNaCl and all in `src/` were removed; nothing is hidden or
  silenced; GNATprove 16.1 emits no warning that would need it).
- `pragma Suppress`, `pragma Annotate`, `--no-checks`, `--proof=...`,
  `--warnings=off`, `-gnatp` — 0 occurrences.
- `Loop_Variant`, `Loop_Invariant`, `Assert_And_Cut` and `Assert` are
  used extensively in SPARKNaCl and the project: these are **verified
  assertions** — GNATprove must prove each of them; they are the opposite
  of assumptions.

In addition, this revision **strengthened** the evidence: every
`sanitize`/zeroing procedure in the vendored SPARKNaCl and in
`kms_signer` now carries an explicit `Post => (… = 0)` contract and every
call site asserts the zeroed result (`pragma Assert`). The old upstream
pattern `Sanitize (X); pragma Unreferenced (X);` (which silenced the
"statement has no effect" flow warning) was replaced by a *verified*
property: the wipe is now proven to zero the buffer. The 65 upstream
`pragma Loop_Optimize (No_Unroll)` hints (which GNATprove 16.1 reports
as ignored) were removed — they are pure optimization hints with no
semantic effect. The two record types that needed public zero-proofs
(`SPARKNaCl.Core.ChaCha20_Context`, `SPARKNaCl.Cryptobox.Secret_Key`)
had their `F` field moved from the private part to the full view so the
`Post` contract can be written and proved.

## 6. The single documented exception: the C shim (`src/kms_os_shim.c`)

Per the review group's decision, the only non-Ada code is the small OS
boundary shim. This is the **only** exception; everything else is Ada/SPARK.

- **Scope:** ~120 lines of C mapping libc/POSIX syscalls
  (time, getrandom, open/close/read/write/rename/unlink/access,
  socket/setsockopt/bind/listen/accept/recv/send) to SPARK-friendly
  contracts. Each call carries an explicit `Import, Convention => C`
  declaration in `src/kms_os.ads` with a full `Global`, `Depends`,
  `Post`, and (for procedures) `Always_Terminates` contract, so GNATprove
  treats the boundary as fully specified.
- **Why it exists:** syscalls cannot be expressed in portable SPARK;
  the shim is the standard AdaCore pattern (same shape as SPARKNaCl's own
  platform layer) and keeps every Ada unit `SPARK_Mode => On`.
- **Review evidence:** the shim is short, single-purpose, side-effect
  visible only through the declared contracts, and is the subject of the
  runtime smoke/roundtrip tests. It is compiled with `-O2` and no
  warnings.

## 7. Hardware / environment assumptions (listed & controlled)

1. **POSIX OS** (Linux host and AArch64 Pi target) with the syscalls
   used by the shim; the Windows target was removed.
2. **System RNG available and trusted**: `getrandom` must deliver
   cryptographic entropy; on failure the server **fails closed**
   (`Random_Bytes` OK=False ⇒ key generation refused — proven).
3. **Time source monotone in the expected direction**: the server uses
   wall-clock seconds for key expiry; clock rollback can extend key
   lifetimes (documented operational assumption, not a proof gap).
4. **Single-threaded event loop**: one accept loop, no concurrency
   (documented F1 accepted risk in `anontoken.txt`).
5. **Keystore/users files owned by the server account**, file mode 0600
   (the shim opens with `O_CREAT|O_TRUNC|0600`).
6. **Stack vs heap**: the 13 MB keystore is heap-allocated in `main.adb`
   by design; SPARK units never declare it on the stack.
7. **Bind address/port are configuration inputs** validated by
   `Build_Sockaddr` (proven: only dotted-quad IPv4 accepted).

## 8. Reproduction commands (from a clean tree)

```bash
# 1. Compile every binary; expect: 0 warnings, 0 errors
gprbuild -P anontoken.gpr -XKMS_MAIN=main.adb -j24 -s -f
gprbuild -P anontoken.gpr -XKMS_MAIN=admin.adb -j24 -s -f
# ... same for tests/t_vectors.adb, t_roundtrip.adb, t_open.adb, t_dispatch.adb

# 2. Proof (clean, level 4, 3 provers) — see run_proof_local.sh
#    (wipes obj/gnatprove, then -f -u over the 11 Kms_* units)
bash run_proof_local.sh   # logs to /tmp/proof_local.log

# 3. Evidence greps
grep -E "Success: all checks proved|not proved|medium:|high:|might not be set" /tmp/proof_local.log
grep -E "^ warning:" /tmp/proof_local.log            # expect nothing
grep -rn "pragma Assume\|Unchecked_Conversion\|SPARK_Mode *=> *Off" src libs/sparknacl/src
grep -rn "pragma Warnings" src libs/sparknacl/src   # expect nothing

# 4. AArch64 cross build (Raspberry Pi) — fully static, 0 warnings, 0 errors
#    (GNAT 16.2.0 Debian-sid cross toolchain; cfg from gprconfig;
#    -largs -static -L<sysroot>/aarch64-linux-gnu/lib for static link)
gprbuild --config=<ca.cgpr> -P cross_a64.gpr -XKMS_MAIN=main.adb -p -j24 -largs -static -L<sysroot>/aarch64-linux-gnu/lib
gprbuild --config=<ca.cgpr> -P cross_a64.gpr -XKMS_MAIN=admin.adb -p -j24 -largs -static -L<sysroot>/aarch64-linux-gnu/lib
# binary: cross-a64/bin/main + admin → deployed to cross/linux-aarch64/
# verify: readelf -h → AArch64; readelf -l → no INTERP (fully static)

# 5. Functional test suites (all PASS)
bash tests/test_auth.sh tests/test_licensing.sh ...  # see tests/
```

## 9. Toolchain (all latest)

- **Host GNAT/SPARK**: GNAT 16.1.0 + gprbuild 26.2 + gnatprove 16.1.0
  (via Alire, `gnat_native_16.1.0`).
- **AArch64 cross**: GNAT/GCC **16.2.0** + binutils **2.47** +
  glibc 2.43 + linux-libc-dev 7.x, taken from Debian sid packages
  (`gnat-16-aarch64-linux-gnu`, `gcc-16-aarch64-linux-gnu`, ...) and
  relocated under `/tmp/a64/tc`; a small `gcc` wrapper injects
  `-I/-L/-Wl,-rpath-link` because the relocated sysroot cannot use
  absolute paths (documented in `anontoken.txt`).
- **Provers**: z3, cvc5, alt-ergo (all three used at level 4;
  `--prover=z3,cvc5,altergo`).
- All toolchain/prover versions are the newest stable available from
  their official sources (Alire index / gcc.gnu.org releases / Debian sid).

---

*Last updated: v0.4.0 — clean level-4 proof run of this revision — run **twice**
from a clean cache (reproducibility), both 11/11 units "Success: all
checks proved", 1,839 checks, 0 unproved / medium / high / warnings /
skipped; 0 `pragma Assume`, 0 `Unchecked_Conversion`, 0
`SPARK_Mode => Off`, 0 `pragma Warnings` anywhere in `src/` +
`libs/sparknacl/` (+ cross copies); 6 host binaries + 2 AArch64 cross
binaries compile with 0 warnings under `-gnatwa`; full functional test
suites all pass (incl. strict-body, TTL 30 years, `admin limit`);
Windows target removed (shim is POSIX-only). Logs:
`/tmp/proof_RUN2_v040.log` + `/tmp/proof_RUN3_v040.log` (11 `rc=0`
units each, `ALL_DONE`, identical results).*