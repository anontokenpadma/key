# AnonToken — deploy (Raspberry Pi / aarch64)

The server is written entirely in Ada/SPARK and proven with `gnatprove
--level=4` (no unproved checks in the `Kms_*` units).  It speaks plain
HTTP/1.1 + JSON on a TCP port and is meant to sit **behind** your
Cloudflare Tunnel, bound to `127.0.0.1:9999` so nothing is exposed
directly.

Every API endpoint except `GET /health` requires **HTTP Basic
authentication** against the owner-managed account list (stored in
the users file, `/var/lib/anontoken/users.bin`).  Accounts are created
with the companion `admin` tool - nobody can use the service without
an account.

## One-command install

```bash
sudo bash deploy/install.sh
```

The script:

1. installs `gnat` + `gprbuild` (native aarch64 toolchain) if missing;
2. builds both binaries from source (`-O2`, `-gnat2022`): the server
   (`bin/main`) and the account manager (`bin/admin`);
3. installs them to `/opt/anontoken/anontoken` and `/opt/anontoken/admin`,
   and the unit to `/etc/systemd/system/anontoken.service`;
4. creates the `anontoken` system user and `/var/lib/anontoken` (where the
   keystore is persisted as `keystore.bin` and accounts as `users.bin`);
5. writes the runtime configuration to `/etc/default/anontoken` and starts the
   service on `127.0.0.1:9999`;
6. smoke-tests `GET /health`.

You can pre-create the first owner account during install:

```bash
ANONTONKEN_INIT_USER=admin ANONTONKEN_INIT_PASS='a-long-password' sudo bash deploy/install.sh
```

(Otherwise the server starts and simply rejects every request with `401`
until you add an account with the `admin` tool below.)

## Configuration

The server reads its defaults from environment variables (command-line
arguments override them):

| env var               | default                          | description                 |
|-----------------------|----------------------------------|-----------------------------|
| `ANONTONKEN_BIND_ADDR`| `127.0.0.1`                      | bind address                |
| `ANONTONKEN_PORT`     | `9999`                           | listen port (1..65535)      |
| `ANONTONKEN_KEYSTORE` | `keystore.bin`                   | keystore file               |
| `ANONTONKEN_LIFETIME_DAYS` | `90`                        | default key lifetime (days) |
| `ANONTONKEN_USERS`    | *(none → deny all)*              | users file (accounts)       |

On the Pi the systemd unit reads these from
**`/etc/default/anontoken`** (via `EnvironmentFile`), so to change the
listen port just edit that file and restart:

```bash
sudo nano /etc/default/anontoken     # e.g. ANONTONKEN_PORT=8443
sudo systemctl restart anontoken     # no unit-file changes needed
```

The unit's `ExecStart` forwards the variables:
`anontoken ${ANONTONKEN_BIND_ADDR} ${ANONTONKEN_PORT}
${ANONTONKEN_KEYSTORE} ${ANONTONKEN_LIFETIME_DAYS} ${ANONTONKEN_USERS}`.

## Accounts (authentication)

Only the owner can create accounts - there is no registration endpoint.
On the Pi, use the `admin` tool (installer puts it at `/opt/anontoken/admin`):

```bash
# add an account for an integrator
sudo /opt/anontoken/admin add alice 'a-strong-password'

# rotate a password / list / remove
sudo /opt/anontoken/admin setpass alice 'a-new-password'
sudo /opt/anontoken/admin list
sudo /opt/anontoken/admin remove alice
```

Notes:

- usernames: 3–24 chars of `a-z A-Z 0-9 . _ -`; passwords: 8–96 chars.
- passwords are **never stored** - only a random 32-byte salt + the
  PBKDF2-HMAC-SHA256 digest (100 000 rounds, SPARK-proven `Kms_Passwd`).
- **no account lockout (v0.4.0)**: brute-force attempts are allowed
  without limit - wrong passwords never lock the account and the correct
  password always works.  Security rests on password strength
  (PBKDF2-HMAC-SHA256 100 000 rounds, constant-time digest compare);
  make sure every developer account uses a strong password.  A wrong
  guess against an unknown username still runs a dummy derivation so
  timing does not reveal which accounts exist.
- changes take effect **immediately, no restart**: the server re-reads
  the users file when it changes on disk.
- with no users file the server starts in **deny-all** mode (every
  request except `/health` → `401`).

Then integrators call the API with HTTP Basic auth, e.g.:

```bash
curl -u alice:'a-strong-password' https://your.domain/keys
```

`GET /health` stays public (liveness check).

## API (v0.4.0 licensing model)

Three parties:

1. **Provider (you)** - runs the server and creates developer accounts with
   the `admin` tool.
2. **Developer** - one account each; creates keys for their end customers.
   Developers only ever see the keys they created (per-account isolation).
3. **End customer** - the developer embeds a `key_id` + `activation_secret`
   into their software; each run the software phone-homes
   `POST /keys/<id>/check` and the server says whether the key is alive.

Developer-facing endpoints (HTTP Basic auth, scoped to your own keys):

```
GET    /health                 -> {"status":"ok","version":"0.4.0","keys":N}   (public)
GET    /keys                   -> YOUR keys only   {"key_id","status","activated","expires_at"}
POST   /keys                   -> create a key     {"lifetime_minutes": N} or
                                                    {"lifetime_seconds": N}
                                                    (optional; default: server lifetime)
                                  response includes "activation_secret" (shown ONCE)
GET    /keys/<id>/pub          -> public key
POST   /keys/<id>/sign         -> sign a message   {"message":"<base64>"}
POST   /keys/<id>/verify       -> verify           {"message":"<base64>","signature":"<base64>"}
DELETE /keys/<id>              -> revoke a key
```

Customer-facing endpoint (public - no Basic auth; the secret IS the
credential):

```
POST   /keys/<id>/check        -> {"secret":"<b64 32B>"}
      200 {"valid":true,"activated_at":N,"expires_at":N}     license alive
      404 (not_found / revoked / wrong secret all look identical)
```

(`/check` answers **404 for every non-valid state** - missing key, wrong
secret and revoked key are indistinguishable from the outside, so nobody
can probe whether a given license id is live or was revoked.)

Key-lifetime semantics (lazy activation):

- A key's TTL is chosen at creation (`lifetime_minutes`/`lifetime_seconds`,
  or the server default) but **only starts counting on the first successful
  `/check`** - i.e. the first time the customer's software runs.
- An **unactivated** key never expires on its own (it sits idle until used).
- Once activated, the key dies exactly `TTL` after activation and is purged
  (any later call → 404).
- `DELETE` revokes: an activated key is blocked immediately (check → 404
  from outside, sign → 403 for the owner) and stays listed until its
  deadline for audit; an unactivated key is freed outright (it was never
  used).

```
Ví dụ key có thời hạn 30 phút (tính từ lần khách chạy đầu tiên):

    curl -X POST -d '{"lifetime_minutes": 30}' http://127.0.0.1:9999/keys

Giá trị lifetime > 30 năm (trần an toàn chống chiếm slot vĩnh viễn) hoặc = 0 bị từ chối với lỗi "bad_lifetime".
Keystore hỗ trợ tối đa 65.536 key đồng thời; file keystore ghi động
(chỉ lưu key còn sống). `GET /keys` liệt kê tối đa 1000 key; tổng số
key xem qua `GET /health`.
```

`<id>` is the 16-hex-digit key id.  Messages are Ed25519 (RFC 8032),
base64-encoded with padding.  On a v1/v2 keystore upgrade the server
claims legacy keys for the first account in the users file automatically.

## Operations

```bash
systemctl status anontoken
journalctl -u anontoken -f
systemctl restart anontoken
```
