#!/usr/bin/env bash
# Test the three big-update features: strict JSON body (Finding 5),
# 30-year TTL ceiling, and per-account key limits (admin limit).
set -u
cd "$(dirname "$0")/.."
BIN=./bin/main
PORT="${T_PORT:-9931}"
KS=/tmp/at5-ks.bin
LOG=/tmp/at5.log
US=/tmp/at5-users.bin
U=testuser; P=TestPass123
A=(-u "$U:$P")
B="http://127.0.0.1:$PORT"

# kill any server using our port, then wait for the port to free up
kill_by_port() {
  pkill -f "bin/main 127.0.0.1 $PORT" 2>/dev/null
  pkill -f "$KS" 2>/dev/null
  sleep 0.5
}
kill_by_port
rm -f "$KS" "$US" "$LOG"

if ! ./bin/admin -f "$US" add "$U" "$P"; then
  echo "FATAL: admin add failed"; exit 1
fi
setsid bash -c "$BIN 127.0.0.1 $PORT $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1.5

echo "== health =="
curl -s "$B/health"; echo

echo "== strict body: POST /keys with malformed bodies (expect 400) =="
for body in 'null' '[]' '{' '}' '{]' 'garbage' '{"lifetime_seconds":5x}' '{"lifetime_seconds":"3600"}' '{"lifetime_seconds": -5}' '{"a":{"b":1}}' '{"lifetime_seconds": 3600} junk' '{"lifetime_seconds": [1,2]}' '{"lifetime_seconds" 3600}' '{"":1}' '{"lifetime_seconds":1.5}'; do
  code=$(curl -s -o /dev/null -w '%{http_code}' -X POST -d "$body" "${A[@]}" "$B/keys")
  echo "  [$body] -> $code"
done
echo "== valid bodies still create keys =="
for body in '' '{}' '{"lifetime_seconds": 3600}' '{ "lifetime_seconds" : 3600 }'; do
  if [ -z "$body" ]; then
    code=$(curl -s -o /dev/null -w '%{http_code}' -X POST "${A[@]}" "$B/keys")
  else
    code=$(curl -s -o /dev/null -w '%{http_code}' -X POST -d "$body" "${A[@]}" "$B/keys")
  fi
  echo "  [$body] -> $code"
done
echo "== strict body on /sign /verify /check (expect 400) =="
curl -s -o /dev/null -w 'sign-garbage=%{http_code}\n' -X POST -d 'garbage' "${A[@]}" "$B/keys/ffffffffffffffff/sign"
curl -s -o /dev/null -w 'verify-nested=%{http_code}\n' -X POST -d '{"message":{"x":1}}' "${A[@]}" "$B/keys/ffffffffffffffff/verify"
curl -s -o /dev/null -w 'check-garbage=%{http_code}\n' -X POST -d '{"secret":[1]}' "$B/keys/ffffffffffffffff/check"

echo "== TTL: 30 years ok, 30y+1 rejected =="
curl -s -X POST -d '{"lifetime_seconds": 946080000}' "${A[@]}" "$B/keys" | python3 -c "import sys,json; print('ttl_30y =', json.load(sys.stdin)['ttl_seconds'])"
curl -s -o /dev/null -w 'ttl_31y=%{http_code}\n' -X POST -d '{"lifetime_seconds": 946080001}' "${A[@]}" "$B/keys"
curl -s -o /dev/null -w 'ttl_minutes_30y=%{http_code}\n' -X POST -d '{"lifetime_minutes": 15768000}' "${A[@]}" "$B/keys"

echo "== key limit: fresh keystore, set 2, create 3 (3rd -> 403) =="
kill_by_port
rm -f "$KS"
setsid bash -c "$BIN 127.0.0.1 $PORT $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1.5
./bin/admin -f "$US" limit "$U" 2
for i in 1 2 3; do
  curl -s -o /dev/null -w "key$i=%{http_code}\n" -X POST "${A[@]}" "$B/keys"
done
echo "== delete 1 key then create again (should succeed -> 201) =="
KID=$(curl -s "${A[@]}" "$B/keys" | python3 -c "import sys,json; k=json.load(sys.stdin)['keys']; print(k[0]['key_id'] if k else '')")
curl -s -o /dev/null -w "del=%{http_code}\n" -X DELETE "${A[@]}" "$B/keys/$KID"
curl -s -o /dev/null -w "recreate=%{http_code}\n" -X POST "${A[@]}" "$B/keys"

echo "== admin limit invalid inputs =="
./bin/admin -f "$US" limit "$U" abc || echo "ok: abc rejected"
./bin/admin -f "$US" limit "$U" 70000 || echo "ok: 70000 rejected"
./bin/admin -f "$US" limit "$U" 0 && echo "ok: 0 = unlimited"
./bin/admin -f "$US" list

kill_by_port
echo "== server log errors (should be 0) =="
grep -c "connection error" "$LOG" || true
echo DONE