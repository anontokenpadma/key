with Ada.Text_IO;
with Interfaces;
use  Interfaces;
with Kms_Os;

procedure T_Open is
   use Kms_Os;
   PB : Path_Buf;
   W  : Chunk := [others => 0];
   R  : C_SSize;
   RC : C_Int;
begin
   Fill_Path (PB, "/tmp/zztmp.bin");
   RC := C_Open (PB, O_WRONLY_TRUNC_CREATE, Path_Mode);
   if RC < 0 then
      Ada.Text_IO.Put_Line ("OPEN FAILED");
      return;
   end if;
   Ada.Text_IO.Put_Line ("OPEN OK fd=" & Integer'Image (Integer (RC)));
   W (0) := 65;
   C_Write (RC, W, 1, R);
   Ada.Text_IO.Put_Line ("WRITE rc=" & Integer_64'Image (Integer_64 (R)));
   if C_Close (RC) /= 0 then
      null;
   end if;
   Fill_Path (PB, "/tmp/zztmp2.bin");
   RC := C_Rename (PB, PB);
   Ada.Text_IO.Put_Line ("RENAME rc=" & Integer'Image (Integer (RC)));
   RC := C_Unlink (PB);
   Ada.Text_IO.Put_Line ("UNLINK rc=" & Integer'Image (Integer (RC)));
end T_Open;