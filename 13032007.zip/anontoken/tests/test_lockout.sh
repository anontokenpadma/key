#!/usr/bin/env bash
# No-lockout policy (v0.3.2, now v0.4.0):
#   - brute-force attempts are deliberately allowed WITHOUT limit
#   - many wrong passwords in a row never lock the account
#   - the CORRECT password still works after any number of failures
#   - wrong guesses at an unknown username change nothing
#   - admin setpass still works and takes effect immediately
# Security rests on password strength (PBKDF2-HMAC-SHA256 100 000
# rounds, constant-time compare), not on account lockout.
cd "$(dirname "$0")/.."
BIN=./bin/main
ADMIN=./bin/admin
P=9995
H=http://127.0.0.1:$P
KS=/tmp/kse_lock.bin
LOG=/tmp/kse_lock.log
US=/tmp/kse_lock_users.bin

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
sleep 0.5
rm -f "$KS" "$LOG" "$US"
"$ADMIN" -f "$US" add victim 'Correct-Pass-1' >/dev/null 2>&1 || true

setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1

FAIL=0
chk() { if [ "$2" = "$3" ]; then echo "PASS  $1"; else echo "FAIL  $1 (got [$2] want [$3])"; FAIL=1; fi; }
code() { curl -s $4 -o /dev/null -w '%{http_code}' -u "$2:$3" $H/keys; }

AUTH_U=victim
AUTH_P=Correct-Pass-1

chk "correct password works" "$(code "" $AUTH_U $AUTH_P "")" "200"

echo "-- 25 wrong passwords in a row (well past the old limit of 5) --"
for i in $(seq 1 25); do
  code "" $AUTH_U "wrong-pass-$i" "" >/dev/null
done

chk "correct password STILL works after 25 failures -> 200" "$(code "" $AUTH_U $AUTH_P "")" "200"
chk "another wrong password still 401 (never locked in)" "$(code "" $AUTH_U still-wrong "")" "401"
chk "correct password again after more failures -> 200" "$(code "" $AUTH_U $AUTH_P "")" "200"

echo "-- unknown username guesses change nothing --"
for i in $(seq 1 10); do
  code "" no-such-user "whatever-$i" "" >/dev/null
done
chk "unknown user still 401" "$(code "" no-such-user whatever "")" "401"
chk "victim unaffected by unknown-user guesses -> 200" "$(code "" $AUTH_U $AUTH_P "")" "200"

echo "-- even 100 more failures cannot lock the account --"
for i in $(seq 1 100); do
  code "" $AUTH_U "flood-$i" "" >/dev/null
done
chk "correct password after 125+ total failures -> 200" "$(code "" $AUTH_U $AUTH_P "")" "200"

echo "-- admin setpass still takes effect immediately --"
"$ADMIN" -f "$US" setpass $AUTH_U 'New-Pass-2' >/dev/null
sleep 0.3   # server reloads users file on next request
chk "correct NEW password after setpass -> 200" "$(code "" $AUTH_U 'New-Pass-2' "")" "200"

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
echo "RESULT: $([ $FAIL = 0 ] && echo ALL_PASS || echo HAS_FAILURES)"