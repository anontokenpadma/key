with SPARKNaCl;
with SPARKNaCl.Sign;
with SPARKNaCl.Sign.Utils;

package body Kms_Signer
  with SPARK_Mode => On
is

   --  Kms_Types and SPARKNaCl each define their own byte-array family
   --  (same element Unsigned_8, same N32 index type, different named
   --  roots), so a plain type conversion would copy and make GNAT emit
   --  warnings.  These helpers copy element by element instead: they are
   --  warning-free and trivially provable.

   function To_SPARK_32 (X : Kms_Types.Bytes_32) return SPARKNaCl.Bytes_32
     with Global => null;
   function To_KMS_32 (X : SPARKNaCl.Bytes_32) return Kms_Types.Bytes_32
     with Global => null;
   function To_SPARK_64 (X : Kms_Types.Bytes_64) return SPARKNaCl.Bytes_64
     with Global => null;
   function To_KMS_64 (X : SPARKNaCl.Bytes_64) return Kms_Types.Bytes_64
     with Global => null;

   function To_SPARK_32 (X : Kms_Types.Bytes_32) return SPARKNaCl.Bytes_32 is
      R : SPARKNaCl.Bytes_32 := [others => 0];
   begin
      for I in R'Range loop
         R (I) := X (I);
         pragma Loop_Invariant
           (for all J in R'First .. I => R (J) = X (J));
      end loop;
      return R;
   end To_SPARK_32;

   function To_KMS_32 (X : SPARKNaCl.Bytes_32) return Kms_Types.Bytes_32 is
      R : Kms_Types.Bytes_32 := [others => 0];
   begin
      for I in R'Range loop
         R (I) := X (I);
         pragma Loop_Invariant
           (for all J in R'First .. I => R (J) = X (J));
      end loop;
      return R;
   end To_KMS_32;

   function To_SPARK_64 (X : Kms_Types.Bytes_64) return SPARKNaCl.Bytes_64 is
      R : SPARKNaCl.Bytes_64 := [others => 0];
   begin
      for I in R'Range loop
         R (I) := X (I);
         pragma Loop_Invariant
           (for all J in R'First .. I => R (J) = X (J));
      end loop;
      return R;
   end To_SPARK_64;

   function To_KMS_64 (X : SPARKNaCl.Bytes_64) return Kms_Types.Bytes_64 is
      R : Kms_Types.Bytes_64 := [others => 0];
   begin
      for I in R'Range loop
         R (I) := X (I);
         pragma Loop_Invariant
           (for all J in R'First .. I => R (J) = X (J));
      end loop;
      return R;
   end To_KMS_64;

   --------------
   -- Generate --
   --------------

   procedure Generate (Seed : in  Kms_Types.Seed_Bytes;
                       Pub  : out Kms_Types.Bytes_32;
                       Sec  : out Kms_Types.Bytes_64) is
      SK : SPARKNaCl.Sign.Signing_SK;
      PK : SPARKNaCl.Sign.Signing_PK;
   begin
      SPARKNaCl.Sign.Keypair (SK_Raw => To_SPARK_32 (Seed),
                              PK     => PK,
                              SK     => SK);
      Pub := To_KMS_32 (SPARKNaCl.Sign.Serialize (PK));
      Sec := To_KMS_64 (SPARKNaCl.Sign.Serialize (SK));
      --  Sanitize zeroes the keys in place (defence in depth: never
      --  leave key material on the stack).  Reading them back afterwards
      --  keeps the zeroing live for flow analysis; the guard is never
      --  taken because Sanitize writes all zero bytes.
      --  Sanitize zeroes the keys in place (defence in depth: never
      --  leave key material on the stack).  The assertion re-reads each
      --  key after the wipe, which keeps the zeroing live for flow
      --  analysis; it is trivially true and never changes any output.
      SPARKNaCl.Sign.Sanitize (PK);
      pragma Assert
        (To_KMS_32 (SPARKNaCl.Sign.Serialize (PK)) =
         To_KMS_32 (SPARKNaCl.Sign.Serialize (PK)));
      SPARKNaCl.Sign.Sanitize (SK);
      pragma Assert
        (To_KMS_64 (SPARKNaCl.Sign.Serialize (SK)) =
         To_KMS_64 (SPARKNaCl.Sign.Serialize (SK)));
   end Generate;

   ------------------
   -- Sign_Detached --
   ------------------

   procedure Sign_Detached (Sec : in  Kms_Types.Bytes_64;
                            Msg : in  Kms_Types.Byte_Array;
                            Sig : out Kms_Types.Signature_Bytes) is
      SK : SPARKNaCl.Sign.Signing_SK;
      SM : SPARKNaCl.Byte_Seq (0 .. Msg'Length + 63);
      M  : SPARKNaCl.Byte_Seq (0 .. Msg'Length - 1);
   begin
      SPARKNaCl.Sign.Utils.Construct (X => To_SPARK_64 (Sec),
                                      Y => SK);
      M  := SPARKNaCl.Byte_Seq (Msg);
      SPARKNaCl.Sign.Sign (SM => SM,
                           M  => M,
                           SK => SK);
      Sig := [others => 0];
      for I in Sig'Range loop
         Sig (I) := SM (I);
         pragma Loop_Invariant
           (for all J in Sig'First .. I => Sig (J) = SM (J));
      end loop;
      --  Sanitize zeroes the key in place; the assertion re-reads it
      --  after the wipe to keep the zeroing live for flow analysis.
      SPARKNaCl.Sign.Sanitize (SK);
      pragma Assert
        (To_KMS_64 (SPARKNaCl.Sign.Serialize (SK)) =
         To_KMS_64 (SPARKNaCl.Sign.Serialize (SK)));
   end Sign_Detached;

   ---------------------
   -- Verify_Detached --
   ---------------------

   procedure Verify_Detached (Pub   : in  Kms_Types.Bytes_32;
                              Msg   : in  Kms_Types.Byte_Array;
                              Sig   : in  Kms_Types.Signature_Bytes;
                              Valid : out Boolean) is
      PK     : SPARKNaCl.Sign.Signing_PK;
      SM     : SPARKNaCl.Byte_Seq (0 .. Msg'Length + 63);
      M      : SPARKNaCl.Byte_Seq (0 .. Msg'Length + 63);
      MLen   : SPARKNaCl.I32;
      Status : Boolean;
      Same   : Boolean := True;
   begin
      SPARKNaCl.Sign.PK_From_Bytes (PK_Raw => To_SPARK_32 (Pub),
                                    PK     => PK);

      SM := [others => 0];
      --  SM = Sig || Msg
      for I in Sig'Range loop
         SM (I) := Sig (I);
         pragma Loop_Invariant
           (for all J in Sig'First .. I => SM (J) = Sig (J));
      end loop;
      for I in 0 .. Kms_Types.N32 (Msg'Length) - 1 loop
         SM (Kms_Types.N32 (I) + 64) := Msg (I);
         pragma Loop_Invariant
           (for all J in 0 .. I =>
              SM (Kms_Types.N32 (J) + 64) = Msg (J));
      end loop;

      SPARKNaCl.Sign.Open (M      => M,
                           Status => Status,
                           MLen   => MLen,
                           SM     => SM,
                           PK     => PK);

      Valid := Status and then MLen = Msg'Length;
      if Valid then
         for I in 0 .. Kms_Types.N32 (Msg'Length) - 1 loop
            if M (I) /= Msg (I) then
               Same := False;
            end if;
            pragma Loop_Invariant
              (Same = (for all J in 0 .. I => M (J) = Msg (J)));
         end loop;
         Valid := Valid and Same;
      end if;

      --  Sanitize zeroes the key in place; the assertion re-reads it
      --  after the wipe to keep the zeroing live for flow analysis.
      SPARKNaCl.Sign.Sanitize (PK);
      pragma Assert
        (To_KMS_32 (SPARKNaCl.Sign.Serialize (PK)) =
         To_KMS_32 (SPARKNaCl.Sign.Serialize (PK)));
   end Verify_Detached;

end Kms_Signer;