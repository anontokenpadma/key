with SPARKNaCl.MAC;
with SPARKNaCl.Hashing.SHA256;

package body Kms_Passwd
  with SPARK_Mode => On
is

   ----------------------------------------
   --  PBKDF2 (RFC 2898), single 32-byte block
   --    U1 = HMAC(Pass, Salt || INT_32_BE(1))
   --    Ui = HMAC(Pass, U(i-1))
   --    T  = U1 xor U2 xor ... xor Uc
   --    Output = T
   ----------------------------------------

   procedure Derive (Salt   : in     Digest_Bytes;
                     Pass   : in     Byte_Array;
                     Output :    out Digest_Bytes) is
      --  Salt || 0x00000001 (the single block index).
      Salt_Blk : Byte_Array (0 .. Digest_Length + 3) := [others => 0];
      --  Same shape/length as SPARKNaCl's SHA-256 digest (32 bytes),
      --  so no conversion buffer is needed in the round loop.  These are
      --  fully assigned by HMAC_SHA_256 / D := U before first use.
      U        : SPARKNaCl.Hashing.SHA256.Digest;
      Nxt      : SPARKNaCl.Hashing.SHA256.Digest;
      D        : SPARKNaCl.Hashing.SHA256.Digest;
   begin
      --  Salt || INT_32_BE(1), block index is always 1 here.
      for I in Salt'Range loop
         Salt_Blk (I) := Salt (I);
      end loop;
      Salt_Blk (Salt'Last + 1) := 0;
      Salt_Blk (Salt'Last + 2) := 0;
      Salt_Blk (Salt'Last + 3) := 0;
      Salt_Blk (Salt'Last + 4) := 1;

      --  Round 1: U = U1 = HMAC(Pass, Salt || 1)
      SPARKNaCl.MAC.HMAC_SHA_256
        (Output => U,
         M      => SPARKNaCl.Byte_Seq (Salt_Blk),
         K      => SPARKNaCl.Byte_Seq (Pass));

      --  T = U1
      D := U;

      --  Rounds 2..N: Ui = HMAC(Pass, U(i-1)); T = T xor Ui.
      --  (No loop invariants here: Derive has no postcondition, so the
      --  only checks gnatprove must discharge on this loop are the bounds
      --  and index checks, which it proves directly.)
      for I in 2 .. Pbkdf2_Iterations loop
         SPARKNaCl.MAC.HMAC_SHA_256
           (Output => Nxt,
            M      => SPARKNaCl.Byte_Seq (U),
            K      => SPARKNaCl.Byte_Seq (Pass));
         for J in D'Range loop
            D (J) := D (J) xor Nxt (J);
         end loop;
         U := Nxt;
      end loop;

      --  Copy the digest out (same byte range, nominal conversion).
      for I in Output'Range loop
         Output (I) := Byte (D (I));
      end loop;
   end Derive;

end Kms_Passwd;