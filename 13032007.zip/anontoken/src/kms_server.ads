------------------------------------------------------------------------------
--  Kms_Server : TCP server loop, fully SPARK (SPARK_Mode => On).
--  All protocol logic lives in the SPARK-proven Kms_Http package; this
--  unit only moves bytes between the socket (through the Kms_Os C
--  imports) and Kms_Http.Parse / Kms_Http.Dispatch.  The account table
--  (from the users file) is loaded on startup and re-loaded on every
--  request, so ``admin`` updates are picked up without a restart.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Server
  with SPARK_Mode => On
is

   subtype Port_Number is Positive range 1 .. 65_535;

   type Config is record
      Bind_Address  : String (1 .. 128) := [others => ' '];
      Bind_Len      : Natural           := 9;   --  "127.0.0.1"
      Port          : Port_Number       := 9999;
      Keystore_Path : String (1 .. 512) := [others => ASCII.NUL];
      Path_Len      : Natural range 0 .. 507 := 0;  -- 0 = no persistence
      Users_Path    : String (1 .. 512) := [others => ASCII.NUL];
      Users_Len     : Natural range 0 .. 507 := 0;  -- 0 = no users file (deny all)
      Lifetime_Days : Kms_Types.I64     := 90;
      Backlog       : Positive          := 16;
   end record;

   --  Run the server forever, serving requests from the socket described
   --  by Cfg.  KS is the (already allocated) keystore, passed as a plain
   --  in-out parameter so this unit contains no access types: every
   --  subprogram in Kms_Server stays fully SPARK-provable at level 4.
   procedure Run (Cfg : in Config; KS : in out Keystore)
     with Global => null,
          Pre  => Cfg.Bind_Len >= 1 and then
                  Cfg.Bind_Len <= Cfg.Bind_Address'Length and then
                  Cfg.Path_Len <= Cfg.Keystore_Path'Length and then
                  Cfg.Users_Len <= Cfg.Users_Path'Length and then
                  Cfg.Lifetime_Days >= 1 and then
                  Cfg.Lifetime_Days <= 3650;

end Kms_Server;