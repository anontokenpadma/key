------------------------------------------------------------------------------
--  admin : manage the owner-managed accounts of the AnonToken KMS.
--
--  Usage:
--      admin [-f <users-file>] add      <user> <password>
--      admin [-f <users-file>] remove   <user>
--      admin [-f <users-file>] setpass  <user> <password>
--      admin [-f <users-file>] limit    <user> <maxkeys>
--      admin [-f <users-file>] count    <user> [<keystore-file>]
--      admin [-f <users-file>] list
--
--  The users file defaults to $ANONTONKEN_USERS or "users.bin".  Passwords
--  are never stored: only a random 32-byte salt plus the PBKDF2-HMAC-SHA256
--  digest (SPARK-proven Kms_Passwd) are written to disk.
--
--  Changes take effect immediately - the server re-reads the users file on
--  the next request, so no restart is needed.
------------------------------------------------------------------------------

with Ada.Command_Line;
with Ada.Environment_Variables;
with Ada.Text_IO;
with Interfaces;
use  Interfaces;

with Kms_File;
with Kms_Keystore;
with Kms_Os;
with Kms_Passwd;
with Kms_Types;
with Kms_Users;
use  Kms_Types;

procedure Admin is

   -------------
   -- Fatal ----  report an error and set a non-zero exit status
   -------------

   procedure Fatal (Msg : String) is
   begin
      Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "admin: " & Msg);
      Ada.Command_Line.Set_Exit_Status (1);
   end Fatal;

   ----------------
   -- Name_To_Buf --
   ----------------

   --  Copy S into B, validating the username charset and length.  Returns
   --  the name length, or 0 when S is invalid (3..24 of a-z A-Z 0-9 . _ -).
   function Name_To_Buf (S : String; B : out User_Name_Buffer) return Natural is
      C : Character;
   begin
      if S'Length < 3 or else S'Length > User_Name_Length then
         return 0;
      end if;
      for I in S'Range loop
         C := S (I);
         if not ((C in 'a' .. 'z') or else (C in 'A' .. 'Z') or else
                 (C in '0' .. '9') or else C = '.' or else
                 C = '_' or else C = '-')
         then
            return 0;
         end if;
         B (N32 (I - S'First)) := Byte (Character'Pos (C));
      end loop;
      return S'Length;
   end Name_To_Buf;

   ----------------
   -- Pass_To_Buf --
   ----------------

   --  Copy S into B.  Returns the length, or 0 when S is invalid
   --  (8..96 bytes).
   function Pass_To_Buf (S : String; B : out Password_Buffer) return Natural is
   begin
      if S'Length < 8 or else S'Length > Password_Length then
         return 0;
      end if;
      for I in S'Range loop
         B (N32 (I - S'First)) := Byte (Character'Pos (S (I)));
      end loop;
      return S'Length;
   end Pass_To_Buf;

   ----------------
   -- Users_Path --
   ----------------

   --  Default users file: $ANONTONKEN_USERS, else "users.bin".
   --  (Applications reading the env var in a declarative part raise
   --  Constraint_Error that a function-level handler cannot catch, so
   --  probe with Exists first.)
   function Users_Path (Max_Len : Natural) return String is
   begin
      if not Ada.Environment_Variables.Exists ("ANONTONKEN_USERS") then
         return "users.bin";
      end if;
      declare
         E : constant String :=
           Ada.Environment_Variables.Value ("ANONTONKEN_USERS");
      begin
         if E'Length = 0 or else E'Length > Max_Len then
            return "users.bin";
         end if;
         return E;
      end;
   end Users_Path;

   ------------------
   -- Keystore_Path --
   ------------------

   --  Default keystore file: $ANONTONKEN_KEYSTORE, else "keystore.bin"
   --  (mirrors the server defaults in main.adb).
   function Keystore_Path (Max_Len : Natural) return String is
   begin
      if not Ada.Environment_Variables.Exists ("ANONTONKEN_KEYSTORE") then
         return "keystore.bin";
      end if;
      declare
         E : constant String :=
           Ada.Environment_Variables.Value ("ANONTONKEN_KEYSTORE");
      begin
         if E'Length = 0 or else E'Length > Max_Len then
            return "keystore.bin";
         end if;
         return E;
      end;
   end Keystore_Path;

   --------------
   -- Load_All --
   --------------

   --  Load the table; a missing file yields an empty table (fine for add),
   --  a corrupt file a fatal error (the owner should delete or restore it).
   procedure Load_All (Path : String; T : out User_Table; OK : out Boolean) is
      Loaded : Boolean;
   begin
      Kms_Users.Init (T);
      Kms_File.Load_Users (Path, T, Loaded);
      if not Loaded then
         --  distinguish missing (ok) from corrupt (bad)
         if Kms_File.Exists (Path) then
            Fatal ("users file '" & Path & "' is corrupt - delete or restore it");
            OK := False;
            return;
         end if;
      end if;
      OK := True;
   end Load_All;

   ---------------
   -- Name_Text --
   ---------------

   function Name_Text (R : User_Record) return String is
      L : constant Natural := Natural (R.Name_Len);
      S : String (1 .. L);
   begin
      for J in 1 .. L loop
         S (J) := Character'Val (R.Name (N32 (J) - 1));
      end loop;
      return S;
   end Name_Text;

   -------------
   -- Cmd_Add --
   -------------

   procedure Cmd_Add (Path : String; Uname : String; Pass : String) is
      T       : User_Table;
      Rec     : User_Record := (In_Use => True, others => <>);
      U_Len   : Natural;
      P_Len   : Natural;
      Seed    : Seed_Bytes := [others => 0];
      Pwd     : Password_Buffer := [others => 0];
      Added   : Boolean;
      OK      : Boolean;
      RNG_OK  : Boolean := False;
   begin
      U_Len := Name_To_Buf (Uname, Rec.Name);
      if U_Len = 0 then
         Fatal ("invalid username '" & Uname & "' (3-24 chars of a-z A-Z 0-9 . _ -)");
         return;
      end if;
      Rec.Name_Len := N32 (U_Len);
      P_Len := Pass_To_Buf (Pass, Pwd);
      if P_Len = 0 then
         Fatal ("invalid password (must be 8-96 characters)");
         return;
      end if;
      Load_All (Path, T, OK);
      if not OK then
         return;
      end if;
      --  the password is only ever hashed; the salt is fresh random.
      --  fail-closed: an RNG error must not yield a zero/known salt.
      Kms_Os.Random_Bytes (Seed, RNG_OK);
      if not RNG_OK then
         Fatal ("RNG failure - cannot generate a secure salt; try again");
         return;
      end if;
      Rec.Salt := Digest_Bytes (Seed);
      Kms_Passwd.Derive (Rec.Salt, Pwd (0 .. N32 (P_Len) - 1), Rec.Hash);
      Kms_Users.Add (T, Rec, Added);
      if not Added then
         Fatal ("user '" & Uname & "' already exists (use setpass to rotate)");
         return;
      end if;
      Kms_File.Save_Users (Path, T);
      Ada.Text_IO.Put_Line
        ("user '" & Uname & "' added to " & Path);
   end Cmd_Add;

   ----------------
   -- Cmd_Remove --
   ----------------

   procedure Cmd_Remove (Path : String; Uname : String) is
      T     : User_Table;
      B     : User_Name_Buffer := [others => 0];
      U_Len : Natural;
      F     : Boolean;
      Idx   : N32;
      OK    : Boolean;
   begin
      U_Len := Name_To_Buf (Uname, B);
      if U_Len = 0 then
         Fatal ("invalid username '" & Uname & "'");
         return;
      end if;
      Load_All (Path, T, OK);
      if not OK then
         return;
      end if;
      Kms_Users.Find (T, B, N32 (U_Len), F, Idx);
      if not F then
         Fatal ("no such user: '" & Uname & "'");
         return;
      end if;
      Kms_Users.Remove (T, Idx);
      Kms_File.Save_Users (Path, T);
      Ada.Text_IO.Put_Line ("user '" & Uname & "' removed from " & Path);
   end Cmd_Remove;

   ------------------
   -- Cmd_Setpass  --
   ------------------

   procedure Cmd_Setpass (Path : String; Uname : String; Pass : String) is
      T     : User_Table;
      B     : User_Name_Buffer := [others => 0];
      U_Len : Natural;
      P_Len : Natural;
      Pwd   : Password_Buffer := [others => 0];
      Seed  : Seed_Bytes := [others => 0];
      New_Salt : Digest_Bytes := [others => 0];
      New_Hash : Digest_Bytes := [others => 0];
      F     : Boolean;
      Idx   : N32;
      OK    : Boolean;
      RNG_OK  : Boolean := False;
   begin
      U_Len := Name_To_Buf (Uname, B);
      if U_Len = 0 then
         Fatal ("invalid username '" & Uname & "'");
         return;
      end if;
      P_Len := Pass_To_Buf (Pass, Pwd);
      if P_Len = 0 then
         Fatal ("invalid password (must be 8-96 characters)");
         return;
      end if;
      Load_All (Path, T, OK);
      if not OK then
         return;
      end if;
      Kms_Users.Find (T, B, N32 (U_Len), F, Idx);
      if not F then
         Fatal ("no such user: '" & Uname & "'");
         return;
      end if;
      --  fail-closed: an RNG error must not yield a zero/known salt.
      Kms_Os.Random_Bytes (Seed, RNG_OK);
      if not RNG_OK then
         Fatal ("RNG failure - cannot generate a secure salt; try again");
         return;
      end if;
      New_Salt := Digest_Bytes (Seed);
      Kms_Passwd.Derive (New_Salt, Pwd (0 .. N32 (P_Len) - 1), New_Hash);
      T (Idx).Salt := New_Salt;
      T (Idx).Hash := New_Hash;
      Kms_File.Save_Users (Path, T);
      Ada.Text_IO.Put_Line
        ("password changed for user '" & Uname & "'");
   end Cmd_Setpass;

   --------------
   -- Cmd_Limit --
   ----------------

   procedure Cmd_Limit (Path : String; Uname : String; Limit_Str : String) is
      T     : User_Table;
      B     : User_Name_Buffer := [others => 0];
      U_Len : Natural;
      F     : Boolean;
      Idx   : N32;
      OK    : Boolean;
      Val   : N32;
   begin
      U_Len := Name_To_Buf (Uname, B);
      if U_Len = 0 then
         Fatal ("invalid username '" & Uname & "'");
         return;
      end if;
      --  parse the limit: a non-negative integer <= Max_Keys
      begin
         Val := N32'Value (Limit_Str);
         if Val > Max_Keys then
            Fatal ("key limit must be 0.." & N32'Image (Max_Keys));
            return;
         end if;
      exception
         when Constraint_Error =>
            Fatal ("invalid key limit '" & Limit_Str &
                   "' (must be 0.." & N32'Image (Max_Keys) & ")");
            return;
      end;
      Load_All (Path, T, OK);
      if not OK then
         return;
      end if;
      Kms_Users.Find (T, B, N32 (U_Len), F, Idx);
      if not F then
         Fatal ("no such user: '" & Uname & "'");
         return;
      end if;
      T (Idx).Key_Limit := Val;
      Kms_File.Save_Users (Path, T);
      if Val = 0 then
         Ada.Text_IO.Put_Line
           ("key limit for '" & Uname & "' cleared (unlimited)");
      else
         Ada.Text_IO.Put_Line
           ("key limit for '" & Uname & "' set to " & N32'Image (Val));
      end if;
   end Cmd_Limit;

   --------------
   -- Cmd_Count --
   --------------

   --  Report how many keys the account currently owns in the keystore
   --  (every key still occupying a slot counts, whatever its status:
   --  active, revoked-but-not-purged, or unactivated).
   procedure Cmd_Count (Path : String; Ks_Path : String; Uname : String) is
      T     : User_Table;
      B     : User_Name_Buffer := [others => 0];
      U_Len : Natural;
      F     : Boolean;
      Idx   : N32;
      OK    : Boolean;
      Owned : N32;
      Loaded: Boolean;
      --  the keystore is ~13 MB and lives for the whole command, so it is
      --  allocated on the heap here (admin.adb is not part of the
      --  SPARK-proved units) like the server does in main.adb.
      type Keystore_Ref is access Keystore;
      KS    : constant Keystore_Ref := new Keystore;
   begin
      U_Len := Name_To_Buf (Uname, B);
      if U_Len = 0 then
         Fatal ("invalid username '" & Uname & "'");
         return;
      end if;
      Load_All (Path, T, OK);
      if not OK then
         return;
      end if;
      Kms_Users.Find (T, B, N32 (U_Len), F, Idx);
      if not F then
         Fatal ("no such user: '" & Uname & "'");
         return;
      end if;
      --  missing/corrupt keystore == empty keystore, exactly like the
      --  server (Kms_File.Load overwrites KS with an empty table on
      --  failure), so the count is simply 0.
      Kms_File.Load (Ks_Path, KS.all, Loaded);
      if not Loaded then
         Ada.Text_IO.Put_Line
           ("user '" & Uname & "' owns 0 key(s) in " & Ks_Path &
            " (keystore missing or corrupt)");
         return;
      end if;
      Owned := Kms_Keystore.Count_Owned (KS.all, B, N32 (U_Len));
      Ada.Text_IO.Put_Line
        ("user '" & Uname & "' owns " & N32'Image (Owned) &
         " key(s) in " & Ks_Path);
   end Cmd_Count;

   --------------
   -- Cmd_List --
   --------------

   procedure Cmd_List (Path : String) is
      T     : User_Table;
      OK    : Boolean;
      N     : Natural := 0;
   begin
      Load_All (Path, T, OK);
      if not OK then
         return;
      end if;
      for I in T'Range loop
         if T (I).In_Use then
            Ada.Text_IO.Put_Line (Name_Text (T (I)));
            N := N + 1;
         end if;
      end loop;
      Ada.Text_IO.Put_Line (Natural'Image (N) & " account(s) in " & Path);
   end Cmd_List;

   ------------------
   -- Print_Usage --
   ------------------

   procedure Print_Usage is
   begin
      Ada.Text_IO.Put_Line
        ("usage: admin [-f <users-file>] add <user> <pass>");
      Ada.Text_IO.Put_Line
        ("       admin [-f <users-file>] remove <user>");
      Ada.Text_IO.Put_Line
        ("       admin [-f <users-file>] setpass <user> <pass>");
      Ada.Text_IO.Put_Line
        ("       admin [-f <users-file>] limit <user> <maxkeys>");
      Ada.Text_IO.Put_Line
        ("       admin [-f <users-file>] count <user> [<keystore-file>]");
      Ada.Text_IO.Put_Line
        ("       admin [-f <users-file>] list");
   end Print_Usage;

   Path    : String (1 .. 512) := [others => ASCII.NUL];
   Path_L  : Natural := 0;
   Command : Positive;

begin
   declare
      P : constant String := Users_Path (512);
   begin
      Path_L := P'Length;
      Path (1 .. Path_L) := P;
   end;

   --  optional leading -f <file>
   Command := 1;
   if Ada.Command_Line.Argument_Count >= 1 and then
      Ada.Command_Line.Argument (1) = "-f"
   then
      if Ada.Command_Line.Argument_Count < 2 then
         Print_Usage;
         Ada.Command_Line.Set_Exit_Status (1);
         return;
      end if;
      declare
         F : constant String := Ada.Command_Line.Argument (2);
      begin
         if F'Length = 0 or else F'Length > 512 then
            Fatal ("bad users file path");
            return;
         end if;
         Path (1 .. F'Length) := F;
         Path_L := F'Length;
      end;
      Command := 3;
   end if;

   if Ada.Command_Line.Argument_Count < Command then
      Print_Usage;
      Ada.Command_Line.Set_Exit_Status (1);
      return;
   end if;

   declare
      Cmd : constant String := Ada.Command_Line.Argument (Command);
   begin
      if Cmd = "add" then
         if Ada.Command_Line.Argument_Count /= Command + 2 then
            Print_Usage;
            Ada.Command_Line.Set_Exit_Status (1);
            return;
         end if;
         Cmd_Add (Path (1 .. Path_L),
                  Ada.Command_Line.Argument (Command + 1),
                  Ada.Command_Line.Argument (Command + 2));
      elsif Cmd = "remove" then
         if Ada.Command_Line.Argument_Count /= Command + 1 then
            Print_Usage;
            Ada.Command_Line.Set_Exit_Status (1);
            return;
         end if;
         Cmd_Remove (Path (1 .. Path_L),
                     Ada.Command_Line.Argument (Command + 1));
      elsif Cmd = "setpass" then
         if Ada.Command_Line.Argument_Count /= Command + 2 then
            Print_Usage;
            Ada.Command_Line.Set_Exit_Status (1);
            return;
         end if;
         Cmd_Setpass (Path (1 .. Path_L),
                      Ada.Command_Line.Argument (Command + 1),
                      Ada.Command_Line.Argument (Command + 2));
      elsif Cmd = "limit" then
         if Ada.Command_Line.Argument_Count /= Command + 2 then
            Print_Usage;
            Ada.Command_Line.Set_Exit_Status (1);
            return;
         end if;
         Cmd_Limit (Path (1 .. Path_L),
                    Ada.Command_Line.Argument (Command + 1),
                    Ada.Command_Line.Argument (Command + 2));
      elsif Cmd = "count" then
         --  count <user> [<keystore-file>]; keystore defaults to
         --  $ANONTONKEN_KEYSTORE else "keystore.bin" (like the server).
         if Ada.Command_Line.Argument_Count < Command + 1 or else
            Ada.Command_Line.Argument_Count > Command + 2
         then
            Print_Usage;
            Ada.Command_Line.Set_Exit_Status (1);
            return;
         end if;
         declare
            K_Str : String (1 .. 512) := [others => ASCII.NUL];
            K_Len : Natural := 0;
         begin
            if Ada.Command_Line.Argument_Count = Command + 2 then
               declare
                  K : constant String :=
                    Ada.Command_Line.Argument (Command + 2);
               begin
                  if K'Length = 0 or else K'Length > 507 then
                     Fatal ("bad keystore file path");
                     return;
                  end if;
                  K_Str (1 .. K'Length) := K;
                  K_Len := K'Length;
               end;
            else
               declare
                  P : constant String := Keystore_Path (512);
               begin
                  K_Len := P'Length;
                  K_Str (1 .. K_Len) := P;
               end;
            end if;
            Cmd_Count (Path (1 .. Path_L), K_Str (1 .. K_Len),
                       Ada.Command_Line.Argument (Command + 1));
         end;
      elsif Cmd = "list" then
         if Ada.Command_Line.Argument_Count /= Command then
            Print_Usage;
            Ada.Command_Line.Set_Exit_Status (1);
            return;
         end if;
         Cmd_List (Path (1 .. Path_L));
      else
         Print_Usage;
         Ada.Command_Line.Set_Exit_Status (1);
      end if;
   end;
end Admin;