------------------------------------------------------------------------------
--  Kms_Types : core types for the AnonToken key management server.
--
--  All types in this package are SPARK (Pure), 0-based to interoperate
--  directly with SPARKNaCl.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;

package Kms_Types
  with Pure,
       SPARK_Mode => On
is

   subtype Byte is Interfaces.Unsigned_8;
   subtype I32  is Interfaces.Integer_32;
   subtype N32  is I32 range 0 .. I32'Last;
   subtype I64  is Interfaces.Integer_64;
   subtype U64  is Interfaces.Unsigned_64;

   --  Unconstrained 0-based byte sequence (like SPARKNaCl.Byte_Seq).
   type Byte_Array is array (N32 range <>) of Byte;

   --  ------------------------------------------------------------------
   --  Ed25519 sizes (match SPARKNaCl.Sign)
   --  ------------------------------------------------------------------
   Public_Key_Length   : constant := 32;
   Secret_Key_Length   : constant := 64;  --  SPARKNaCl serialised secret key
   Signature_Length    : constant := 64;
   Seed_Length         : constant := 32;

   --  Maximum message length (bytes) accepted for signing.
   Max_Message_Length  : constant := 768;

   subtype Bytes_32         is Byte_Array (0 .. Public_Key_Length - 1);
   subtype Bytes_64         is Byte_Array (0 .. Secret_Key_Length - 1);
   subtype Signature_Bytes  is Byte_Array (0 .. Signature_Length - 1);
   subtype Seed_Bytes       is Byte_Array (0 .. Seed_Length - 1);
   subtype Message_Bytes    is Byte_Array (0 .. Max_Message_Length - 1);

   --  ------------------------------------------------------------------
   --  Account sizes (owner-managed account table)
   --  ------------------------------------------------------------------
   Max_Users          : constant := 128;   --  account slots (owner-managed)
   User_Name_Length   : constant := 24;    --  max username bytes
   Password_Length    : constant := 96;    --  max password bytes
   Digest_Length      : constant := 32;    --  PBKDF2-HMAC-SHA256 output

   --  PBKDF2 iteration count used to derive a password digest.  100 000
   --  rounds is the lowest current recommendation for PBKDF2-SHA256
   --  (OWASP guidance is 600k where affordable): it keeps one derivation
   --  around tens of ms on a Pi while making offline cracking of a leaked
   --  users file 10x more expensive than the original 10 000 rounds.
   Pbkdf2_Iterations : constant := 100_000;

   --  ------------------------------------------------------------------
   --  Per-key TTL bounds
   --  ------------------------------------------------------------------
   --  A key's TTL is chosen per key at creation and counts from the first
   --  activation.  The ceiling is 30 years - long enough for any
   --  commercial licence (on-premise, white-label, perpetual-with-support)
   --  while keeping every key self-purging: an unbounded TTL would let an
   --  attacker create keys that never expire, permanently occupying
   --  keystore slots (a storage-exhaustion DoS).  With a finite TTL the
   --  keystore is always drained by Kms_Keystore.Expire.
   Max_Ttl_Seconds : constant := 30 * 365 * 86_400;   --  30 years
   Max_Ttl_Minutes : constant := Max_Ttl_Seconds / 60;

   subtype User_Name_Buffer is Byte_Array (0 .. User_Name_Length - 1);
   subtype Password_Buffer is Byte_Array (0 .. Password_Length - 1);
   subtype Digest_Bytes   is Byte_Array (0 .. Digest_Length - 1);

   --  ------------------------------------------------------------------
   --  Key identity and status
   --  ------------------------------------------------------------------
   Key_Id_Length : constant := 8;         --  64-bit identifier
   type Key_Id is mod 2 ** 64;

   type Key_Status is (Active, Expired, Revoked);

   --  ------------------------------------------------------------------
   --  Keystore
   --  ------------------------------------------------------------------
   --  65,536 slots: effectively unlimited (activated keys are purged
   --  automatically once past their deadline, so this bounds concurrent
   --  live keys).
   Max_Keys : constant := 65_536;
   subtype Key_Index is N32 range 0 .. Max_Keys - 1;

   --  GET /keys returns at most this many entries (keeps responses small).
   List_Cap : constant := 1000;

   --  Activation-secret length: 32 random bytes, returned exactly once at
   --  key creation (as base64) to the developer, who passes it to the end
   --  customer's software for phone-home checks.
   Activation_Length : constant := 32;
   subtype Activation_Bytes is Byte_Array (0 .. Activation_Length - 1);

   --  One keystore slot.  Semantics of the lifetime fields:
   --    * Created_At    : unix seconds when the key was created.
   --    * Activated_At  : 0 until the first successful phone-home check;
   --                      then the moment the TTL started counting.
   --    * Expires_At    : 0 until activation (an unused key never dies);
   --                      after activation = Activated_At + Ttl_Secs.
   --    * Ttl_Secs      : per-key lifetime chosen at creation, counted
   --                      from activation, not from creation.
   --    * Owner         : username (Owner_Len bytes) of the developer
   --                      account that created the key; all management
   --                      endpoints are scoped to it.
   --    * Secret        : the activation secret.  Stored alongside the
   --                      Ed25519 secret key (the keystore file already
   --                      holds private keys, so this adds no exposure).
   type Key_Record is record
      In_Use      : Boolean            := False;
      Id          : Key_Id             := 0;
      Owner_Len   : N32 range 0 .. User_Name_Length := 0;
      Owner       : User_Name_Buffer   := [others => 0];
      Pub         : Bytes_32           := [others => 0];
      Sec         : Bytes_64           := [others => 0];
      Secret      : Activation_Bytes   := [others => 0];
      Created_At  : I64                := 0;   --  unix seconds
      Activated_At: I64                := 0;   --  0 = not yet activated
      Expires_At  : I64                := 0;   --  0 = no deadline yet
      Ttl_Secs    : I64                := 0;   --  lifetime from activation
      Status      : Key_Status         := Revoked;
   end record;

   type Keystore is array (Key_Index) of Key_Record;

   --  ------------------------------------------------------------------
   --  HTTP / JSON limits
   --  ------------------------------------------------------------------
   Max_Request_Length  : constant := 4096;  --  total HTTP request size
   Max_Body_Length     : constant := 2048;  --  request body size
   Max_Response_Length : constant := 120_000;  --  response size (list cap * 110)

   subtype Request_Buffer  is Byte_Array (0 .. Max_Request_Length - 1);
   subtype Body_Buffer     is Byte_Array (0 .. Max_Body_Length - 1);
   subtype Response_Buffer is Byte_Array (0 .. Max_Response_Length - 1);

   --  Base64 buffer big enough for the largest message (768 -> 1024 chars,
   --  padded to a multiple of 4).
   Max_Base64_Length : constant := 1028;
   subtype Base64_Buffer is Byte_Array (0 .. Max_Base64_Length - 1);

   --  Small string buffers used for JSON values.
   Max_Short_Length : constant := 128;
   subtype Short_Buffer is Byte_Array (0 .. Max_Short_Length - 1);

   --  ------------------------------------------------------------------
   --  Accounts (owner-managed, enforced via HTTP Basic Auth)
   --  ------------------------------------------------------------------
   --  The owner creates developer accounts with the separate ``admin``
   --  tool; every API request (except /health and /keys/<id>/check) must
   --  present a valid username/password.  Passwords are never stored:
   --  only a salted PBKDF2-HMAC-SHA256 digest (derived by the
   --  SPARK-proven Kms_Passwd) plus the random salt.

   --  One account slot.  Key_Limit is the maximum number of keys the
   --  account may hold at once (every key still occupying a keystore
   --  slot counts, whatever its status); 0 means unlimited, which is
   --  also what accounts loaded from a v1 users file get.
   type User_Record is record
      In_Use    : Boolean                                  := False;
      Name_Len  : N32 range 0 .. User_Name_Length          := 0;
      Name      : User_Name_Buffer                         := [others => 0];
      Salt      : Digest_Bytes                             := [others => 0];
      Hash      : Digest_Bytes                             := [others => 0];
      Key_Limit : N32 range 0 .. Max_Keys                  := 0;   --  0 = unlimited
   end record;

   type User_Table is array (N32 range 0 .. Max_Users - 1) of User_Record;

   --  Everything after "Basic " in an Authorization header - the base64 of
   --  "user:pass".  Largest legal value: 4 * ceil((24 + 1 + 96)/3) = 164.
   Max_Auth_Length : constant := 192;
   subtype Auth_Buffer is Byte_Array (0 .. Max_Auth_Length - 1);

end Kms_Types;
