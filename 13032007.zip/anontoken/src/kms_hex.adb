package body Kms_Hex
  with SPARK_Mode => On
is

   ---------------
   -- Is_Hex_Digit --
   ---------------

   function Is_Hex_Digit (C : Byte) return Boolean is
   begin
      return (C in Character'Pos ('0') .. Character'Pos ('9')) or else
             (C in Character'Pos ('a') .. Character'Pos ('f')) or else
             (C in Character'Pos ('A') .. Character'Pos ('F'));
   end Is_Hex_Digit;

   --------------
   -- Hex_Value --
   --------------

   function Hex_Value (C : Byte) return Natural is
     (if C in 48 .. 57 then Natural (C) - 48
      elsif C in 97 .. 102 then Natural (C) - 97 + 10
      else Natural (C) - 65 + 10);

   ------------------
   -- Nibble_To_Char --
   ------------------

   function Nibble_To_Char (V : Natural) return Byte is
   begin
      if V <= 9 then
         return Byte (Character'Pos ('0') + V);
      else
         return Byte (Character'Pos ('a') + V - 10);
      end if;
   end Nibble_To_Char;

   ------------
   -- To_Hex --
   ------------

   function To_Hex (Id : Key_Id) return Hex_Buffer is
      Result : Hex_Buffer := [others => 0];
   begin
      for I in Hex_Buffer'Range loop
         --  Most significant nibble first: bit positions 4*(15-I) .. +3.
         --  Use Shift_Right so the divisor is never zero and no exponentiation
         --  (16 ** 8 would overflow a 32-bit Natural) is involved.
         Result (I) := Nibble_To_Char
           (Natural (Shift_Right (Unsigned_64 (Id),
                                  Natural (4 * (Hex_Buffer'Last - I)))
                     mod 16));
         pragma Loop_Invariant
           (for all J in Hex_Buffer'First .. I =>
              Result (J) = Nibble_To_Char
                (Natural (Shift_Right
                   (Unsigned_64 (Id),
                    Natural (4 * (Hex_Buffer'Last - J)))
                   mod 16)));
      end loop;
      return Result;
   end To_Hex;

   ---------------
   -- From_Hex --
   ---------------

   procedure From_Hex (S     : in  Hex_Buffer;
                       Valid : out Boolean;
                       Id    : out Key_Id) is
      Acc : Key_Id := 0;
      Ok  : Boolean := True;
   begin
      for I in S'Range loop
         if S (I) in 48 .. 57 or S (I) in 97 .. 102 or S (I) in 65 .. 70 then
            Acc := Acc * 16 + Key_Id (Hex_Value (S (I)));
         else
            Ok := False;
         end if;
         pragma Loop_Invariant
           ((for all J in S'First .. I =>
               (S (J) in 48 .. 57 or S (J) in 97 .. 102 or
                S (J) in 65 .. 70)) or else not Ok);
         pragma Loop_Invariant
           (Ok = (for all J in S'First .. I =>
                    S (J) in 48 .. 57 or S (J) in 97 .. 102 or
                    S (J) in 65 .. 70));
      end loop;
      Valid := Ok;
      Id    := Acc;
   end From_Hex;

end Kms_Hex;