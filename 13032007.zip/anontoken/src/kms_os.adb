------------------------------------------------------------------------------
--  Kms_Os implementation.  All low-level libc calls are imported directly
--  from the C shim (see the package spec); this body only contains the
--  pure helpers: entropy filling, path building, logging, and sockaddr
--  construction.  No 'Address attribute is used, so the whole unit is
--  provable by gnatprove at level 4.
------------------------------------------------------------------------------

package body Kms_Os
  with SPARK_Mode => On
is

   -----------------
   -- Random_Bytes --
   -----------------

   procedure Random_Bytes (Buf : out Seed_Bytes;
                           OK  :    out Boolean) is
      Tmp : Seed_Bytes := [others => 0];
      Rc  : C_Bool;
   begin
      C_Getrandom (Tmp, C_Size (Tmp'Length), Rc);
      OK  := C_Bool'Pos (Rc) /= 0;  --  shim returns 1 on success
      Buf := Tmp;
   end Random_Bytes;

   --------------
   -- Fill_*  --
   --------------

   procedure Fill_Path (Dst :    out Path_Buf;
                        Src : in     String)
   is
      N : N32;
   begin
      Dst := [others => 0];
      N := N32 (Src'Length);
      for J in 0 .. N - 1 loop
         Dst (J) := Byte (Character'Pos (Src (Src'First + Natural (J))));
      end loop;
      Dst (N) := 0;   --  NUL terminator
   end Fill_Path;

   procedure Fill_Path2 (Dst  :    out Path_Buf;
                         Src  : in     String;
                         Suf  : in     String)
   is
      N  : N32;
      NS : N32;
   begin
      Dst := [others => 0];
      N  := N32 (Src'Length);
      NS := N32 (Suf'Length);
      for J in 0 .. N - 1 loop
         Dst (J) := Byte (Character'Pos (Src (Src'First + Natural (J))));
      end loop;
      for J in 0 .. NS - 1 loop
         Dst (N + J) := Byte (Character'Pos (Suf (Suf'First + Natural (J))));
      end loop;
      Dst (N + NS) := 0;   --  NUL terminator
   end Fill_Path2;

   ------------
   -- Log    --
   ------------

   procedure Log (S : in String) is
      B : Chunk := [others => 0];
      N : N32 := 0;
      R : C_SSize;
   begin
      for J in 0 .. N32 (S'Length) - 1 loop
         exit when J >= N32 (B'Length);
         B (J) := Byte (Character'Pos (S (S'First + Natural (J))));
         N := J + 1;
      end loop;
      if N > 0 then
         C_Write (2, B, C_Size (Natural (N)), R);
      end if;
   end Log;

   -------------------
   -- Build_Sockaddr --
   -------------------

   procedure Build_Sockaddr (Bind_Str : in     String;
                             Port     : in     Positive;
                             A        :    out Sock_Addr;
                             OK       :    out Boolean)
   is
      --  Parse "a.b.c.d" into four octets.  B (1 .. 4) receive them.
      --  V is clamped to 256 so arithmetic never overflows; N is bounded
      --  by the dot count so index checks are trivial.
      B     : array (1 .. 4) of Natural := [others => 0];
      N     : Natural := 1;     --  current octet index (1 .. 5)
      V     : Natural := 0;     --  current octet value, clamped to 256
      Have  : Boolean := False;
      Valid : Boolean := True;
   begin
      A := [others => 0];
      for I in Bind_Str'Range loop
         pragma Loop_Invariant (N >= 1 and then N <= 5);
         pragma Loop_Invariant (V <= 256);
         pragma Loop_Invariant
           (for all K in 1 .. N - 1 => B (K) <= 255);
         declare
            C : constant Character := Bind_Str (I);
         begin
            if C in '0' .. '9' then
               if V <= 255 then
                  V := V * 10 + Character'Pos (C) - Character'Pos ('0');
                  if V > 255 then
                     V := 256;   --  clamp: mark overflow without overflowing
                  end if;
               end if;
               Have := True;
            elsif C = '.' then
               if (not Have) or else V > 255 then
                  Valid := False;
               else
                  if N <= 4 then
                     B (N) := V;
                     N := N + 1;
                  end if;
                  V      := 0;
                  Have   := False;
               end if;
            else
               Valid := False;
            end if;
         end;
      end loop;
      if (not Have) or else V > 255 then
         Valid := False;
      elsif N <= 4 then
         B (N) := V;
      end if;

      OK := Valid and then N = 4;
      if OK then
         --  family AF_INET (2):  u16 little-endian
         A (0) := 2;
         A (1) := 0;
         --  port:  u16 big-endian (network byte order)
         A (2) := Byte (Port / 256);
         A (3) := Byte (Port mod 256);
         --  address:  4 octets in network (big-endian) order
         A (4) := Byte (B (1));
         A (5) := Byte (B (2));
         A (6) := Byte (B (3));
         A (7) := Byte (B (4));
      end if;
   end Build_Sockaddr;

end Kms_Os;