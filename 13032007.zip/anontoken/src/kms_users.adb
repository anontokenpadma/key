package body Kms_Users
  with SPARK_Mode => On
is

   ----------
   -- Init --
   ----------

   procedure Init (T : in out User_Table) is
   begin
      for I in T'Range loop
         T (I) := (In_Use => False, others => <>);
         pragma Loop_Invariant
           (for all J in T'First .. I => not T (J).In_Use);
      end loop;
   end Init;

   -----------
   -- Count --
   -----------

   function Count (T : User_Table) return N32 is
      N : N32 := 0;
   begin
      for I in T'Range loop
         if T (I).In_Use then
            N := N + 1;
         end if;
         pragma Loop_Invariant (N <= I - T'First + 1);
      end loop;
      return N;
   end Count;

   -------------
   -- Has_Free --
   -------------

   function Has_Free (T : User_Table) return Boolean is
   begin
      for I in T'Range loop
         if not T (I).In_Use then
            return True;
         end if;
         pragma Loop_Invariant
           (for all J in T'First .. I => T (J).In_Use);
      end loop;
      return False;
   end Has_Free;

   ----------
   -- Find --
   ----------

   procedure Find (T        : in     User_Table;
                   Name     : in     User_Name_Buffer;
                   Name_Len : in     N32;
                   Found    :    out Boolean;
                   Idx      :    out N32) is
      Equal : Boolean;
   begin
      Found := False;
      Idx   := 0;
      for I in T'Range loop
         if T (I).In_Use and then T (I).Name_Len = Name_Len then
            Equal := True;
            for J in 0 .. Name_Len - 1 loop
               if T (I).Name (J) /= Name (J) then
                  Equal := False;
               end if;
               pragma Loop_Invariant
                 (Equal = (for all K in 0 .. J =>
                             T (I).Name (K) = Name (K)));
            end loop;
            if Equal then
               Found := True;
               Idx   := I;
               return;
            end if;
         end if;
         pragma Loop_Invariant (not Found);
      end loop;
   end Find;

   ---------
   -- Get --
   ---------

   procedure Get (T   : in     User_Table;
                  Idx : in     N32;
                  Rec :    out User_Record) is
   begin
      Rec := T (Idx);
   end Get;

   ---------
   -- Add --
   ---------

   procedure Add (T     : in out User_Table;
                  Rec   : in     User_Record;
                  Added :    out Boolean) is
      F : Boolean;
      I : N32;
   begin
      Find (T, Rec.Name, Rec.Name_Len, F, I);
      pragma Unreferenced (I);  --  only the hit flag matters here
      if F then
         Added := False;
         return;
      end if;
      for I2 in T'Range loop
         if not T (I2).In_Use then
            T (I2) := Rec;
            Added  := True;
            return;
         end if;
         pragma Loop_Invariant
           (for all J in T'First .. I2 => T (J).In_Use);
      end loop;
      Added := False;
   end Add;

   ------------
   -- Remove --
   ------------

   procedure Remove (T   : in out User_Table;
                     Idx : in     N32) is
   begin
      T (Idx) := (In_Use => False, others => <>);
   end Remove;

   ------------
   -- Verify --
   ------------

   procedure Verify (Stored    : in Digest_Bytes;
                     Presented : in Digest_Bytes;
                     Ok        : out Boolean) is
      Diff : Byte := 0;
   begin
      for I in Digest_Bytes'Range loop
         Diff := Diff or (Stored (I) xor Presented (I));
         pragma Loop_Invariant
           ((Diff = 0) = (for all J in Digest_Bytes'First .. I =>
                              Stored (J) = Presented (J)));
      end loop;
      Ok := Diff = 0;
   end Verify;

end Kms_Users;