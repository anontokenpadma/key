------------------------------------------------------------------------------
--  anontoken : SPARK-proven Ed25519 key management server.
--
--  Usage: anontoken [bind-address] [port] [keystore-file] [lifetime-days]
--                    [users-file]
--
--  Defaults come from the environment (when set), else the built-in defaults:
--      ANONTONKEN_BIND_ADDR       bind address     (default 127.0.0.1)
--      ANONTONKEN_PORT            listen port      (default 9999)
--      ANONTONKEN_KEYSTORE        keystore file    (default keystore.bin)
--      ANONTONKEN_LIFETIME_DAYS   default lifetime (default 90)
--      ANONTONKEN_USERS           users file       (default: none =
--                                    every API request is rejected with
--                                    401 until accounts are created with
--                                    the admin tool)
--  Command-line arguments override the environment.
------------------------------------------------------------------------------

with Ada.Command_Line;
with Ada.Environment_Variables;
with Ada.Text_IO;
with Interfaces;
with Kms_Server;
with Kms_Types;
use  Interfaces;
use  Kms_Server;
use  Kms_Types;

procedure Main is

   Cfg : Kms_Server.Config;

   ------------
   -- Env_Value --
   ------------
   --  Return the value of environment variable Name, or "" if unset.

   function Env_Value (Name : String) return String is
   begin
      return Ada.Environment_Variables.Value (Name);
   exception
      when Constraint_Error =>
         return "";
   end Env_Value;

   --------------
   -- Bad_Usage --
   --------------

   procedure Bad_Usage (Msg : String) is
   begin
      Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, "anontoken: " & Msg);
      Ada.Text_IO.Put_Line
        (Ada.Text_IO.Standard_Error,
         "usage: anontoken [bind-address] [port] [keystore-file]" &
         " [lifetime-days] [users-file]");
   end Bad_Usage;

   --------------
   -- Read_Port --
   --------------
   --  Parse S as a port (1..65535) into Cfg.Port.  Reports an error and
   --  returns False so the caller can stop.

   function Read_Port (S : String; What : String) return Boolean is
      V : Positive := 1;
   begin
      V := Positive'Value (S);
      if V > 65_535 then
         Bad_Usage ("bad " & What & ": " & S & " (must be 1..65535)");
         return False;
      end if;
      Cfg.Port := Port_Number (V);
      return True;
   exception
      when Constraint_Error =>
         Bad_Usage ("bad " & What & ": " & S);
         return False;
   end Read_Port;

begin
   Cfg := (others => <>);
   Cfg.Bind_Address (1 .. 9) := "127.0.0.1";
   Cfg.Keystore_Path (1 .. 12) := "keystore.bin";
   Cfg.Path_Len := 12;

   --  environment-driven defaults (command-line arguments override these)
   declare
      E : constant String := Env_Value ("ANONTONKEN_BIND_ADDR");
   begin
      if E'Length > 0 then
         if E'Length > 128 then
            Bad_Usage ("bad ANONTONKEN_BIND_ADDR");
            return;
         end if;
         Cfg.Bind_Address (1 .. E'Length) := E;
         Cfg.Bind_Len := E'Length;
      end if;
   end;

   declare
      E : constant String := Env_Value ("ANONTONKEN_PORT");
   begin
      if E'Length > 0 and then not Read_Port (E, "ANONTONKEN_PORT") then
         return;
      end if;
   end;

   declare
      E : constant String := Env_Value ("ANONTONKEN_KEYSTORE");
   begin
      if E'Length > 0 then
         if E'Length > 507 then
            Bad_Usage ("bad ANONTONKEN_KEYSTORE");
            return;
         end if;
         Cfg.Keystore_Path (1 .. E'Length) := E;
         Cfg.Path_Len := E'Length;
      end if;
   end;

   declare
      E : constant String := Env_Value ("ANONTONKEN_LIFETIME_DAYS");
   begin
      if E'Length > 0 then
         begin
            Cfg.Lifetime_Days := Kms_Types.I64'Value (E);
            if Cfg.Lifetime_Days < 1 then
               Cfg.Lifetime_Days := 1;
            elsif Cfg.Lifetime_Days > 3650 then
               Cfg.Lifetime_Days := 3650;
            end if;
         exception
            when Constraint_Error =>
               Bad_Usage ("bad ANONTONKEN_LIFETIME_DAYS: " & E);
               return;
         end;
      end if;
   end;

   declare
      E : constant String := Env_Value ("ANONTONKEN_USERS");
   begin
      if E'Length > 0 then
         if E'Length > 507 then
            Bad_Usage ("bad ANONTONKEN_USERS");
            return;
         end if;
         Cfg.Users_Path (1 .. E'Length) := E;
         Cfg.Users_Len := E'Length;
      end if;
   end;

   if Ada.Command_Line.Argument_Count >= 1 then
      declare
         S : constant String := Ada.Command_Line.Argument (1);
      begin
         if S'Length = 0 or else S'Length > 128 then
            Bad_Usage ("bad bind address");
            return;
         end if;
         Cfg.Bind_Address (1 .. S'Length) := S;
         Cfg.Bind_Len := S'Length;
      end;
   end if;

   if Ada.Command_Line.Argument_Count >= 2 then
      declare
         S : constant String := Ada.Command_Line.Argument (2);
      begin
         if not Read_Port (S, "port") then
            return;
         end if;
      end;
   end if;

   if Ada.Command_Line.Argument_Count >= 3 then
      declare
         S : constant String := Ada.Command_Line.Argument (3);
      begin
         if S'Length = 0 or else S'Length > 507 then
            Bad_Usage ("bad keystore path");
            return;
         end if;
         Cfg.Keystore_Path (1 .. S'Length) := S;
         Cfg.Path_Len := S'Length;
      end;
   end if;

   if Ada.Command_Line.Argument_Count >= 4 then
      declare
         S : constant String := Ada.Command_Line.Argument (4);
      begin
         Cfg.Lifetime_Days := Kms_Types.I64'Value (S);
         if Cfg.Lifetime_Days < 1 then
            Cfg.Lifetime_Days := 1;
         elsif Cfg.Lifetime_Days > 3650 then
            Cfg.Lifetime_Days := 3650;
         end if;
      exception
         when others =>
            Bad_Usage ("bad lifetime: " & S);
            return;
      end;
   end if;

   if Ada.Command_Line.Argument_Count >= 5 then
      declare
         S : constant String := Ada.Command_Line.Argument (5);
      begin
         if S'Length = 0 or else S'Length > 507 then
            Bad_Usage ("bad users file path");
            return;
         end if;
         Cfg.Users_Path (1 .. S'Length) := S;
         Cfg.Users_Len := S'Length;
      end;
   end if;

   declare
      --  The keystore is ~13 MB and lives for the whole server lifetime,
      --  so it is allocated on the heap here (main.adb is not part of
      --  the SPARK-proved units) and passed to Kms_Server.Run, which
      --  stays free of access types.
      type Keystore_Ref is access Keystore;
      KS : constant Keystore_Ref := new Keystore;
   begin
      Kms_Server.Run (Cfg, KS.all);
   end;
end Main;