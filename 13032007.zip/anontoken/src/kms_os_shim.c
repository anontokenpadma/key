/*------------------------------------------------------------------------------
 *  Kms_Os_Shim : minimal C syscall glue for the SPARK Kms_Os boundary.
 *
 *  The Ada package Kms_Os (SPARK_Mode => On) imports these procedures
 *  directly with Convention => C.  Buffers are passed by reference
 *  (GNAT array parameters), results are returned through an explicit
 *  output scalar (GNAT passes out scalars by reference under C
 *  convention).  No 'Address attribute is needed anywhere in Ada.
 *
 *  This file deliberately contains no logic: it forwards each call to the
 *  corresponding operating-system primitive and stores the raw result.
 *
 *  Single supported platform: POSIX/Linux (getrandom, accept4, POSIX
 *  sockets, fd semantics).  Every libc entry point used by Ada
 *  (open/close/rename/unlink/access/socket/bind/listen) goes through a
 *  kms_* wrapper defined here, so the same SPARK code compiles for both
 *  native and cross (aarch64) targets without conditional Ada code.
 *---------------------------------------------------------------------------*/

#define _GNU_SOURCE
#include <stddef.h>
#include <stdint.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/random.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

/*  read(fd, buf, count) -> bytes read / 0 EOF / -1 error  */
void kms_read(int fd, unsigned char *buf, size_t count, int64_t *res)
{
    ssize_t r = read(fd, buf, count);
    *res = (int64_t)r;
}

/*  write(fd, buf, count) -> bytes written / -1 error  */
void kms_write(int fd, const unsigned char *buf, size_t count, int64_t *res)
{
    ssize_t r = write(fd, buf, count);
    *res = (int64_t)r;
}

/*  open(path, flags, mode) -> fd >= 0 or -1  */
int kms_open(const unsigned char *path, int flags, int mode)
{
    return open((const char *)path, flags, mode);
}

int kms_close(int fd)
{
    return close(fd);
}

int kms_rename(const unsigned char *oldp, const unsigned char *newp)
{
    return rename((const char *)oldp, (const char *)newp);
}

int kms_unlink(const unsigned char *path)
{
    return unlink((const char *)path);
}

int kms_access(const unsigned char *path, int mode)
{
    return access((const char *)path, mode);
}

int kms_socket(int domain, int kind, int protocol)
{
    return socket(domain, kind, protocol);
}

int kms_bind(int fd, const unsigned char *addr, int len)
{
    return bind(fd, (const struct sockaddr *)addr, (socklen_t)len);
}

int kms_listen(int fd, int backlog)
{
    return listen(fd, backlog);
}

/*  recv(fd, buf, len, 0) -> bytes read / 0 EOF / -1 error  */
void kms_recv(int fd, unsigned char *buf, size_t len, int64_t *res)
{
    ssize_t r = recv(fd, buf, len, 0);
    *res = (int64_t)r;
}

/*  send(fd, buf, len, 0) -> bytes sent / -1 error  */
void kms_send(int fd, const unsigned char *buf, size_t len, int64_t *res)
{
    ssize_t r = send(fd, buf, len, 0);
    *res = (int64_t)r;
}

/*  accept4(fd, NULL, NULL, 0) -> client fd / -1 error  */
void kms_accept(int fd, int *client)
{
    *client = accept4(fd, NULL, NULL, 0);
}

/*  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &1, 4) -> ok = 1 / 0.  */
int kms_setsockopt_reuse(int fd)
{
    int one = 1;
    int r = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    return (r == 0) ? 1 : 0;
}

/*  time(NULL) -> seconds since the epoch  */
int64_t kms_time(void)
{
    return (int64_t)time(NULL);
}

/*  getrandom(buf, len, 0); retries on EINTR, fills the whole buffer.
 *  *ok = 1 on success, 0 when the kernel refused (fail-closed on the Ada
 *  side: the caller must never use buf when *ok == 0).
 */
void kms_getrandom(unsigned char *buf, size_t len, char *ok)
{
    for (;;) {
        ssize_t r = getrandom(buf, len, 0);
        if (r == (ssize_t)len) {
            *ok = 1;
            return;
        }
        if (r < 0 && errno == EINTR)
            continue;
        if (r < 0) {
            *ok = 0;                /*  kernel refused  */
            return;
        }
        buf += (size_t)r;
        len -= (size_t)r;
    }
}