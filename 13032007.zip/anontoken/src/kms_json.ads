------------------------------------------------------------------------------
--  Kms_Json : minimal JSON object builder and field lookup.
--  Only the subset needed by the HTTP API is supported.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Json
  with SPARK_Mode => On
is

   --  Append one byte at Pos and advance Pos.
   procedure Append (Buf : in out Byte_Array;
                     Pos : in out N32;
                     C   : in     Byte)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos < Buf'Length,
          Post => Pos = Pos'Old + 1;

   --  Append raw ASCII text (no quoting, no escaping).
   procedure Append_Text (Buf : in out Byte_Array;
                          Pos : in out N32;
                          S   : in     String)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  S'Length <= Max_Short_Length and then
                  Pos <= Buf'Length and then
                  Pos + S'Length <= Buf'Length,
          Post => Pos = Pos'Old + S'Length;

   --  Append "\"" S "\"" where S is an ASCII byte array (0-based).
   --  '"' and '\' inside S are escaped (so the worst case needs 2x+2).
   procedure Append_Quoted (Buf : in out Byte_Array;
                            Pos : in out N32;
                            S   : in     Byte_Array)
     with Global => null,
          Pre  => Buf'First = 0 and then S'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  S'Length <= Max_Short_Length and then
                  Pos <= Buf'Length and then
                  Pos + 2 * S'Length + 2 <= Buf'Length,
          Post => Pos >= Pos'Old + S'Length + 1 and then
                  Pos <= Pos'Old + 2 * S'Length + 2;

   --  Same, but for an Ada String (no escaping; the callers only pass
   --  plain ASCII like JSON keys and status names).
   procedure Append_Quoted_Text (Buf : in out Byte_Array;
                                 Pos : in out N32;
                                 S   : in     String)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  S'Length <= Max_Short_Length and then
                  Pos <= Buf'Length and then
                  Pos + S'Length + 2 <= Buf'Length,
          Post => Pos = Pos'Old + S'Length + 2;

   --  16-character hex string (a base-16 key id).
   subtype Hex_Word is Byte_Array (0 .. 2 * Key_Id_Length - 1);

   --  Append "\"" H "\"" where H is a fixed-length hex string (16 ASCII
   --  chars, e.g. a key id).  Hex characters never need escaping, so the
   --  postcondition is exact - this keeps the per-entry size bound of the
   --  /keys list loop tight enough to prove.
   procedure Append_Quoted_Hex (Buf : in out Byte_Array;
                                Pos : in out N32;
                                H   : in     Hex_Word)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos <= Buf'Length and then
                  Pos + 2 * Key_Id_Length + 2 <= Buf'Length,
          Post => Pos = Pos'Old + 2 * Key_Id_Length + 2;

   --  Append the decimal representation of an unsigned 64-bit value.
   procedure Append_U64 (Buf : in out Byte_Array;
                         Pos : in out N32;
                         V   : in     U64)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos <= Buf'Length and then
                  Pos + 20 <= Buf'Length,
          Post => Pos > Pos'Old and then Pos <= Pos'Old + 20;

   --  Append "true" or "false".
   procedure Append_Bool (Buf : in out Byte_Array;
                          Pos : in out N32;
                          B   : in     Boolean)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos <= Buf'Length and then
                  Pos + 5 <= Buf'Length,
          Post => Pos > Pos'Old and then Pos <= Pos'Old + 5;

   --  Look up the string value of Key inside a flat JSON object stored in
   --  Data (0 .. Len-1).  Pattern searched:  "key" :  "value".
   --  Found is False when the key is absent or its value is malformed or
   --  longer than Val'Length.
   procedure Find_String (Data    : in  Byte_Array;
                          Len     : in  N32;
                          Key     : in  String;
                          Found   : out Boolean;
                          Val     : out Byte_Array;
                          Val_Len : out N32)
     with Global => null,
          Pre  => Data'First = 0 and then
                  Data'Length <= Max_Request_Length and then
                  Len <= Data'Length and then
                  Key'Length <= Max_Short_Length and then
                  Val'First = 0 and then
                  Val'Length <= Max_Response_Length,
          Post => (if not Found then Val_Len = 0) and then
                  Val_Len <= Val'Length;

   --  Look up the unsigned integer value of Key.  Pattern searched:
   --  "key" :  <digits>.  Found is False when the key is absent, its value
   --  is not a plain decimal number, or the number overflows U64.
   procedure Find_U64 (Data    : in  Byte_Array;
                       Len     : in  N32;
                       Key     : in  String;
                       Found   : out Boolean;
                       Value   : out U64)
     with Global => null,
          Pre  => Data'First = 0 and then
                  Data'Length <= Max_Request_Length and then
                  Len <= Data'Length and then
                  Key'Length <= Max_Short_Length,
          Post => (if not Found then Value = 0);

   --  True iff Key appears as a top-level member name of a validated
   --  flat object (pattern  "key" :  with optional whitespace around the
   --  colon).  Only meaningful on bodies that already passed
   --  Validate_Flat_Object; there the ``"key"`` bytes can only occur at
   --  a real member boundary, so this is exact.  Used to distinguish
   --  "field absent" from "field present but not a valid <type>" so a
   --  malformed value is rejected loudly instead of silently defaulting.
   function Field_Present (Data : in Byte_Array;
                           Len  : in N32;
                           Key  : in String) return Boolean
     with Global => null,
          Pre  => Data'First = 0 and then
                  Data'Length <= Max_Request_Length and then
                  Len <= Data'Length and then
                  Key'Length >= 1 and then
                  Key'Length <= Max_Short_Length;

   --  Strict structural validation of a request body: True iff Data
   --  (0 .. Len-1) is exactly one flat JSON object
   --
   --     { "key": value, ... }
   --
   --  with these rules (a deliberately strict subset of RFC 8259, exactly
   --  the shape this API's endpoints consume):
   --    * optional ASCII whitespace (space / tab / LF / CR) between tokens
   --      and around the whole object;
   --    * keys are non-empty quoted strings of printable ASCII (no
   --      backslash escapes - the API's keys never need them);
   --    * values are quoted printable-ASCII strings, integers (optional
   --      leading '-', then one or more digits - no floats, no exponents),
   --      or the literals true / false / null;
   --    * no nested objects or arrays as values;
   --    * members separated by ','; the object closes with '}' and NOTHING
   --      may follow it except whitespace (no trailing junk);
   --    * duplicate member names are allowed (the lookup below
   --      deterministically uses the first occurrence - see Find_String).
   --
   --  This turns the old lenient substring scanning into a gated one: an
   --  endpoint only runs Find_String/Find_U64 on bodies that already
   --  passed this check, so the ``"key":`` pattern can only ever match a
   --  real top-level member (string values cannot contain quotes or
   --  backslashes by construction) and malformed numbers like ``5x`` are
   --  rejected up front instead of being read as ``5``.
   procedure Validate_Flat_Object (Data  : in  Byte_Array;
                                   Len   : in  N32;
                                   Valid :    out Boolean)
     with Global => null,
          Pre  => Data'First = 0 and then
                  Data'Length <= Max_Request_Length and then
                  Len <= Data'Length,
          Post => (if Len = 0 then not Valid);

end Kms_Json;
