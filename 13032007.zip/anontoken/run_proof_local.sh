#!/usr/bin/env bash
# Clean level-4 proof of every unit in the project, from scratch.
# Adapted from run_proof_final.sh for the current machine layout.
# Usage: launch in background + monitor: tail -f /tmp/proof_local.log
cd "$(dirname "$0")"
export PATH="$HOME/.alire/bin:$HOME/.alire/libexec/spark/bin:$HOME/.local/share/alire/toolchains/gnat_native_16.1.0_9f74f58a/bin:$HOME/.local/share/alire/toolchains/gprbuild_26.0.1_e3f27f25/bin:$PATH"
export GPR_PROJECT_PATH="$(pwd)/libs/sparknacl"
LOG=/tmp/proof_local.log
: > "$LOG"
rm -rf obj/gnatprove libs/sparknacl/obj/gnatprove
for u in kms_os kms_file kms_server kms_base64 kms_hex kms_json \
         kms_keystore kms_signer kms_users kms_passwd kms_http; do
  echo "=== $u start $(date +%H:%M:%S) ===" >> "$LOG"
  timeout 7200 gnatprove -P anontoken.gpr --level=4 -j23 --report=all \
      --prover=z3,cvc5,altergo --timeout=120 --steps=400000 --no-inlining \
      -f -u "$u" >> "$LOG" 2>&1
  echo "rc=$? end $(date +%H:%M:%S)" >> "$LOG"
done
echo "=== ALL_DONE $(date +%H:%M:%S) ===" >> "$LOG"