# AnonToken — Cross-build binaries

Two standalone binaries cross-compiled from the **same SPARK source**
(11 units, `SPARK_Mode => On`, gnatprove level 4: **1.839 checks proved,
0 unproved, 0 `pragma Assume`**, 0 `SPARK_Mode => Off`). No code changes were
made for this build — only the C OS shim (`kms_os_shim.c`, the single
documented C exception) is compiled for the target.

Version: **0.4.0** (strict JSON body validation, per-account key limits,
TTL up to 30 years — see `AUDIT.md` §v0.4.0).

Toolchain used (all latest): **GNAT 16.2.0** (Debian sid
`gnat-16-aarch64-linux-gnu`) + **binutils 2.47** + **glibc 2.43** +
**aarch64-linux-gnu** cross toolchain, relocated and link-static.

## Contents

| File | Target | Runs on |
|---|---|---|
| `linux-aarch64/main`  | AArch64 Linux  | Raspberry Pi 5 (64-bit OS), other ARM64 Linux |
| `linux-aarch64/admin` | AArch64 Linux  | same |

The pair is the server (`main`) and the account manager (`admin`). They are
**completely static** (no `PT_INTERP`, no shared-library `NEEDED` entries),
so **no runtime or toolchain needs to be installed** on the target machine.

## Linux (AArch64, e.g. Raspberry Pi)

```bash
chmod +x main admin
./main 0.0.0.0 9999 keystore.bin 90 users.bin   # bind  port  keystore  lifetime-days  users
./admin add alice s3cret                        # manage accounts (same dir)
./admin limit alice 100                         # cap keys per account (0 = unlimited)
```

> The default bind address above listens on all interfaces — use
> `127.0.0.1` when a Cloudflare Tunnel / reverse proxy on the same
> machine should be the only entry point.

## Verification notes

- `linux-aarch64/*` (0.4.0) were executed and smoke-tested end-to-end under
  `qemu-aarch64` (server boot, health 200 → `"version":"0.4.0"`, admin add /
  list / limit user, create/activate key, Ed25519 sign/verify roundtrip,
  strict-body 400, TTL 30 years — all passed).
- Binaries verified: `readelf -h` → Machine AArch64; `readelf -l` → no
  `INTERP` (fully static).
