# AnonToken — Cross-build binaries

Four standalone binaries cross-compiled from the **same SPARK source**
(11 units, `SPARK_Mode => On`, gnatprove level 4: **8.763 checks proved,
0 unproved, 0 `pragma Assume`**, 0 `SPARK_Mode => Off`). No code changes were made for this build —
only the C OS shim (`kms_os_shim.c`) got a second `_WIN32` branch so the same
Ada logic runs on both platforms.

Toolchain used (all latest, built from source): **GCC/GNAT 16.1.0** +
**binutils 2.47** + **mingw-w64 v12**.

## Contents

| File | Target | Runs on |
|---|---|---|
| `linux-aarch64/main`  | AArch64 Linux  | Raspberry Pi 5 (64-bit OS), other ARM64 Linux |
| `linux-aarch64/admin` | AArch64 Linux  | same |
| `windows-x86_64/main.exe`  | x86-64 Windows | Windows 10 / 11 (64-bit) |
| `windows-x86_64/admin.exe` | x86-64 Windows | same |

Each pair is the server (`main`) and the account manager (`admin`). They are
completely static on Linux (glibc only) and on Windows link only system DLLs
(KERNEL32, WS2_32, bcrypt, UCRT — all present on stock Windows 10/11), so
**no runtime or toolchain needs to be installed** on the target machine.

## Linux (AArch64, e.g. Raspberry Pi)

```bash
chmod +x main admin
./main 0.0.0.0 9999 keystore.bin 90 users.bin   # bind  port  keystore  lifetime-days  users
./admin add alice s3cret                        # manage accounts (same dir)
```

## Windows (x86-64)

Run from `cmd` or PowerShell — same arguments:

```
main.exe 0.0.0.0 9999 keystore.bin 90 users.bin
admin.exe add alice s3cret
```

> Note: Windows Firewall will prompt on first listen; allow it (private
> networks). The default bind address above listens on all interfaces —
> use `127.0.0.1` when a Cloudflare Tunnel / reverse proxy on the same
> machine should be the only entry point.

## Verification notes

- `linux-aarch64/*` were executed and smoke-tested end-to-end under
  `qemu-aarch64` (server boot, health 200, admin add user, create/activate
  key, Ed25519 sign/verify roundtrip — all passed).
- `windows-x86_64/*` could not be executed in this Linux environment (no
  Wine); they were verified structurally: correct PE/AMD64 headers, imports
  limited to stock Windows system DLLs, linked against the UCRT runtime.
  First run on a real Windows machine should start with
  `main.exe 127.0.0.1 9999 keystore.bin 90 users.bin` and a `curl` health
  check on `http://127.0.0.1:9999/health`.
