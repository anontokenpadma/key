------------------------------------------------------------------------------
--  Kms_Server : TCP server loop, fully SPARK (SPARK_Mode => On).
--
--  The socket work is done through the contract-carrying C imports in
--  Kms_Os (socket / setsockopt / bind / listen / accept4 / recv / send);
--  all protocol logic lives in the SPARK-proven Kms_Http package.  The
--  account table is (re)loaded from the users file on every request, so
--  ``admin add/remove/setpass`` takes effect immediately.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;

with Kms_File;
with Kms_Http;
with Kms_Keystore;
with Kms_Os;
with Kms_Users;

package body Kms_Server
  with SPARK_Mode => On
is

   use Interfaces;
   use Kms_File;
   use Kms_Http;
   use Kms_Os;
   use Kms_Types;

   -----------------------------
   --  persistent keystore    --
   -----------------------------

   --  The keystore (65,536 slots, ~13 MB) is way too large for the task
   --  stack, so it is allocated in main.adb on the heap and passed in
   --  here as a plain in-out parameter: this unit contains no access
   --  types and every subprogram stays SPARK-provable at level 4.

   ----------
   -- Run --
   ----------

   procedure Run (Cfg : in Config; KS : in out Keystore) is
      Server      : C_Int := -1;
      Addr        : Sock_Addr := (others => 0);
      Addr_OK     : Boolean := False;
      Seed        : Seed_Bytes := (others => 0);
      Secret_Seed : Seed_Bytes := (others => 0);
      RNG_OK      : Boolean := False;
      RNG_OK2     : Boolean := False;
      --  Fully explicit initializer: gnatprove needs to see Body_Len = 0
      --  (not just "some default") so the receive-loop invariant is
      --  trivially true on its first iteration.
      Req         : Kms_Http.Request :=
        (Kind         => Kms_Http.Req_None,
         Id           => 0,
         Error        => Kms_Http.Err_None,
         Body_Data    => (others => 0),
         Body_Len     => 0,
         Auth_Present => False,
         Auth_Data    => (others => 0),
         Auth_Len     => 0);
      Res         : Kms_Http.Parse_Result := Kms_Http.Incomplete;
      Resp        : Response_Buffer := (others => 0);
      Resp_Len    : N32 := 0;
      Changed     : Boolean := False;
      Freed       : Boolean := False;
      Loaded      : Boolean := False;
      Legacy_Claimed : Boolean := False;
      Users       : User_Table := (others => <>);
      Users_Loaded : Boolean := False;
      --  per-account login lockout state (anti brute-force); stays in
      --  memory for the lifetime of the process
      Attempts    : Attempt_Table := (others => (Fails => 0,
                                                 Locked_Until => 0));
      --  snapshot of the account table from the last successful load,
      --  used to detect when an account was deleted so its keys can be
      --  purged from the keystore (see Purge_Deleted_Users below)
      Prev_Users  : User_Table := (others => <>);
      Prev_Loaded : Boolean := False;
      Purged      : Boolean := False;
      Bind_Str    : constant String := Cfg.Bind_Address (1 .. Cfg.Bind_Len);
      Path_Str    : constant String :=
        (if Cfg.Path_Len > 0 then Cfg.Keystore_Path (1 .. Cfg.Path_Len)
         else "");
      Users_Str   : constant String :=
        (if Cfg.Users_Len > 0 then Cfg.Users_Path (1 .. Cfg.Users_Len)
         else "");
      One         : Integer := 1;
      Reuse_OK    : Boolean := False;
      R           : C_Int;

      --  Claim any legacy (pre-ownership, migrated from v1/v2) key for
      --  the first account in the table, so old keys stay visible under
      --  the per-developer model.  Did is True when a key was assigned
      --  (caller persists).  A procedure (not a function) because it
      --  writes the output global KS, which SPARK forbids in functions.
      procedure Claim_Legacy_Keys (Did : out Boolean) is
         First_User : User_Record;
         Got        : Boolean := False;
      begin
         Did := False;
         if not (Cfg.Users_Len > 0 and then Users_Loaded
                   and then Kms_Users.Count (Users) > 0)
         then
            return;
         end if;
         for I in Users'Range loop
            if Users (I).In_Use then
               First_User := Users (I);
               Got        := True;
               exit;
            end if;
         end loop;
         if not Got then
            return;
         end if;
         for I in KS'Range loop
            if KS (I).In_Use and then KS (I).Owner_Len = 0 and then
               First_User.Name_Len >= 1 and then
               First_User.Name_Len <= KS (I).Owner'Length
            then
               KS (I).Owner_Len := First_User.Name_Len;
               KS (I).Owner (0 .. First_User.Name_Len - 1) :=
                 First_User.Name (0 .. First_User.Name_Len - 1);
               Did := True;
            end if;
         end loop;
      end Claim_Legacy_Keys;

      --  Purge from the keystore every key whose owner account no longer
      --  exists in the (freshly loaded) users table - i.e. the account
      --  was deleted with the admin tool, so all keys it created must be
      --  wiped and can no longer be used or validated.  Only runs when
      --  the users file was actually loaded (a missing/corrupt users
      --  file means deny-all and must never trigger key deletion).  Did
      --  is True when at least one key was removed (caller persists).
      procedure Purge_Deleted_Users (Did : out Boolean) is
         F2   : Boolean;
         Idx2 : N32;
      begin
         Did := False;
         if not (Cfg.Users_Len > 0 and then Users_Loaded) then
            return;
         end if;
         --  fast path: account table unchanged since the last check
         if Prev_Loaded and then Prev_Users = Users then
            return;
         end if;
         --  scan every live key; when its owner is no longer an account,
         --  wipe it (Remove_By_Owner also cleans any sibling keys of the
         --  same owner in one pass).  The owner is copied into a local
         --  first: passing KS and KS (I).Owner together would alias the
         --  same memory, which SPARK RM 6.4.2 forbids.
         for I in KS'Range loop
            if KS (I).In_Use and then KS (I).Owner_Len >= 1 then
               declare
                  Own_Name : User_Name_Buffer := KS (I).Owner;
                  Own_Len  : N32 := KS (I).Owner_Len;
               begin
                  Kms_Users.Find (Users, Own_Name, Own_Len, F2, Idx2);
                  if not F2 then
                     declare
                        Freed2 : Boolean;
                     begin
                        Kms_Keystore.Remove_By_Owner
                          (KS, Own_Name, Own_Len, Freed2);
                        if Freed2 then
                           Did := True;
                        end if;
                     end;
                  end if;
               end;
            end if;
         end loop;
         Prev_Users  := Users;
         Prev_Loaded := True;
      end Purge_Deleted_Users;

   begin
      Kms_Keystore.Init (KS);
      if Cfg.Path_Len > 0 then
         Kms_File.Load (Path_Str, KS, Loaded);
         if Loaded then
            Log ("[anontoken] keystore loaded from " & Path_Str);
         else
            Log ("[anontoken] no keystore found at " & Path_Str &
                 " - starting empty");
         end if;
      end if;
      Kms_Keystore.Expire (KS, Kms_Os.Unix_Time, Freed);
      --  persist the purge so expired keys are cleared from the keystore
      --  file immediately at boot
      if Freed and then Cfg.Path_Len > 0 then
         Kms_File.Save (Path_Str, KS);
      end if;

      --  account table: loaded at boot, then re-checked per request
      if Cfg.Users_Len > 0 then
         Kms_File.Load_Users (Users_Str, Users, Users_Loaded);
         if Users_Loaded then
            Log ("[anontoken] users loaded from " & Users_Str);
         else
            Log ("[anontoken] no users file at " & Users_Str &
                 " - all API requests will be rejected with 401");
         end if;
      end if;

      --  claim legacy keys for the first account
      Claim_Legacy_Keys (Legacy_Claimed);
      if Legacy_Claimed and then Cfg.Path_Len > 0 then
         Kms_File.Save (Path_Str, KS);
      end if;

      --  purge keys whose owner account was deleted while we were down
      --  (or on the very first start with an existing users file)
      Purge_Deleted_Users (Purged);
      if Purged and then Cfg.Path_Len > 0 then
         Kms_File.Save (Path_Str, KS);
         Log ("[anontoken] purged keys of deleted accounts from " &
              Path_Str);
      end if;

      --  create + bind + listen
      Server := C_Socket (Kms_Os.AF_INET, Kms_Os.SOCK_STREAM, 0);
      if Server < 0 then
         Log ("[anontoken] socket() failed");
         return;
      end if;
      Set_Reuse (Server, Reuse_OK);
      pragma Unreferenced (Reuse_OK);
      Build_Sockaddr (Bind_Str, Cfg.Port, Addr, Addr_OK);
      if not Addr_OK then
         Log ("[anontoken] bad bind address: " & Bind_Str);
         R := C_Close (Server);
         pragma Unreferenced (R);
         return;
      end if;
      R := C_Bind (Server, Addr, 16);
      if R /= 0 then
         Log ("[anontoken] bind() failed");
         R := C_Close (Server);
         return;
      end if;
      R := C_Listen (Server, Backlog);
      if R /= 0 then
         Log ("[anontoken] listen() failed");
         R := C_Close (Server);
         return;
      end if;
      Log ("[anontoken] lifetime=" &
           Kms_Types.I64'Image (Cfg.Lifetime_Days) & "d");
      Log ("[anontoken] listening on " & Bind_Str & ":" &
           Positive'Image (Cfg.Port));

      loop
         declare
            Client : C_Int;
            Buf    : Request_Buffer := (others => 0);
            C      : Chunk := (others => 0);
            Last   : C_SSize;
            Len    : N32 := 0;
            W      : Chunk := (others => 0);
            Sent_i : N32 := 0;
            RR     : C_SSize;
         begin
            C_Accept (Server, Client);
            if Client < 0 then
               Log ("[anontoken] accept() failed");
               exit;
            end if;

            --  Receive chunks until the request parser says it is complete.
            --  Len never exceeds Request_Buffer'Length: each iteration copies
            --  at most (Request_Buffer'Length - Len) bytes, so the buffer
            --  index is safe by construction.
            --  Start each connection from a clean request state so the loop
            --  invariant below is trivial on its first iteration regardless
            --  of what the previous connection left behind.  Only the fields
            --  the invariant / parser contract mention are reset here: a
            --  full-record aggregate would drag the 2 KiB Body_Data into
            --  every later proof goal and blow their step limits.
            Req.Kind         := Kms_Http.Req_None;
            Req.Id           := 0;
            Req.Error        := Kms_Http.Err_None;
            Req.Body_Len     := 0;
            Req.Auth_Present := False;
            Req.Auth_Len     := 0;
            Res := Kms_Http.Incomplete;
            loop
               pragma Loop_Invariant
                 (Len <= N32 (Request_Buffer'Length) and then
                  Req.Body_Len <= Max_Body_Length and then
                  Req.Auth_Len <= Max_Auth_Length);
               C := (others => 0);
               C_Recv (Client, C, 2048, Last);
               exit when Last <= 0;
               for I in 0 .. N32 (Last) - 1 loop
                  pragma Loop_Invariant
                    (Len <= N32 (Request_Buffer'Length));
                  if Len < N32 (Request_Buffer'Length) then
                     Buf (Len) := C (I);
                     Len := Len + 1;
                  end if;
               end loop;
               Kms_Http.Parse (Buf, Len, Req, Res);
               exit when Res /= Kms_Http.Incomplete;
            end loop;

            if Res = Kms_Http.Incomplete then
               --  any leftover unfinished request is treated as an error
               Req := (Kind => Kms_Http.Req_None, others => <>);
            end if;

            --  reload the account table on every request so that
            --  ``admin add/remove/setpass`` takes effect immediately
            if Cfg.Users_Len > 0 then
               declare
                  Was_Loaded : constant Boolean := Users_Loaded;
                  Table_Changed : Boolean := False;
               begin
                  Kms_File.Load_Users (Users_Str, Users, Users_Loaded);
                  if (not Was_Loaded) and then Users_Loaded then
                     Log ("[anontoken] users loaded from " & Users_Str);
                  end if;
                  --  the lockout table is keyed by account slot: when the
                  --  account list changed on disk (admin add/remove/setpass
                  --  reorders slots) a stale lock could be misattributed to
                  --  a different account, so reset the counters.  On a
                  --  steady-state table the counters survive across
                  --  requests, which is exactly what throttling needs.
                  Table_Changed := (not Users_Loaded) or else
                                   (not Prev_Loaded) or else
                                   (Users /= Prev_Users);
                  if Table_Changed then
                     Kms_Users.Init_Attempts (Attempts);
                  end if;
                  --  when accounts first become available, claim any
                  --  still-unowned legacy keys for the first account
                  if (not Was_Loaded) and then Users_Loaded then
                     Claim_Legacy_Keys (Legacy_Claimed);
                     if Legacy_Claimed and then Cfg.Path_Len > 0 then
                        Kms_File.Save (Path_Str, KS);
                     end if;
                  end if;
               end;
            end if;

            --  if an account was deleted since the last request, wipe all
            --  keys it created immediately (takes effect with no restart)
            Purge_Deleted_Users (Purged);
            if Purged and then Cfg.Path_Len > 0 then
               Kms_File.Save (Path_Str, KS);
            end if;

            --  fresh entropy is needed only by key creation; a request
            --  that needs it but cannot get it is refused (fail-closed):
            --  never derive a key id / Ed25519 pair / activation secret
            --  from a zeroed or partial seed.  The refused request turns
            --  into a 500 (Req_None) below.
            if Req.Kind = Req_Create then
               Kms_Os.Random_Bytes (Seed, RNG_OK);
               Kms_Os.Random_Bytes (Secret_Seed, RNG_OK2);
               if not (RNG_OK and then RNG_OK2) then
                  Req := (Kind => Kms_Http.Req_None, others => <>);
               end if;
            end if;
            Kms_Http.Dispatch
              (KS, Kms_Os.Unix_Time, Seed, Secret_Seed,
               Cfg.Lifetime_Days, Users, Attempts,
               Req, Resp, Resp_Len, Changed);

            if Resp_Len > 0 then
               Sent_i := 0;
               while Sent_i < Resp_Len loop
                  pragma Loop_Invariant (Sent_i <= Resp_Len);
                  --  Send at most W'Length bytes per call: W is a 4 KiB
                  --  stack chunk, and a full response can be much larger
                  --  (e.g. a long key listing).
                  declare
                     Take : constant N32 :=
                       N32'Min (N32 (W'Length), Resp_Len - Sent_i);
                  begin
                     for J in 0 .. Take - 1 loop
                        pragma Loop_Invariant
                          (Sent_i + J <= Resp_Len - 1);
                        W (J) := Resp (Sent_i + J);
                     end loop;
                     C_Send (Client, W, C_Size (Natural (Take)), RR);
                     pragma Assert (RR >= -1 and then RR <= C_SSize (Take));
                  end;
                  if RR <= 0 then
                     exit;
                  end if;
                  Sent_i := Sent_i + N32 (RR);
               end loop;
            end if;
            R := C_Close (Client);

            if Changed and then Cfg.Path_Len > 0 then
               Kms_File.Save (Path_Str, KS);
            end if;
         end;
      end loop;

      R := C_Close (Server);
   end Run;

end Kms_Server;