/*------------------------------------------------------------------------------
 *  Kms_Os_Shim : minimal C syscall glue for the SPARK Kms_Os boundary.
 *
 *  The Ada package Kms_Os (SPARK_Mode => On) imports these procedures
 *  directly with Convention => C.  Buffers are passed by reference
 *  (GNAT array parameters), results are returned through an explicit
 *  output scalar (GNAT passes out scalars by reference under C
 *  convention).  No 'Address attribute is needed anywhere in Ada.
 *
 *  This file deliberately contains no logic: it forwards each call to the
 *  corresponding operating-system primitive and stores the raw result.
 *
 *  Two platforms are supported:
 *    - POSIX/Linux  (getrandom, accept4, POSIX sockets, fd semantics)
 *    - Windows      (BCryptGenRandom, WinSock2, CRT file descriptors)
 *  The Ada side is identical on both: every libc entry point used by Ada
 *  (open/close/rename/unlink/access/socket/bind/listen) goes through a
 *  kms_* wrapper defined here, so the same SPARK code compiles for both
 *  targets without conditional Ada code.
 *---------------------------------------------------------------------------*/

#if defined(_WIN32)
/*------------------------------- Windows ----------------------------------*/
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#include <bcrypt.h>
#include <io.h>
#include <time.h>
#include <stddef.h>
#include <stdint.h>

#define FD_SOCK_BASE  4096          /*  logical fds for sockets live here  */
#define FD_SOCK_MAX   256
static SOCKET sock_tab[FD_SOCK_MAX];
static int    wsa_state = 0;        /*  0 = not started, 1 = started       */

static void ensure_wsa(void)
{
    if (wsa_state == 0) {
        WSADATA wd;
        if (WSAStartup(MAKEWORD(2, 2), &wd) == 0)
            wsa_state = 1;
    }
}

static SOCKET fd_to_sock(int fd)
{
    if (fd >= FD_SOCK_BASE && fd < FD_SOCK_BASE + FD_SOCK_MAX)
        return sock_tab[fd - FD_SOCK_BASE];
    return INVALID_SOCKET;
}

/*  Translate the Linux O_* flag encoding used by the Ada spec into the
 *  Windows CRT encoding.  Low two bits (O_RDONLY/O_WRONLY/O_RDWR) and
 *  O_TRUNC (0x200) are identical; O_CREAT differs (0x40 Linux, 0x100 CRT). */
static int win_flags(int flags)
{
    int w = flags & 3;
    if (flags & 0x200) w |= 0x200;
    if (flags & 0x040) w |= 0x100;
    return w;
}

/*  read(fd, buf, count) -> bytes read / 0 EOF / -1 error  */
void kms_read(int fd, unsigned char *buf, size_t count, int64_t *res)
{
    int r = _read(fd, buf, (unsigned int)count);
    *res = (r < 0) ? -1 : (int64_t)r;
}

/*  write(fd, buf, count) -> bytes written / -1 error  */
void kms_write(int fd, const unsigned char *buf, size_t count, int64_t *res)
{
    int r = _write(fd, buf, (unsigned int)count);
    *res = (r < 0) ? -1 : (int64_t)r;
}

/*  open(path, flags, mode) -> fd >= 0 or -1  */
int kms_open(const unsigned char *path, int flags, int mode)
{
    return _open((const char *)path, win_flags(flags), mode);
}

/*  close(fd) -> 0 or -1; closes either a CRT file or a logical socket fd  */
int kms_close(int fd)
{
    SOCKET s = fd_to_sock(fd);
    if (s != INVALID_SOCKET) {
        int r = closesocket(s);
        sock_tab[fd - FD_SOCK_BASE] = INVALID_SOCKET;
        return (r == 0) ? 0 : -1;
    }
    return _close(fd);
}

/*  rename(old, new) -> 0 or -1; replaces an existing target (POSIX style)  */
int kms_rename(const unsigned char *oldp, const unsigned char *newp)
{
    if (MoveFileExA((const char *)oldp, (const char *)newp,
                    MOVEFILE_REPLACE_EXISTING))
        return 0;
    return -1;
}

int kms_unlink(const unsigned char *path)
{
    return _unlink((const char *)path);
}

int kms_access(const unsigned char *path, int mode)
{
    return _access((const char *)path, mode);
}

/*  socket(domain, kind, proto) -> logical fd >= 0 or -1  */
int kms_socket(int domain, int kind, int protocol)
{
    int i;
    SOCKET s;
    ensure_wsa();
    s = socket(domain, kind, protocol);
    if (s == INVALID_SOCKET)
        return -1;
    for (i = 0; i < FD_SOCK_MAX; i++) {
        if (sock_tab[i] == INVALID_SOCKET) {
            sock_tab[i] = s;
            return FD_SOCK_BASE + i;
        }
    }
    closesocket(s);
    return -1;
}

int kms_bind(int fd, const unsigned char *addr, int len)
{
    SOCKET s = fd_to_sock(fd);
    if (s == INVALID_SOCKET)
        return -1;
    return bind(s, (const struct sockaddr *)addr, len);
}

int kms_listen(int fd, int backlog)
{
    SOCKET s = fd_to_sock(fd);
    if (s == INVALID_SOCKET)
        return -1;
    return listen(s, backlog);
}

/*  accept(fd) -> logical client fd or -1  */
void kms_accept(int fd, int *client)
{
    int i;
    SOCKET s, c;
    ensure_wsa();
    s = fd_to_sock(fd);
    if (s == INVALID_SOCKET) {
        *client = -1;
        return;
    }
    c = accept(s, NULL, NULL);
    if (c == INVALID_SOCKET) {
        *client = -1;
        return;
    }
    for (i = 0; i < FD_SOCK_MAX; i++) {
        if (sock_tab[i] == INVALID_SOCKET) {
            sock_tab[i] = c;
            *client = FD_SOCK_BASE + i;
            return;
        }
    }
    closesocket(c);
    *client = -1;
}

/*  setsockopt(fd, SO_REUSEADDR, 1) -> ok = 1 / 0.
 *  GNAT maps Ada Boolean to a 1-byte char under C convention.  */
void kms_setsockopt_reuse(int fd, char *ok)
{
    SOCKET s = fd_to_sock(fd);
    int one = 1;
    int r;
    if (s == INVALID_SOCKET) {
        *ok = 0;
        return;
    }
    r = setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char *)&one,
                   sizeof(one));
    *ok = (char)((r == 0) ? 1 : 0);
}

/*  recv(fd, buf, len, 0) -> bytes read / 0 EOF / -1 error  */
void kms_recv(int fd, unsigned char *buf, size_t len, int64_t *res)
{
    SOCKET s = fd_to_sock(fd);
    int r;
    if (s == INVALID_SOCKET) {
        *res = -1;
        return;
    }
    r = recv(s, (char *)buf, (int)len, 0);
    *res = (r == SOCKET_ERROR) ? -1 : (int64_t)r;
}

/*  send(fd, buf, len, 0) -> bytes sent / -1 error  */
void kms_send(int fd, const unsigned char *buf, size_t len, int64_t *res)
{
    SOCKET s = fd_to_sock(fd);
    int r;
    if (s == INVALID_SOCKET) {
        *res = -1;
        return;
    }
    r = send(s, (const char *)buf, (int)len, 0);
    *res = (r == SOCKET_ERROR) ? -1 : (int64_t)r;
}

/*  time(NULL) -> seconds since the epoch  */
int64_t kms_time(void)
{
    return (int64_t)time(NULL);
}

/*  getrandom(buf, len): fill the whole buffer from the system RNG.
 *  *ok = 1 on success, 0 when the system RNG refused (fail-closed on the
 *  Ada side: the caller must never use buf when *ok == 0).  GNAT maps Ada
 *  Boolean to a 1-byte char under C convention, like kms_setsockopt_reuse.
 */
void kms_getrandom(unsigned char *buf, size_t len, char *ok)
{
    while (len > 0) {
        ULONG chunk = (len > 0x40000000UL) ? 0x40000000UL : (ULONG)len;
        if (BCryptGenRandom(NULL, buf, chunk,
                            BCRYPT_USE_SYSTEM_PREFERRED_RNG) != 0) {
            *ok = 0;                /*  system refused  */
            return;
        }
        buf += chunk;
        len -= (size_t)chunk;
    }
    *ok = 1;
}

#else
/*-------------------------------- POSIX/Linux ------------------------------*/
#define _GNU_SOURCE
#include <stddef.h>
#include <stdint.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/random.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

/*  read(fd, buf, count) -> bytes read / 0 EOF / -1 error  */
void kms_read(int fd, unsigned char *buf, size_t count, int64_t *res)
{
    ssize_t r = read(fd, buf, count);
    *res = (int64_t)r;
}

/*  write(fd, buf, count) -> bytes written / -1 error  */
void kms_write(int fd, const unsigned char *buf, size_t count, int64_t *res)
{
    ssize_t r = write(fd, buf, count);
    *res = (int64_t)r;
}

/*  open(path, flags, mode) -> fd >= 0 or -1  */
int kms_open(const unsigned char *path, int flags, int mode)
{
    return open((const char *)path, flags, mode);
}

int kms_close(int fd)
{
    return close(fd);
}

int kms_rename(const unsigned char *oldp, const unsigned char *newp)
{
    return rename((const char *)oldp, (const char *)newp);
}

int kms_unlink(const unsigned char *path)
{
    return unlink((const char *)path);
}

int kms_access(const unsigned char *path, int mode)
{
    return access((const char *)path, mode);
}

int kms_socket(int domain, int kind, int protocol)
{
    return socket(domain, kind, protocol);
}

int kms_bind(int fd, const unsigned char *addr, int len)
{
    return bind(fd, (const struct sockaddr *)addr, (socklen_t)len);
}

int kms_listen(int fd, int backlog)
{
    return listen(fd, backlog);
}

/*  recv(fd, buf, len, 0) -> bytes read / 0 EOF / -1 error  */
void kms_recv(int fd, unsigned char *buf, size_t len, int64_t *res)
{
    ssize_t r = recv(fd, buf, len, 0);
    *res = (int64_t)r;
}

/*  send(fd, buf, len, 0) -> bytes sent / -1 error  */
void kms_send(int fd, const unsigned char *buf, size_t len, int64_t *res)
{
    ssize_t r = send(fd, buf, len, 0);
    *res = (int64_t)r;
}

/*  accept4(fd, NULL, NULL, 0) -> client fd / -1 error  */
void kms_accept(int fd, int *client)
{
    *client = accept4(fd, NULL, NULL, 0);
}

/*  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &1, 4) -> ok = 1 / 0.
 *  GNAT maps Ada Boolean to a 1-byte char under C convention, so the
 *  output is a char pointer, not an int pointer.  */
void kms_setsockopt_reuse(int fd, char *ok)
{
    int one = 1;
    int r = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    *ok = (char)((r == 0) ? 1 : 0);
}

/*  time(NULL) -> seconds since the epoch  */
int64_t kms_time(void)
{
    return (int64_t)time(NULL);
}

/*  getrandom(buf, len, 0); retries on EINTR, fills the whole buffer.
 *  *ok = 1 on success, 0 when the kernel refused (fail-closed on the Ada
 *  side: the caller must never use buf when *ok == 0).
 */
void kms_getrandom(unsigned char *buf, size_t len, char *ok)
{
    for (;;) {
        ssize_t r = getrandom(buf, len, 0);
        if (r == (ssize_t)len) {
            *ok = 1;
            return;
        }
        if (r < 0 && errno == EINTR)
            continue;
        if (r < 0) {
            *ok = 0;                /*  kernel refused  */
            return;
        }
        buf += (size_t)r;
        len -= (size_t)r;
    }
}
#endif
