#!/usr/bin/env bash
# Anti brute-force lockout (v0.3.1 hardening):
#   - 5 consecutive wrong passwords lock the account for Auth_Lockout_Secs
#   - while locked, even the CORRECT password is rejected (401)
#   - wrong guesses at an unknown username are never counted (and cannot
#     lock anything: the account table is unchanged, so attempts reset)
#   - admin setpass (rewrites users file) resets the lock immediately
#   - the reset also happens when the account table changes on disk, so a
#     fresh server process starts with a clean attempt table
cd "$(dirname "$0")/.."
BIN=./bin/main
ADMIN=./bin/admin
P=9995
H=http://127.0.0.1:$P
KS=/tmp/kse_lock.bin
LOG=/tmp/kse_lock.log
US=/tmp/kse_lock_users.bin

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
sleep 0.5
rm -f "$KS" "$LOG" "$US"
"$ADMIN" -f "$US" add victim 'Correct-Pass-1' >/dev/null 2>&1 || true

setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1

FAIL=0
chk() { if [ "$2" = "$3" ]; then echo "PASS  $1"; else echo "FAIL  $1 (got [$2] want [$3])"; FAIL=1; fi; }
code() { curl -s $4 -o /dev/null -w '%{http_code}' -u "$2:$3" $H/keys; }

AUTH_U=victim
AUTH_P=Correct-Pass-1

chk "correct password before lockout" "$(code "" $AUTH_U $AUTH_P "")" "200"

echo "-- 5 wrong passwords in a row --"
for i in 1 2 3 4 5; do
  code "" $AUTH_U "wrong-pass-$i" "" >/dev/null
done
chk "correct password DURING lockout -> 401" "$(code "" $AUTH_U $AUTH_P "")" "401"
chk "wrong password during lockout -> 401" "$(code "" $AUTH_U still-wrong "")" "401"

echo "-- unknown username never locks / never counted --"
for i in 1 2 3 4 5 6 7 8; do
  code "" no-such-user "whatever-$i" "" >/dev/null
done
chk "unknown user still 401 (not locked in)" "$(code "" no-such-user whatever "")" "401"
chk "victim unaffected by unknown-user guesses (still locked) -> 401" "$(code "" $AUTH_U $AUTH_P "")" "401"

echo "-- admin setpass resets the lock --"
"$ADMIN" -f "$US" setpass $AUTH_U 'New-Pass-2' >/dev/null
sleep 0.3   # server reloads users file on next request
chk "correct NEW password after setpass -> 200" "$(code "" $AUTH_U 'New-Pass-2' "")" "200"

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
echo "RESULT: $([ $FAIL = 0 ] && echo ALL_PASS || echo HAS_FAILURES)"
