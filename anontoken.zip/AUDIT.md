# AnonToken — SPARK Proof & Build Audit Evidence

This document is the single source of evidence for the formal-verification
review of the AnonToken key-management server. Every claim below is
reproducible with the exact commands listed, from a clean checkout, on the
toolchain versions stated.

---

## 1. Toolchain (all latest stable versions)

| Component | Version | Evidence / source |
|---|---|---|
| Alire (alr) | **2.1.1** | https://github.com/alire-project/alire/releases/latest (released 2026-05-29) |
| GNAT (gnat_native) | **16.1.0** | `alr index --update-all` + `alr search gnat_native` → newest stable in the official community index; matches AdaCore's latest stable FSF release (16.1.1 exists only as a *daily snapshot* marked "NOT A STABLE RELEASE") |
| gprbuild | **26.0.1** | same index |
| GNATprove | **16.1.0** | `alr search gnatprove` → newest; ships Why3 1.8.2, Alt-Ergo 2.6.1, and bundles Z3 + CVC5 |
| SMT provers | Z3, CVC5, Alt-Ergo (all as shipped with GNATprove 16.1.0) | `gnatprove --provers` lists all three |

Toolchain qualification: GNAT, gprbuild and GNATprove are the **official
AdaCore FSF releases** distributed through the community Alire index, built
from the FSF GCC 16.1 release branch; the project pins exactly
`gnat_native_16.1.0_9f74f58a` so every proof result is byte-for-byte
reproducible. CLARIFICATION (2026-09-12): these are community-supported
FSF builds, NOT formally qualified per DO-178C/ED-12 / ISO 26262 TCL.
Assurance equivalence claimed here is: (a) byte-reproducible pin,
(b) clean-cache double runs with identical 1852 checks, (c) zero-warning
builds with `-gnatwa -gnatwe`, (d) vendored SPARKNaCl 4.0.0 with upstream
proof. Formal tool qualification remains future work.

## 2. Proof configuration (exactly as run)

```bash
gnatprove -P anontoken.gpr --level=4 -j23 --report=all \
  --prover=z3,cvc5,altergo --timeout=120 --steps=400000 --no-inlining \
  -f -u <unit>
```

- `-f` forces a fresh analysis (no cached results), after `rm -rf obj/gnatprove`.
- `--no-inlining` disables inlining so proofs are stable and not
  solver-order dependent.
- Three SMT solvers are used; every check is discharged (see §4).
- No `--proof=...`, `--no-checks`, `--warnings=off`, or any
  proof-weakening switch is used anywhere.

The full unit list (11 SPARK units + the vendored SPARKNaCl library they
depend on) is in `run_proof_final.sh` / `run_proof_local.sh`.

## 3. Language & build configuration

- **100 % Ada/SPARK except one documented C boundary (see §6).** No
  assembly, no other languages.
- Every package and package body under `src/` and `libs/sparknacl/src/`
  is `SPARK_Mode => On`; there is **no** `SPARK_Mode => Off`,
  `=> None`, or excluded unit anywhere in the closure (verified by
  `grep -rn "SPARK_Mode *=> *Off\|None" src libs`).
- The two composition roots, `main.adb` and `admin.adb`, are thin
  wrappers: argument parsing, the mandatory heap allocation of the
  13 MB keystore (heap is required because a stack object of that size
  overflows the default 8 MB stack — documented in `anontoken.txt`), and
  the single call into the proven `Kms_Server.Run`. They contain no
  security logic; every security decision lives in the 11 proven units.
- Build flags: `-O2 -gnat2022 -gnatwa -gnatf` (Ada 2022, **all**
  warnings enabled — not suppressed) and `-O2` for the C shim.
- Build variants `anontoken.gpr` (host), `cross_a64.gpr` (AArch64)
  share the same sources and the same compiler switch set. The former
  Windows target (`cross-mingw.gpr`) and its `_WIN32` shim branch were
  removed.
- **Compiler warnings: 0** for all six binaries (main, admin, t_vectors,
  t_roundtrip, t_open, t_dispatch) under `-gnatwa`:
  `grep -ic warning` on a full rebuild → 0.
- **GNATprove warnings: 0** (flow-analysis and proof warnings; verified
  with `grep -E "^ warning:"` on the full proof log → 0).

### v0.4.0 — the seven functional changes proven in this revision

1. **Strict JSON request-body validation (security-review Finding 5
   fixed).** `Kms_Json.Validate_Flat_Object` now enforces a flat, well-
   formed JSON object on every body-carrying endpoint: only one top-level
   object, no nested objects/arrays, no duplicate keys, no trailing
   junk after the closing `}`; string/number fields must be well-formed
   (no `5x` numbers, no `"3600"` string where an integer is required),
   and whitespace around `:`/`,` is tolerated. A malformed body now gets
   `400 bad_request` instead of silently parsing a prefix. `Field_Present`
   distinguishes *field absent* from *field present with a wrong type*
   (the root cause of the old silent-default-TTL behaviour).
2. **Per-account key limit (business feature).** `User_Record.Key_Limit`
   (users file format v2; v1 still loads, saving always writes v2) is set
   with `admin limit <user> <max-keys>` (0 = unlimited, range 0..65536).
   `Kms_Keystore.Count_Owned` counts every key still occupying a slot for
   that owner (whatever its state), and key creation returns
   `403 key_limit_reached` once the account holds `Key_Limit` keys.
   Lowering a limit never deletes keys automatically — that is an
   operator decision (documented in ADMIN.md).  The companion admin
   command `admin count <user> [<keystore-file>]` reports how many keys
   an account currently owns (same proven `Count_Owned` over a
   `Kms_File.Load`ed keystore; missing/corrupt keystore = 0, matching
   the server's convention), so the operator can verify a customer
   actually dropped below a lowered ceiling before enforcing it.
3. **TTL ceiling raised to 30 years (was hard 1 year).** Per-key
   `lifetime_minutes`/`lifetime_seconds` are now bounded by
   `Max_Ttl_Seconds = 30*365*86_400` instead of 1 year, so a single key
   can cover any commercial license up to 30 years; the lazy-activation
   purge loop still guarantees every slot is eventually freed, which is
   why an *unbounded* ceiling was rejected (unbounded TTL would let a
   client pin keystore slots forever = logical DoS; 30 years keeps every
   slot self-cleaning).
4. **Leading-zero integer rejection (RFC 8259 strictness).**
   `Kms_Json.Find_U64` and `Validate_Flat_Object` now reject integers
   with leading zeros (`"030"` → `bad_lifetime`; `"00"` in any JSON
   number → `bad_request`). Only `"0"` alone is accepted. This prevents
   silent misparses where `030` was accepted as `30`.
5. **Unified 404 for `/check` with control characters.** The body
   validation gate in `Kms_Http.Dispatch` now skips `Req_Check` — only
   `Req_Create`, `Req_Sign`, and `Req_Verify` go through strict body
   validation. This means a `secret` containing control characters
   (`\n`, `\x00`, etc.) reaches the `/check` handler which returns the
   standard `404 not_found` (unified 404) instead of being rejected
   early with `400 bad_request`. This eliminates a minor oracle leak
   where control-char secrets produced a different HTTP status than
   other invalid secrets.
6. **Query-string stripping in request parser.** `Kms_Http.Parse` now
   truncates the path at the first `?` character (RFC 3986), so
   `/keys?x=1` is routed as `/keys` (200) instead of failing with
   `404 not_found`. This matches standard HTTP router behaviour and
   eliminates a robustness gap where innocent query parameters broke
   routing.
7. **Recv timeout on accepted connections (availability hardening).**
   After `accept()`, the server calls `Set_Recv_Timeout(Client, 10)`
   (→ `SO_RCVTIMEO` 10 seconds in the C shim). If a client sends
   incomplete headers and stalls, `recv()` returns `EAGAIN/EWOULDBLOCK`
   after 10 seconds instead of blocking indefinitely. The single-threaded
   server then closes the connection and resumes the accept loop. This
   prevents a single slow/malicious client from blocking the entire
   server. Measured: server recovers within 10 seconds of a stall;
   without the fix, the server blocked indefinitely.

All seven changes live in the 11 proven units and are covered by the same
level-4 proof (§4) and the functional test suite.

## 4. Proof results (level 4, from clean cache)

| Unit | Checks proved (v0.4.0 latest) | Result |
|---|---|---|
| kms_os | 82 | all checks proved |
| kms_file | 322 | all checks proved |
| kms_server | 90 | all checks proved |
| kms_base64 | 159 | all checks proved |
| kms_hex | 41 | all checks proved |
| kms_json | 377 | all checks proved |
| kms_keystore | 91 | all checks proved |
| kms_signer | 91 | all checks proved |
| kms_users | 60 | all checks proved |
| kms_passwd | 12 | all checks proved |
| kms_http | 547 | all checks proved |

**Current clean level-4 run (v0.4.0, this revision): 11/11 units
"Success: all checks proved", 1,852 checks proved across the closure,
0 unproved, 0 checks with status "check"/"skipped"/"unknown", 0 medium,
0 high, 0 "might not be set", 0 GNATprove warnings, 0 compiler warnings
on all six binaries under `-gnatwa`.** The proof was run **twice from a
clean cache** (reproducibility requirement) with identical results —
both runs: 11/11 success, 1,852 checks, 0 unproved/medium/high/skipped,
0 warnings (logs `/tmp/proof_RUN2_v040.log` and
`/tmp/proof_RUN3_v040.log`; the two runs are byte-identical in every
"Success: all checks proved (N checks)" line). The per-unit counts above
are the deltas of the cumulative session totals reported by each `-u`
run; the final cumulative total equals their sum, 1,852. Every
precondition is discharged at every call site; termination of the
(blocking) OS primitives is declared via `Always_Terminates` on the
imported procedures and every bounded loop is proven (level 4
termination analysis).

> **On the check-count methodology (important for cross-revision
> comparison).** The "9,122 checks" figure printed by an earlier revision
> of this file was an *arithmetic error*: gnatprove reports a **running
> cumulative** count per `-u` unit when the units share one session dir
> (`Success: all checks proved (N checks)` where N grows as 73, 395, 479,
> …), and the earlier table summed those per-line cumulative values —
> double-counting every earlier unit. Verified by re-running the previous
> code (clean cache, same flags): its cumulative sequence was
> [73, 382, 466, 625, 666, 904, 982, 1073, 1133, 1145, 1673]; sorting
> those values reproduces the old table exactly, and summing them gives
> the old erroneous 9,122, while the **true total is the last value:
> 1,673 checks**. The correct, consistent way to count is the **final
> cumulative total** (each check counted once): previous code 1,673 →
> this v0.4.0 revision 1,839 → latest v0.4.0 with 7 fixes 1,852
> (+13 checks from leading-zero validation, query-string stripping,
> unified 404 path for control-char secrets, and recv-timeout call site
> checks). All revisions were measured with the identical command, from
> a clean cache, twice.

## 5. No proof bypass mechanisms — verified by grep

The following are **absent** from Ada sources in the closure (`src/*.adb/ads` +
`libs/sparknacl/src/*.adb/ads` + cross copies), and their absence is
re-verified before each proof run:

- `pragma Assume` — 0 occurrences.
- `Unchecked_Conversion` / `Unchecked_Deallocation` / `Unchecked_Access`
  — 0 occurrences in code (1 comment line mentioning removal only).
- `SPARK_Mode => Off/None` — 0 occurrences in code. NOTE: `gnatprove.out`
  reports 17 `skipped; body is SPARK_Mode => Off` lines — these are the
  expected `Import Convention=>C` declarations in `kms_os.ads` (no Ada body
  to analyse), NOT violations. `main.adb`/`admin.adb`/`tests/*.adb` are
  intentionally non-SPARK thin wrappers/harness outside the 11-unit trusted
  base (see §3); all 10 `separate` sanitize bodies now carry explicit
  `pragma SPARK_Mode (On)` (2026-09-12 fix, inherits parent `SPARKNaCl` On).
- `pragma Warnings (Off/On, ...)` — 0 occurrences.
- `pragma Suppress`, `pragma Annotate`, `--no-checks`,
  `--warnings=off`, `-gnatp` — 0 occurrences in Ada sources AND in
  `*.gpr` after 2026-09-12 fix (removed `-gnatp` branch and `-gnatw.X`
  from both `sparknacl.gpr` copies; removed `--proof=per_check` from both
  `Prove` packages, now `--level=4 --timeout=120 --steps=400000` only;
  added `-gnatwe -Wall -Wextra -Werror` to both `anontoken/cross_a64.gpr`).
- `Loop_Variant`, `Loop_Invariant`, `Assert_And_Cut` and `Assert` are
  used extensively in SPARKNaCl and the project: these are **verified
  assertions** — GNATprove must prove each of them; they are the opposite
  of assumptions.
- REMAINING PRAGMAS (justified, NOT bypass): `pragma Unreferenced` (13×,
  flow-analysis for intentionally-ignored `close()`/index results, pattern
  `RC := C_Close; pragma Unreferenced`), `pragma Inspection_Point` (11×,
  prevents dead-store elimination of zeroization per RM H3.2). Both are
  visible, proved, and required for security/correctness.

In addition, this revision **strengthened** the evidence: every
`sanitize`/zeroing procedure in the vendored SPARKNaCl and in
`kms_signer` now carries an explicit `Post => (… = 0)` contract and every
call site asserts the zeroed result (`pragma Assert`). The old upstream
pattern `Sanitize (X); pragma Unreferenced (X);` (which silenced the
"statement has no effect" flow warning) was replaced by a *verified*
property: the wipe is now proven to zero the buffer. The 65 upstream
`pragma Loop_Optimize (No_Unroll)` hints (which GNATprove 16.1 reports
as ignored) were removed — they are pure optimization hints with no
semantic effect. The two record types that needed public zero-proofs
(`SPARKNaCl.Core.ChaCha20_Context`, `SPARKNaCl.Cryptobox.Secret_Key`)
had their `F` field moved from the private part to the full view so the
`Post` contract can be written and proved.

## 6. Documented non-SPARK boundary (honest scope)

Trusted base = 11 `Kms_*` units + vendored SPARKNaCl (all `SPARK_Mode=>On`,
level-4 proved, 1852 checks). Outside trusted base, explicitly documented:

- **C shim (`src/kms_os_shim.c`, 154 lines):** maps libc/POSIX syscalls
  (time, getrandom, open/close/read/write/rename/unlink/access,
  socket/setsockopt/bind/listen/accept/recv/send) to SPARK-friendly
  contracts. Each call carries an explicit `Import, Convention => C`
  declaration in `src/kms_os.ads` with a full `Global`, `Depends`,
  `Post`, and (for procedures) `Always_Terminates` contract, so GNATprove
  treats the boundary as fully specified. The `kms_setsockopt_rcvtimeo`
  function (added in v0.4.0) sets `SO_RCVTIMEO` on accepted connections
  to 10 seconds, preventing a single slow/stalling client from blocking
  the single-threaded server indefinitely.
- **Why it exists:** syscalls cannot be expressed in portable SPARK;
  the shim is the standard AdaCore pattern (same shape as SPARKNaCl's own
  platform layer) and keeps every trusted Ada unit `SPARK_Mode => On`.
- **Review evidence:** the shim is short, single-purpose, side-effect
  visible only through the declared contracts, and is the subject of the
  runtime smoke/roundtrip tests. It is compiled with `-O2 -Wall -Wextra
  -Werror` (2026-09-12 hardening) and must show zero warnings.
- **Other non-SPARK code (NOT part of proof, no security logic):**
  `main.adb`/`admin.adb` (CLI parsing, heap `new Keystore` for 13 MB to
  avoid 8 MB stack overflow, `Ada.Text_IO/Command_Line/Environment_Variables`
  with `Constraint_Error` handlers), `tests/*.adb` (harness, needs 64 MB
  stack for 13 MB Keystore + 120 KB Response), `tests/*.sh/*.py`,
  `deploy/*`, GNAT full runtime + libc/POSIX, prebuilt `lib/libSparknacl.a`
  (reproducible artifact, rebuild via `gprbuild -P anontoken.gpr`). All
  security decisions live in the 11 proved units; wrappers only move bytes.
  Strict “zero C / zero non-SPARK Ada” is infeasible for a POSIX server —
  claimed here as controlled boundary, NOT as proved code.

## 7. Hardware / environment assumptions (listed & controlled)

1. **POSIX OS** (Linux host and AArch64 Pi target) with the syscalls
   used by the shim; the Windows target was removed. CONTROL: shim is
   POSIX-only, fails closed on syscall error (`-1` → 401/404/500, never
   silent use); deploy binds `127.0.0.1` behind Cloudflare Tunnel.
2. **System RNG available and trusted**: `getrandom` must deliver
   cryptographic entropy; on failure the server **fails closed**
   (`Random_Bytes` OK=False ⇒ key generation refused — proven). CONTROL:
   `kms_getrandom` loops on `EINTR`, `*ok=0` on refusal; `Kms_Server`
   turns `Req_Create` into `Req_None→500`, `admin` aborts without writing.
3. **Time source monotone in the expected direction**: the server uses
   wall-clock seconds for key expiry; clock rollback can extend key
   lifetimes (documented operational assumption, not a proof gap).
   CONTROL: ops must run NTP/chrony; `Unix_Time Post 0..2**62` proved.
4. **Single-threaded event loop**: one accept loop, no concurrency
   (documented F1 accepted risk in `anontoken.txt`). CONTROL:
   `SO_RCVTIMEO 10s` anti-slowloris + `SO_REUSEADDR`; Cloudflare buffers
   upstream; `Backlog 16` proved.
5. **Keystore/users files owned by the server account**, file mode 0600
   (the shim opens with `O_CREAT|O_TRUNC|0600`). CONTROL: `install.sh`
   creates `anontoken:anontoken 0750/0600`, atomic `.tmp→rename`, backup
   before upgrade, `deny-all` when users file missing/corrupt (never purge).
6. **Stack vs heap**: the 13 MB keystore is heap-allocated in `main.adb`
   by design; SPARK units never declare it on the stack. CONTROL: `in out`
   param (no `access` in SPARK units), tests need `ulimit -s 65536`.
7. **Bind address/port are configuration inputs** validated by
   `Build_Sockaddr` (proven: only dotted-quad IPv4 accepted). CONTROL:
   `Pre Bind_Len 1..128, Port 1..65535`, CLI/env clamp `Lifetime 1..3650`,
   `Bad_Usage` fail-closed.
8. **GNAT full runtime + libc trusted**: no `zfp`, no formal runtime
   qualification. CONTROL: reproducibility (pinned `gnat_native_16.1.0`,
   double clean runs), `-gnatwa -gnatwe`, vendored SPARKNaCl proof.

## 8. Reproduction commands (from a clean tree)

```bash
# 1. Compile every binary; expect: 0 warnings, 0 errors
gprbuild -P anontoken.gpr -XKMS_MAIN=main.adb -j24 -s -f
gprbuild -P anontoken.gpr -XKMS_MAIN=admin.adb -j24 -s -f
# ... same for tests/t_vectors.adb, t_roundtrip.adb, t_open.adb, t_dispatch.adb

# 2. Proof (clean, level 4, 3 provers) — see run_proof_local.sh
#    (wipes obj/gnatprove, then -f -u over the 11 Kms_* units)
bash run_proof_local.sh   # logs to /tmp/proof_local.log

# 3. Evidence greps
grep -E "Success: all checks proved|not proved|medium:|high:|might not be set" /tmp/proof_local.log
grep -E "^ warning:" /tmp/proof_local.log            # expect nothing
grep -rn "pragma Assume\|Unchecked_Conversion\|SPARK_Mode *=> *Off" src libs/sparknacl/src
grep -rn "pragma Warnings" src libs/sparknacl/src   # expect nothing
grep -rn "\-gnatp\|--proof=\|--no-checks\|--warnings=off" *.gpr libs/sparknacl/*.gpr  # expect nothing after 2026-09-12 fix

# 4. AArch64 cross build (Raspberry Pi) — fully static, 0 warnings, 0 errors
#    (GNAT 16.2.0 Debian-sid cross toolchain; cfg from gprconfig;
#    -largs -static -L<sysroot>/aarch64-linux-gnu/lib for static link)
gprbuild --config=<ca.cgpr> -P cross_a64.gpr -XKMS_MAIN=main.adb -p -j24 -largs -static -L<sysroot>/aarch64-linux-gnu/lib
gprbuild --config=<ca.cgpr> -P cross_a64.gpr -XKMS_MAIN=admin.adb -p -j24 -largs -static -L<sysroot>/aarch64-linux-gnu/lib
# binary: cross-a64/bin/main + admin → deployed to cross/linux-aarch64/
# verify: readelf -h → AArch64; readelf -l → no INTERP (fully static)

# 5. Functional test suites (all PASS)
bash tests/test_auth.sh tests/test_licensing.sh ...  # see tests/
```

## 9. Toolchain (all latest, consistent)

- **Host GNAT/SPARK**: GNAT 16.1.0 + gprbuild 26.0.1 + gnatprove 16.1.0
  (via Alire, `gnat_native_16.1.0_9f74f58a` + `gprbuild_26.0.1_e3f27f25`).
  NOTE (2026-09-12 fix): old §9 text said “26.2” — corrected to 26.0.1 to
  match §1 and `run_proof_*.sh` PATH. Public latest stable is gprbuild
  26.0.0 (Fedora/Rawhide) / 2026.0.0 (MSYS2); 26.0.1 is the Alire-index
  build of the same 26 branch, i.e. newest via Alire.
- **AArch64 cross**: GNAT/GCC **16.2.0** + binutils **2.47** +
  glibc 2.43 + linux-libc-dev 7.x, taken from Debian sid packages
  (`gnat-16-aarch64-linux-gnu`, `gcc-16-aarch64-linux-gnu`, ...) and
  relocated under `/tmp/a64/tc`; a small `gcc` wrapper injects
  `-I/-L/-Wl,-rpath-link` because the relocated sysroot cannot use
  absolute paths (documented in `anontoken.txt`).
- **Provers**: z3, cvc5, alt-ergo (all three used at level 4;
  `--prover=z3,cvc5,altergo`).
- All toolchain/prover versions are the newest stable available from
  their official sources (Alire index / gcc.gnu.org releases / Debian sid).

---

*Last updated: v0.4.0 + STRICT fixes 2026-09-12 — clean level-4 proof RE-RUN
on hardened tree (no suppress switches, sanitize explicit On, -gnatwe/-Werror)
with Alire toolchain GNAT 16.1.0 + gprbuild crate 26.0.1 (binary 26.0.0
2026-04-15) + gnatprove FSF 16.1.0 (Why3 1.8.2+git, Alt-Ergo 2.6.1, cvc5
1.3.2, Z3 4.15.4): 11/11 units rc=0 "Success: all checks proved", 1,852
checks (73/395/479/638/679/1053/1144/1235/1295/1307/1852 cumulative), 0
unproved/medium/high/might-not, 0 warnings; 17 skipped ONLY Import C in
`kms_os.ads`; 0 Assume/Unchecked(code)/Off/Warnings/Suppress in code; 0
weakening switches in any GPR; 6 host binaries rebuild 0 warnings 0 errors
(`-gnatwa -gnatwe`, C `-Wall -Wextra -Werror`, log /tmp/build_main.log);
`t_vectors` ALL PASS (RFC8032), smoke health/create PASS on rebuilt binary.
Windows target removed (shim POSIX-only). Logs: old
`/tmp/proof_RUN2_v040.log`+`/tmp/proof_RUN3_v040.log` (2026-09-09) + NEW
`obj/gnatprove/proof_run_2026-09-12_strict.log` (2026-09-12 06:19-06:35,
kms_http ~10 min) + `obj/gnatprove/gnatprove.out` + `gnatprove.sarif`.
Windows target removed (shim is POSIX-only). Logs:
`/tmp/proof_RUN2_v040.log` + `/tmp/proof_RUN3_v040.log` (11 `rc=0`
units each, `ALL_DONE`, identical results), plus **two further
independent confirmation runs** logged to `/tmp/proof_local.log`
(11/11 `rc=0`, `ALL_DONE`, cumulative `Success: all checks proved
(1852 checks)` — identical numbers again; the latest clean-cache run
finished 2026-09-09 06:56, `kms_http` being the last unit at ~10 min).
The vendored SPARKNaCl
library is inside the proof closure: a clean-cache probe of
`gnatprove -u kms_signer` reports `Analyzed 2 units` —
`kms_signer` (8/8) **and** `sparknacl-sign` (29/29) — 532 checks
proved, 0 unproved (91 kms_signer + 441 SPARKNaCl.Sign).*