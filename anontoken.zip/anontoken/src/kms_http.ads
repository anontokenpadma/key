------------------------------------------------------------------------------
--  Kms_Http : minimal HTTP/1.1 request parsing and API dispatching for the
--  AnonToken key management server.  All parsing / dispatch code is SPARK.
--
--  Endpoints (developer-facing, HTTP Basic Auth required except /health
--  and /keys/<id>/check):
--    GET    /health
--    GET    /keys                        -> own keys only
--    POST   /keys                        body: {"lifetime_minutes": N} or
--                                             {"lifetime_seconds": N}
--                                           (optional; default: server
--                                            lifetime).  Returns the key
--                                            plus its activation secret,
--                                            shown exactly once.
--    GET    /keys/<id>/pub
--    POST   /keys/<id>/sign              body: {"message": "<b64>"}
--    POST   /keys/<id>/verify            body: {"message": "<b64>",
--                                               "signature": "<b64>"}
--    DELETE /keys/<id>                   revoke (owner only)
--
--  Endpoint (customer-facing, public, authenticated by activation secret):
--    POST   /keys/<id>/check             body: {"secret": "<b64 32B>"}
--      First successful check ACTIVATES the key: its TTL starts counting
--      from that moment.  Unactivated keys never expire; activated keys
--      are purged automatically once past their deadline.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Http
  with SPARK_Mode => On
is

   type Request_Kind is (Req_None,
                         Req_Health,
                         Req_List,
                         Req_Create,
                         Req_Check,
                         Req_Public,
                         Req_Sign,
                         Req_Verify,
                         Req_Revoke);

   type Parse_Error is (Err_None,
                        Err_Bad_Request,
                        Err_Not_Found,
                        Err_Method,
                        Err_Too_Large);

   type Parse_Result is (Incomplete, Bad, Good);

   type Request is record
      Kind         : Request_Kind := Req_None;
      Id           : Key_Id       := 0;
      Error        : Parse_Error  := Err_None;
      Body_Data    : Body_Buffer  := (others => 0);
      Body_Len     : N32          := 0;
      --  Authorization header: base64 token after "Basic " (or absent).
      Auth_Present : Boolean       := False;
      Auth_Data    : Auth_Buffer   := (others => 0);
      Auth_Len     : N32           := 0;
   end record;

   --  Parse one HTTP request from Buf (0 .. Len-1).  A request is complete
   --  only when the whole body is present.  Incomplete means: need more
   --  data (call again with a longer buffer).
   procedure Parse (Buf : in  Request_Buffer;
                    Len : in  N32;
                    Req : out Request;
                    Res : out Parse_Result)
     with Global => null,
          Pre  => Buf'First = 0 and then Len <= Buf'Length,
          Post => Req.Body_Len <= Max_Body_Length;

   --  Handle Req: update KS (create/activate/revoke/expire), produce the
   --  HTTP response bytes in Resp (0 .. Resp_Len-1).  Changed is True when
   --  KS was mutated and should be persisted.
   --
   --  Seed / Secret_Seed are fresh 32 random bytes for the request; the
   --  first is used for key identity/derivation on create, the second is
   --  the activation secret of a newly created key (shown once).
   --
   --  Every request except GET /health, POST /keys/<id>/check and
   --  unparseable requests must carry valid Basic credentials; key
   --  operations are additionally scoped to the authenticated account
   --  (developers only ever see the keys they created).
   procedure Dispatch (KS            : in out Keystore;
                       Now           : in     I64;
                       Seed          : in     Seed_Bytes;
                       Secret_Seed   : in     Seed_Bytes;
                       Lifetime_Days : in     I64;
                       Users         : in     User_Table;
                       Req           : in     Request;
                       Resp          : out    Response_Buffer;
                       Resp_Len      : out    N32;
                       Changed       : out    Boolean)
     with Global => null,
          Relaxed_Initialization => Resp,
          Pre  => Resp'First = 0 and then
                  Now >= 0 and then Now <= 2 ** 62 and then
                  Lifetime_Days >= 0 and then Lifetime_Days <= 3650 and then
                  Req.Body_Len <= Max_Body_Length and then
                  Req.Auth_Len <= Max_Auth_Length;

end Kms_Http;
