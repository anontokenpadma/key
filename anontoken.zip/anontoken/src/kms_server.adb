with Ada.Calendar;
with Ada.Exceptions;
with Ada.Streams;
with Ada.Text_IO;
with Interfaces;
use  Interfaces;
with GNAT.Sockets;

with Kms_File;
with Kms_Http;
with Kms_Keystore;
with Kms_Os;
with Kms_Users;

package body Kms_Server
  with SPARK_Mode => Off
is

   use Ada.Exceptions;
   use Ada.Streams;
   use GNAT.Sockets;
   use Kms_File;
   use Kms_Http;
   use Kms_Types;

   ---------
   -- Run --
   ---------

   --  The keystore is 8 MB (65,536 slots) - too large for the task stack,
   --  so it lives on the heap.  It is allocated WITHOUT an initializer: a
   --  big aggregate can be materialised on the stack first, overflowing it
   --  on some toolchains (seen on aarch64/GNAT 14).  Kms_Keystore.Init
   --  below zeroes every slot before first use.
   type Keystore_Ref is access Keystore;

   procedure Run (Cfg : in Config) is
      Server      : Socket_Type;
      Addr        : Sock_Addr_Type;
      KS          : Keystore_Ref := new Keystore;
      Seed        : Seed_Bytes := (others => 0);
      Secret_Seed : Seed_Bytes := (others => 0);
      Req         : Kms_Http.Request;
      Res         : Kms_Http.Parse_Result;
      Resp        : Response_Buffer := (others => 0);
      Resp_Len    : N32 := 0;
      Changed     : Boolean := False;
      Loaded      : Boolean := False;
      Freed       : Boolean := False;
      Users       : User_Table := (others => <>);
      Users_Loaded : Boolean   := False;
      Users_Stamp : Kms_File.File_Stamp :=
        (Exists => False, Size => 0, Time => Ada.Calendar.Clock);
      Bind_Str  : constant String := Cfg.Bind_Address (1 .. Cfg.Bind_Len);
      Path_Str  : constant String :=
        (if Cfg.Path_Len > 0 then Cfg.Keystore_Path (1 .. Cfg.Path_Len)
         else "");
      Users_Str : constant String :=
        (if Cfg.Users_Len > 0 then Cfg.Users_Path (1 .. Cfg.Users_Len)
         else "");

      --  Claim any legacy (pre-ownership, migrated from v1/v2) key for the
      --  first account in the table, so old keys stay visible/manageable
      --  under the per-developer model.  Returns True when a key was
      --  assigned (caller persists).
      function Claim_Legacy_Keys return Boolean is
         First_User : User_Record;
         Got        : Boolean := False;
         Did        : Boolean := False;
      begin
         if not (Cfg.Users_Len > 0 and then Users_Loaded
                   and then Kms_Users.Count (Users) > 0)
         then
            return False;
         end if;
         for I in Users'Range loop
            if Users (I).In_Use then
               First_User := Users (I);
               Got        := True;
               exit;
            end if;
         end loop;
         if not Got then
            return False;
         end if;
         for I in KS.all'Range loop
            if KS.all (I).In_Use and then KS.all (I).Owner_Len = 0 then
               KS.all (I).Owner_Len := First_User.Name_Len;
               KS.all (I).Owner (0 .. First_User.Name_Len - 1) :=
                 First_User.Name (0 .. First_User.Name_Len - 1);
               Did := True;
            end if;
         end loop;
         if Did then
            declare
               N : constant Natural := Natural (First_User.Name_Len);
               S : String (1 .. N);
            begin
               for J in 1 .. N loop
                  S (J) := Character'Val (First_User.Name (N32 (J) - 1));
               end loop;
               Ada.Text_IO.Put_Line
                 ("[anontoken] claimed legacy keys for account '" & S & "'");
            end;
         end if;
         return Did;
      end Claim_Legacy_Keys;

   begin
      Ada.Text_IO.Put_Line
        ("[anontoken] starting v0.2.0 on " & Bind_Str & ":" &
         Positive'Image (Cfg.Port) & " lifetime=" &
         Kms_Types.I64'Image (Cfg.Lifetime_Days) & "d");

      Kms_Keystore.Init (KS.all);
      if Cfg.Path_Len > 0 then
         Loaded := Kms_File.Load (Path_Str, KS.all);
         if Loaded then
            Ada.Text_IO.Put_Line ("[anontoken] keystore loaded from " & Path_Str);
         else
            Ada.Text_IO.Put_Line
              ("[anontoken] no keystore found at " & Path_Str &
               " - starting empty");
         end if;
      end if;
      Kms_Keystore.Expire (KS.all, Kms_Os.Unix_Time, Freed);
      --  persist the purge so expired keys (and their secrets) are also
      --  cleared from the keystore file immediately at boot
      if Freed and then Cfg.Path_Len > 0 then
         Kms_File.Save (Path_Str, KS.all);
      end if;

      --  account table: loaded once here, re-checked per request below
      if Cfg.Users_Len > 0 then
         Users_Stamp := Kms_File.Stat (Users_Str);
         Users_Loaded := Kms_File.Load_Users (Users_Str, Users);
         if Users_Loaded then
            Ada.Text_IO.Put_Line
              ("[anontoken] users loaded from " & Users_Str & " (" &
               Kms_Types.N32'Image (Kms_Users.Count (Users)) &
               " accounts)");
         else
            Ada.Text_IO.Put_Line
              ("[anontoken] no users file at " & Users_Str &
               " - all API requests will be rejected with 401");
         end if;
      end if;

      --  claim legacy (pre-ownership) keys for the first account, so old
      --  keys stay visible/manageable under the new per-developer model
      if Claim_Legacy_Keys and then Cfg.Path_Len > 0 then
         Kms_File.Save (Path_Str, KS.all);
      end if;

      Create_Socket (Server);
      Set_Socket_Option (Server, Socket_Level, (Reuse_Address, True));
      Addr := (Family => Family_Inet,
               Addr   => Inet_Addr (Bind_Str),
               Port   => Port_Type (Cfg.Port));
      Bind_Socket (Server, Addr);
      Listen_Socket (Server, Cfg.Backlog);
      Ada.Text_IO.Put_Line ("[anontoken] listening");

      loop
         declare
            Client : Socket_Type;
            From   : Sock_Addr_Type;
            Buf    : Request_Buffer := (others => 0);
            Len    : N32 := 0;
            Resp_SE : Ada.Streams.Stream_Element_Array (1 .. 8192);
            Sent    : Ada.Streams.Stream_Element_Count;
            Sent_i  : N32;
         begin
            Accept_Socket (Server, Client, From);

            --  Receive chunks until the request parser says it is complete.
            loop
               declare
                  Chunk : Ada.Streams.Stream_Element_Array (1 .. 2048);
                  Last  : Ada.Streams.Stream_Element_Count;
               begin
                  Receive_Socket (Client, Chunk, Last);
                  if Last = 0 then
                     exit;  --  EOF from the client
                  end if;
                  for I in 1 .. Last loop
                     if Len < Request_Buffer'Length then
                        Len := Len + 1;
                        Buf (Len - 1) := Byte (Chunk (I));
                     end if;
                  end loop;
               end;
               Kms_Http.Parse (Buf, Len, Req, Res);
               exit when Res /= Kms_Http.Incomplete;
            end loop;

            if Res = Kms_Http.Incomplete then
               --  any leftover unfinished request is treated as an error
               Req := (Kind => Kms_Http.Req_None, others => <>);
            end if;

            --  reload the account table if the users file changed on disk,
            --  so ``admin add/remove/setpass`` takes effect immediately
            --  (no restart needed)
            if Cfg.Users_Len > 0 then
               declare
                  St : constant Kms_File.File_Stamp :=
                    Kms_File.Stat (Users_Str);
                  Was_Loaded : constant Boolean := Users_Loaded;
               begin
                  if (not Users_Loaded) and then St.Exists then
                     if Kms_File.Load_Users (Users_Str, Users) then
                        Users_Loaded := True;
                        Users_Stamp  := St;
                        Ada.Text_IO.Put_Line
                          ("[anontoken] users reloaded from " & Users_Str);
                     end if;
                  elsif Users_Loaded and then St.Exists
                    and then St /= Users_Stamp
                  then
                     if Kms_File.Load_Users (Users_Str, Users) then
                        Users_Stamp := St;
                        Ada.Text_IO.Put_Line
                          ("[anontoken] users reloaded from " & Users_Str);
                     end if;
                  elsif Users_Loaded and then not St.Exists then
                     --  file deleted: fall back to an empty table (deny all)
                     Kms_Users.Init (Users);
                     Users_Loaded := False;
                  end if;
                  --  when accounts first become available, claim any
                  --  still-unowned legacy keys for the first account
                  if (not Was_Loaded) and then Users_Loaded then
                     if Claim_Legacy_Keys and then Cfg.Path_Len > 0 then
                        Kms_File.Save (Path_Str, KS.all);
                     end if;
                  end if;
               end;
            end if;

            Kms_Os.Random_Bytes (Seed);
            Kms_Os.Random_Bytes (Secret_Seed);
            Kms_Http.Dispatch
              (KS.all, Kms_Os.Unix_Time, Seed, Secret_Seed,
               Cfg.Lifetime_Days,
               Users, Req, Resp, Resp_Len, Changed);

            --  copy the response into a stream element buffer and send it
            for J in 1 .. Positive (Resp_Len) loop
               Resp_SE (Stream_Element_Offset (J)) :=
                 Ada.Streams.Stream_Element (Resp (N32 (J - 1)));
            end loop;

            if Resp_Len > 0 then
               Sent_i := 1;
               while Sent_i <= Resp_Len loop
                  Send_Socket
                    (Client,
                     Resp_SE (Stream_Element_Offset (Sent_i)
                                .. Stream_Element_Offset (Resp_Len)),
                     Sent);
                  exit when Sent = 0;
                  Sent_i := Sent_i + N32 (Sent);
               end loop;
            end if;
            Close_Socket (Client);

            if Changed and then Cfg.Path_Len > 0 then
               Kms_File.Save (Path_Str, KS.all);
            end if;
         exception
            when E : others =>
               Ada.Text_IO.Put_Line
                 (Ada.Text_IO.Standard_Error,
                  "[anontoken] connection error: " & Exception_Name (E));
         end;
      end loop;
   exception
      when E : others =>
         Ada.Text_IO.Put_Line
           (Ada.Text_IO.Standard_Error,
            "[anontoken] fatal: " & Exception_Name (E) & " - " &
            Exception_Message (E));
         Close_Socket (Server);
         raise;
   end Run;

end Kms_Server;