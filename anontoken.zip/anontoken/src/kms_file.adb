with Ada.Calendar;
with Ada.Directories;
with Ada.Exceptions;
with Ada.Streams;
with Ada.Streams.Stream_IO;
with Ada.Text_IO;
with Interfaces;
use  Interfaces;
with GNAT.OS_Lib;

package body Kms_File
  with SPARK_Mode => Off
is

   use Ada.Streams;
   use Ada.Streams.Stream_IO;
   use Kms_Types;

   Magic      : constant String := "ANKT";
   Version_V1 : constant := 1;                     --  fixed 64-slot file
   Version_V2 : constant := 2;                     --  dynamic (live slots only)
   Version_V3 : constant := 3;                     --  dynamic, v3 slots

   Header_Size : constant := 8;
   Slot_Size   : constant := 195;                  --  v3 slot
   Legacy_Slot : constant := 122;                  --  v1/v2 slot

   --  v1 files always had exactly 64 fixed slots.
   Legacy_Keys  : constant := 64;
   subtype Legacy_Index is Key_Index range 0 .. Legacy_Keys - 1;

   --  Users file (magic "ANKU", version 1).
   Users_Max_Entry : constant := 1 + User_Name_Length + 2 * Digest_Length;

   type Bytes is array (Natural range <>) of Byte;

   -------------------
   -- Byte helpers --
   -------------------

   procedure Set_B (A : in out Bytes; Off : in Natural; V : Byte) is
   begin
      A (Off) := V;
   end Set_B;

   function B (A : Bytes; Off : Natural) return Byte is (A (Off));

   procedure Put_U64_LE (A : in out Bytes; Off : in Natural; V : U64) is
      X : U64 := V;
   begin
      for I in 0 .. 7 loop
         Set_B (A, Off + I, Byte (X mod 256));
         X := X / 256;
      end loop;
   end Put_U64_LE;

   function Get_U64_LE (A : Bytes; Off : Natural) return U64 is
      V : U64 := 0;
   begin
      for I in reverse 0 .. 7 loop
         V := V * 256 + U64 (B (A, Off + I));
      end loop;
      return V;
   end Get_U64_LE;

   procedure Put_I64_LE (A : in out Bytes; Off : in Natural; V : I64) is
   begin
      Put_U64_LE (A, Off, U64 (V));
   end Put_I64_LE;

   function Get_I64_LE (A : Bytes; Off : Natural) return I64 is
   begin
      return I64 (Get_U64_LE (A, Off));
   end Get_I64_LE;

   -------------------
   -- Status coding --
   -------------------

   function Status_To_Byte (S : Key_Status) return Byte is
   begin
      case S is
         when Active  => return 0;
         when Expired => return 1;
         when Revoked => return 2;
      end case;
   end Status_To_Byte;

   function Byte_To_Status (B : Byte) return Key_Status is
   begin
      case B is
         when 0 => return Active;
         when 1 => return Expired;
         when 2 => return Revoked;
         when others => return Revoked;
      end case;
   end Byte_To_Status;

   ----------------
   -- v3 slot marshalling --
   ----------------
   --  Layout (195 bytes):
   --    in_use u8 | owner_len u8 | owner 24b | id u64 | pub 32b | sec 64b
   --    | secret 32b | created i64 | activated i64 | expires i64
   --    | ttl i64 | status u8
   --  Offsets: 0 in_use, 1 owner_len, 2..25 owner, 26..33 id,
   --           34..65 pub, 66..129 sec, 130..161 secret,
   --           162..169 created, 170..177 activated, 178..185 expires,
   --           186..193 ttl, 194 status.

   procedure Fill_Slot (S : out Bytes; R : in Key_Record) is
   begin
      S := (others => 0);
      Set_B (S, 0, 1);                                  --  in-use
      Set_B (S, 1, Byte (R.Owner_Len));
      for I in 0 .. N32 (User_Name_Length) - 1 loop
         Set_B (S, 2 + Natural (I), R.Owner (I));
      end loop;
      Put_U64_LE (S, 26, U64 (R.Id));
      for I in R.Pub'Range loop
         Set_B (S, 34 + Natural (I - R.Pub'First), R.Pub (I));
      end loop;
      for I in R.Sec'Range loop
         Set_B (S, 66 + Natural (I - R.Sec'First), R.Sec (I));
      end loop;
      for I in R.Secret'Range loop
         Set_B (S, 130 + Natural (I - R.Secret'First), R.Secret (I));
      end loop;
      Put_I64_LE (S, 162, R.Created_At);
      Put_I64_LE (S, 170, R.Activated_At);
      Put_I64_LE (S, 178, R.Expires_At);
      Put_I64_LE (S, 186, R.Ttl_Secs);
      Set_B (S, 194, Status_To_Byte (R.Status));
   end Fill_Slot;

   procedure Parse_Slot (S : in Bytes; R : out Key_Record) is
      L : Natural;
   begin
      R := (In_Use => False, others => <>);
      if B (S, 0) = 0 then
         return;
      end if;
      R.In_Use     := True;
      L := Natural (B (S, 1));
      if L > User_Name_Length then
         L := 0;
      end if;
      R.Owner_Len := N32 (L);
      for J in 0 .. N32 (L) - 1 loop
         R.Owner (J) := B (S, 2 + Natural (J));
      end loop;
      R.Id         := Key_Id (Get_U64_LE (S, 26));
      for I in R.Pub'Range loop
         R.Pub (I) := B (S, 34 + Natural (I - R.Pub'First));
      end loop;
      for I in R.Sec'Range loop
         R.Sec (I) := B (S, 66 + Natural (I - R.Sec'First));
      end loop;
      for I in R.Secret'Range loop
         R.Secret (I) := B (S, 130 + Natural (I - R.Secret'First));
      end loop;
      R.Created_At  := Get_I64_LE (S, 162);
      R.Activated_At := Get_I64_LE (S, 170);
      R.Expires_At  := Get_I64_LE (S, 178);
      R.Ttl_Secs    := Get_I64_LE (S, 186);
      R.Status      := Byte_To_Status (B (S, 194));
   end Parse_Slot;

   -------------------
   -- Stream helpers --
   -------------------

   procedure Write_Bytes (File : in File_Type; A : in Bytes) is
      SE : Stream_Element_Array (1 .. A'Length);
   begin
      for I in SE'Range loop
         SE (I) := Stream_Element (A (Natural (I) - 1 + A'First));
      end loop;
      Write (File, SE);
   end Write_Bytes;

   procedure Write_Header (File : in File_Type; Version : in Natural) is
      H : Bytes (0 .. Header_Size - 1) := (others => 0);
      V : U64 := U64 (Version);
   begin
      Set_B (H, 0, Character'Pos ('A'));
      Set_B (H, 1, Character'Pos ('N'));
      Set_B (H, 2, Character'Pos ('K'));
      Set_B (H, 3, Character'Pos ('T'));
      for I in 0 .. 3 loop
         Set_B (H, 4 + I, Byte (V mod 256));
         V := V / 256;
      end loop;
      Write_Bytes (File, H);
   end Write_Header;

   function Read_Header (File : in File_Type;
                         Version : out Natural) return Boolean is
      SE   : Stream_Element_Array (1 .. Header_Size);
      Last : Stream_Element_Count;
      H    : Bytes (0 .. Header_Size - 1);
      V    : U64 := 0;
   begin
      Read (File, SE, Last);
      if Last /= Header_Size then
         return False;
      end if;
      for I in SE'Range loop
         H (Natural (I) - 1) := Byte (SE (I));
      end loop;
      if H (0) /= Character'Pos ('A') or else
         H (1) /= Character'Pos ('N') or else
         H (2) /= Character'Pos ('K') or else
         H (3) /= Character'Pos ('T')
      then
         return False;
      end if;
      for I in reverse 0 .. 3 loop
         V := V * 256 + U64 (H (4 + I));
      end loop;
      Version := Natural (V);
      return True;
   end Read_Header;

   procedure Write_Slot (File : in File_Type; R : in Key_Record) is
      S : Bytes (0 .. Slot_Size - 1);
   begin
      Fill_Slot (S, R);
      Write_Bytes (File, S);
   end Write_Slot;

   ----------
   -- Load --
   ----------

   --  v1 files: header + exactly 64 fixed 122-byte slots (7816 bytes total).
   --  The header has already been consumed by Read_Header, so only the
   --  64 x 122 = 7808 slot bytes are read here.  v1 keys count their TTL
   --  from creation (old semantics); migrate them as activated-at-creation
   --  with their stored deadline, no activation secret, no owner (the
   --  server claims unowned keys for the operator account after boot).
   function Load_V1 (File : in File_Type; KS : out Keystore) return Boolean is
      Blob : Bytes (0 .. Legacy_Keys * Legacy_Slot - 1)
               := (others => 0);
      SE   : Stream_Element_Array (1 .. Blob'Length);
      Last : Stream_Element_Count;
      Off  : Natural;
   begin
      Read (File, SE, Last);
      if Last /= Stream_Element_Count (Blob'Length) then
         return False;
      end if;
      for I in SE'Range loop
         Blob (Natural (I) - 1) := Byte (SE (I));
      end loop;
      for I in Key_Index'Range loop
         KS (I) := (In_Use => False, others => <>);
      end loop;
      for I in Legacy_Index loop
         Off := Natural (I) * Legacy_Slot;
         if B (Blob, Off) /= 0 then
            KS (I).In_Use      := True;
            KS (I).Id          := Key_Id (Get_U64_LE (Blob, Off + 1));
            for J in KS (I).Pub'Range loop
               KS (I).Pub (J) := B (Blob, Off + 9 + Natural (J - KS (I).Pub'First));
            end loop;
            for J in KS (I).Sec'Range loop
               KS (I).Sec (J) := B (Blob, Off + 41 + Natural (J - KS (I).Sec'First));
            end loop;
            KS (I).Created_At  := Get_I64_LE (Blob, Off + 105);
            KS (I).Expires_At  := Get_I64_LE (Blob, Off + 113);
            KS (I).Status      := Byte_To_Status (B (Blob, Off + 121));
            --  old keys counted their TTL from creation
            KS (I).Activated_At := KS (I).Created_At;
            if KS (I).Expires_At >= KS (I).Created_At then
               KS (I).Ttl_Secs := KS (I).Expires_At - KS (I).Created_At;
            end if;
         end if;
      end loop;
      return True;
   end Load_V1;

   --  v2 files: header + one 122-byte record per live slot, in slot order.
   function Load_V2 (File : in File_Type; KS : out Keystore) return Boolean is
      SE   : Stream_Element_Array (1 .. Legacy_Slot);
      Last : Stream_Element_Count;
   begin
      for I in Key_Index'Range loop
         KS (I) := (In_Use => False, others => <>);
      end loop;
      for I in Key_Index'Range loop
         Read (File, SE, Last);
         exit when Last = 0;                       --  clean end of file
         if Last /= Legacy_Slot then
            return False;                          --  partial record: corrupt
         end if;
         declare
            S : Bytes (0 .. Legacy_Slot - 1);
         begin
            for K in SE'Range loop
               S (Natural (K) - 1) := Byte (SE (K));
            end loop;
            if B (S, 0) /= 0 then
               KS (I).In_Use      := True;
               KS (I).Id          := Key_Id (Get_U64_LE (S, 1));
               for J in KS (I).Pub'Range loop
                  KS (I).Pub (J) := B (S, 9 + Natural (J - KS (I).Pub'First));
               end loop;
               for J in KS (I).Sec'Range loop
                  KS (I).Sec (J) := B (S, 41 + Natural (J - KS (I).Sec'First));
               end loop;
               KS (I).Created_At  := Get_I64_LE (S, 105);
               KS (I).Expires_At  := Get_I64_LE (S, 113);
               KS (I).Status      := Byte_To_Status (B (S, 121));
               KS (I).Activated_At := KS (I).Created_At;
               if KS (I).Expires_At >= KS (I).Created_At then
                  KS (I).Ttl_Secs := KS (I).Expires_At - KS (I).Created_At;
               end if;
            end if;
         end;
      end loop;
      return True;
   end Load_V2;

   --  v3 files: header + one 195-byte record per live slot, in slot order.
   function Load_V3 (File : in File_Type; KS : out Keystore) return Boolean is
      SE   : Stream_Element_Array (1 .. Slot_Size);
      Last : Stream_Element_Count;
   begin
      for I in Key_Index'Range loop
         KS (I) := (In_Use => False, others => <>);
      end loop;
      for I in Key_Index'Range loop
         Read (File, SE, Last);
         exit when Last = 0;                       --  clean end of file
         if Last /= Slot_Size then
            return False;                          --  partial record: corrupt
         end if;
         declare
            S : Bytes (0 .. Slot_Size - 1);
            R : Key_Record;
         begin
            for K in SE'Range loop
               S (Natural (K) - 1) := Byte (SE (K));
            end loop;
            Parse_Slot (S, R);
            KS (I) := R;
         end;
      end loop;
      return True;
   end Load_V3;

   function Load (Path : String; KS : out Keystore) return Boolean is
      File    : File_Type;
      Version : Natural;
   begin
      begin
         Open (File, In_File, Path);
      exception
         when others =>
            return False;
      end;
      if not Read_Header (File, Version) then
         Close (File);
         return False;
      end if;
      if Version = Version_V1 then
         if not Load_V1 (File, KS) then
            Close (File);
            return False;
         end if;
      elsif Version = Version_V2 then
         if not Load_V2 (File, KS) then
            Close (File);
            return False;
         end if;
      elsif Version = Version_V3 then
         if not Load_V3 (File, KS) then
            Close (File);
            return False;
         end if;
      else
         Close (File);
         return False;
      end if;
      Close (File);
      return True;
   end Load;

   ----------
   -- Save --
   ----------

   --  Write header + one record per live slot (file size tracks the number
   --  of live keys, so writes stay small regardless of Max_Keys).
   procedure Save (Path : String; KS : in Keystore) is
      File : File_Type;
      Tmp  : constant String := Path & ".tmp";
      OK   : Boolean := False;
   begin
      begin
         Create (File, Out_File, Tmp);
         Write_Header (File, Version_V3);
         for I in Key_Index'Range loop
            if KS (I).In_Use then
               Write_Slot (File, KS (I));
            end if;
         end loop;
         Close (File);
         GNAT.OS_Lib.Rename_File (Tmp, Path, OK);
         if not OK then
            GNAT.OS_Lib.Delete_File (Tmp, OK);
         end if;
      exception
         when E : others =>
            GNAT.OS_Lib.Delete_File (Tmp, OK);
            Ada.Text_IO.Put_Line
              (Ada.Text_IO.Standard_Error,
               "keystore save failed: " & Ada.Exceptions.Exception_Name (E));
      end;
   end Save;

   ------------------------
   -- Users file helpers --
   ------------------------

   function Read_All (File   : in  File_Type;
                      Buf    : out Bytes;
                      Last_N : out Natural) return Boolean is
      SE   : Stream_Element_Array
               (1 .. Stream_Element_Offset (Buf'Length));
      Last : Stream_Element_Count;
      N    : Natural := 0;
   begin
      Read (File, SE, Last);
      N := Natural (Last);
      if N > Buf'Length then
         return False;
      end if;
      for I in SE'Range loop
         Buf (Natural (I) - 1) := Byte (SE (I));
      end loop;
      Last_N := N;
      return True;
   end Read_All;

   function Get_U32_LE (A : Bytes; Off : Natural) return Interfaces.Unsigned_32 is
      V : Interfaces.Unsigned_32 := 0;
   begin
      for I in reverse 0 .. 3 loop
         V := V * 256 + Interfaces.Unsigned_32 (B (A, Off + I));
      end loop;
      return V;
   end Get_U32_LE;

   ----------
   -- Stat --
   ----------

   function Stat (Path : String) return File_Stamp is
   begin
      if not Ada.Directories.Exists (Path) then
         return (Exists => False, Size => 0, Time => Ada.Calendar.Clock);
      end if;
      return (Exists => True,
              Size   => Natural (Ada.Directories.Size (Path)),
              Time   => Ada.Directories.Modification_Time (Path));
   exception
      when others =>
         return (Exists => False, Size => 0, Time => Ada.Calendar.Clock);
   end Stat;

   ----------------
   -- Load_Users --
   --  header (12 bytes) + count entries:
   --    name_len u8 | name | salt 32 | digest 32
   ----------------

   function Load_Users (Path : String; T : out User_Table) return Boolean is
      File    : File_Type;
      Blob    : Bytes (0 .. 12 + Max_Users * Users_Max_Entry - 1)
                  := (others => 0);
      N       : Natural;
      Off     : Natural := 0;
      Magic_OK : Boolean;
      Count   : Natural;
      N_Len   : Natural;
      P       : Natural;
   begin
      for I in T'Range loop
         T (I) := (In_Use => False, others => <>);
      end loop;
      begin
         Open (File, In_File, Path);
      exception
         when others =>
            return False;
      end;
      if not Read_All (File, Blob, N) then
         Close (File);
         return False;
      end if;
      Close (File);

      if N < 12 then
         return False;
      end if;
      Magic_OK := B (Blob, 0) = Character'Pos ('A') and then
                  B (Blob, 1) = Character'Pos ('N') and then
                  B (Blob, 2) = Character'Pos ('K') and then
                  B (Blob, 3) = Character'Pos ('U');
      if not Magic_OK or else Get_U32_LE (Blob, 4) /= 1 then
         return False;
      end if;
      Count := Natural (Get_U32_LE (Blob, 8));
      if Count > Max_Users then
         return False;
      end if;

      --  Each entry is a fixed 89-byte slot: name_len u8 | name (padded
      --  to User_Name_Length) | salt 32 | digest 32.  Save_Users writes
      --  the salt/digest at fixed offsets, so Load must read them there.
      --  (T was zeroed above, so only the name prefix and both digests
      --  are filled here.)
      Off := 12;
      for I in 0 .. N32 (Count) - 1 loop
         if Off + Users_Max_Entry > N then
            return False;
         end if;
         N_Len := Natural (B (Blob, Off));
         if N_Len = 0 or else N_Len > User_Name_Length then
            return False;
         end if;
         P := Off + 1;
         for J in 0 .. N32 (N_Len) - 1 loop
            T (I).Name (J) := B (Blob, P);
            P := P + 1;
         end loop;
         P := Off + 1 + User_Name_Length;
         for J in T (I).Salt'Range loop
            T (I).Salt (J) := B (Blob, P);
            P := P + 1;
         end loop;
         for J in T (I).Hash'Range loop
            T (I).Hash (J) := B (Blob, P);
            P := P + 1;
         end loop;
         T (I).In_Use   := True;
         T (I).Name_Len := N32 (N_Len);
         Off := Off + Users_Max_Entry;
      end loop;
      return True;
   end Load_Users;

   ----------------
   -- Save_Users --
   ----------------

   procedure Save_Users (Path : String; T : in User_Table) is
      File  : File_Type;
      Tmp   : constant String := Path & ".tmp";
      OK    : Boolean := False;
      Count : Natural := 0;
      Ent   : Bytes (0 .. Users_Max_Entry - 1);
      Hdr   : Bytes (0 .. 11);
      C     : Interfaces.Unsigned_32;
   begin
      for I in T'Range loop
         if T (I).In_Use then
            Count := Count + 1;
         end if;
      end loop;
      begin
         Create (File, Out_File, Tmp);
         Hdr := (others => 0);
         Set_B (Hdr, 0, Character'Pos ('A'));
         Set_B (Hdr, 1, Character'Pos ('N'));
         Set_B (Hdr, 2, Character'Pos ('K'));
         Set_B (Hdr, 3, Character'Pos ('U'));
         C := 1;
         for I in 0 .. 3 loop
            Set_B (Hdr, 4 + I, Byte (C mod 256));
            C := C / 256;
         end loop;
         C := Interfaces.Unsigned_32 (Count);
         for I in 0 .. 3 loop
            Set_B (Hdr, 8 + I, Byte (C mod 256));
            C := C / 256;
         end loop;
         Write_Bytes (File, Hdr);
         for I in T'Range loop
            if T (I).In_Use then
               Ent := (others => 0);
               Set_B (Ent, 0, Byte (T (I).Name_Len));
               for J in 0 .. T (I).Name_Len - 1 loop
                  Set_B (Ent, 1 + Natural (J), T (I).Name (J));
               end loop;
               for J in T (I).Salt'Range loop
                  Set_B (Ent, 1 + User_Name_Length + Natural (J),
                         T (I).Salt (J));
               end loop;
               for J in T (I).Hash'Range loop
                  Set_B (Ent, 1 + User_Name_Length + Digest_Length +
                           Natural (J),
                         T (I).Hash (J));
               end loop;
               --  fixed 89-byte entries (name padded) so Load_Users can
               --  seek the salt/digest at constant offsets
               Write_Bytes (File, Ent);
            end if;
         end loop;
         Close (File);
         GNAT.OS_Lib.Rename_File (Tmp, Path, OK);
         if not OK then
            GNAT.OS_Lib.Delete_File (Tmp, OK);
         end if;
      exception
         when E : others =>
            GNAT.OS_Lib.Delete_File (Tmp, OK);
            Ada.Text_IO.Put_Line
              (Ada.Text_IO.Standard_Error,
               "users save failed: " & Ada.Exceptions.Exception_Name (E));
      end;
   end Save_Users;

end Kms_File;
