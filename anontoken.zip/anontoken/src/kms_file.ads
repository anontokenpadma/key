------------------------------------------------------------------------------
--  Kms_File : persistence of the keystore (non-SPARK veneer).
--  Format (fixed size, little-endian):
--    magic "ANKT" (4 bytes) + version u32 (1) +
--    64 slots of 122 bytes:
--       in_use u8 | id u64 | pub 32b | sec 64b | created i64 | expires i64
--       | status u8
--  Total: 7816 bytes.
--
--  Also persists the owner-managed account table (users file), format:
--    magic "ANKU" (4) + version u32 (1) + count u32 +
--    per user: name_len u8 | name | salt 32b | digest 32b
------------------------------------------------------------------------------

with Ada.Calendar;
with Kms_Types;
use  Kms_Types;

package Kms_File
  with SPARK_Mode => Off
is

   --  Stat information for change detection (the server reloads the
   --  users file when this changes, so ``admin`` changes are seen
   --  without a restart).
   type File_Stamp is record
      Exists : Boolean;
      Size   : Natural;
      Time   : Ada.Calendar.Time;
   end record;

   --  Load the keystore.  Returns False when the file is missing or
   --  corrupt; KS is then left untouched.
   function Load (Path : String; KS : out Keystore) return Boolean;

   --  Atomically replace the keystore file (write temp + rename).
   procedure Save (Path : String; KS : in Keystore);

   --  Stat Path; missing/unreadable files yield Exists => False.
   function Stat (Path : String) return File_Stamp;

   --  Load the account table.  Returns False when the file is missing or
   --  corrupt; T is then left untouched (callers treat it as empty).
   function Load_Users (Path : String; T : out User_Table) return Boolean;

   --  Atomically replace the users file (write temp + rename).
   procedure Save_Users (Path : String; T : in User_Table);

end Kms_File;