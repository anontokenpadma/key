------------------------------------------------------------------------------
--  Kms_Server : TCP server loop (non-SPARK veneer).  All protocol logic
--  lives in the SPARK-proven Kms_Http package; this unit only moves bytes
--  between the socket and Kms_Http.Parse / Kms_Http.Dispatch.  The
--  account table (from the users file) is loaded here on startup and
--  re-loaded whenever the file changes, so ``admin`` updates are picked
--  up without a restart.
------------------------------------------------------------------------------

with Kms_Types;

package Kms_Server
  with SPARK_Mode => Off
is

   type Config is record
      Bind_Address  : String (1 .. 128) := (others => ' ');
      Bind_Len      : Natural           := 9;   --  "127.0.0.1"
      Port          : Positive          := 9999;
      Keystore_Path : String (1 .. 512) := (others => ASCII.NUL);
      Path_Len      : Natural           := 0;   --  0 = no persistence
      Users_Path    : String (1 .. 512) := (others => ASCII.NUL);
      Users_Len     : Natural           := 0;   --  0 = no users file (deny all)
      Lifetime_Days : Kms_Types.I64     := 90;
      Backlog       : Positive          := 16;
   end record;

   procedure Run (Cfg : in Config);

end Kms_Server;