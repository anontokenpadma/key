------------------------------------------------------------------------------
--  Kms_Os : operating-system boundary (non-SPARK veneer).
--  Provides unix time and cryptographically secure random bytes via
--  Linux syscalls (time / getrandom).
------------------------------------------------------------------------------

with Kms_Types;

package Kms_Os
  with SPARK_Mode => Off
is

   function Unix_Time return Kms_Types.I64;

   procedure Random_Bytes (Buf : out Kms_Types.Seed_Bytes);

end Kms_Os;