with Interfaces;
use  Interfaces;

package body Kms_Keystore
  with SPARK_Mode => On
is

   use Kms_Types;

   ----------
   -- Init --
   ----------

   procedure Init (KS : out Keystore) is
   begin
      for I in Key_Index loop
         KS (I) := (In_Use => False, others => <>);
         pragma Loop_Invariant
           (for all J in Key_Index'First .. I => not KS (J).In_Use);
      end loop;
      pragma Assert (Count (KS) = 0);
   end Init;

   -----------
   -- Count --
   -----------

   function Count (KS : Keystore) return N32 is
      C : N32 := 0;
   begin
      for I in Key_Index loop
         if KS (I).In_Use then
            C := C + 1;
         end if;
         pragma Loop_Invariant (C <= I - Key_Index'First + 1);
         pragma Loop_Invariant
           (if (for all J in Key_Index'First .. I => not KS (J).In_Use)
            then C = 0);
      end loop;
      return C;
   end Count;

   --------------
   -- Has_Free --
   --------------

   function Has_Free (KS : Keystore) return Boolean is
   begin
      for I in Key_Index loop
         if not KS (I).In_Use then
            return True;
         end if;
         pragma Loop_Invariant
           (for all J in Key_Index'First .. I => KS (J).In_Use);
      end loop;
      return False;
   end Has_Free;

   ------------
   -- Insert --
   ------------

   procedure Insert (KS      : in out Keystore;
                     Rec     : in     Key_Record;
                     Created : out    Boolean) is
      Done : Boolean := False;
   begin
      Created := False;
      for I in Key_Index loop
         if not KS (I).In_Use then
            KS (I) := Rec;
            Created := True;
            Done    := True;
            exit;
         end if;
         pragma Loop_Invariant
           (for all J in Key_Index'First .. I => KS (J).In_Use);
      end loop;
      pragma Assert (not Created or else Done);
      pragma Assert
        (if not Created then (for all J in Key_Index => KS (J).In_Use));
   end Insert;

   ----------
   -- Find --
   ----------

   procedure Find (KS    : in     Keystore;
                   Id    : in     Key_Id;
                   Found : out    Boolean;
                   Idx   : out    Key_Index) is
   begin
      Found := False;
      Idx   := 0;
      for I in Key_Index loop
         if KS (I).In_Use and then KS (I).Id = Id then
            Found := True;
            Idx   := I;
            exit;
         end if;
         pragma Loop_Invariant
           (for all J in Key_Index'First .. I =>
              (not KS (J).In_Use or else KS (J).Id /= Id));
      end loop;
   end Find;

   ---------
   -- Get --
   ---------

   procedure Get (KS  : in     Keystore;
                  Idx : in     Key_Index;
                  Rec : out    Key_Record) is
   begin
      Rec := KS (Idx);
   end Get;

   -----------
   -- Owned --
   -----------

   function Owned (KS       : in Keystore;
                   Idx      : in Key_Index;
                   Name     : in User_Name_Buffer;
                   Name_Len : in N32) return Boolean is
   begin
      if KS (Idx).Owner_Len /= Name_Len then
         return False;
      end if;
      for J in 0 .. Name_Len - 1 loop
         if KS (Idx).Owner (J) /= Name (J) then
            return False;
         end if;
         pragma Loop_Invariant
           (for all K in 0 .. J => KS (Idx).Owner (K) = Name (K));
      end loop;
      return True;
   end Owned;

   --------------
   -- Activate --
   --------------

   procedure Activate (KS  : in out Keystore;
                       Idx : in     Key_Index;
                       Now : in     I64) is
   begin
      KS (Idx).Activated_At := Now;
      KS (Idx).Expires_At   := Now + KS (Idx).Ttl_Secs;
   end Activate;

   ------------
   -- Expire --
   ------------

   procedure Expire (KS    : in out Keystore;
                     Now   : in     I64;
                     Freed : out    Boolean) is
   begin
      Freed := False;
      for I in Key_Index loop
         if KS (I).In_Use and then KS (I).Activated_At /= 0 and then
            KS (I).Expires_At < Now
         then
            --  an activated key past its deadline: drop secrets, free slot
            KS (I).Sec    := (others => 0);
            KS (I).Secret := (others => 0);
            KS (I).In_Use := False;
            Freed         := True;
         end if;
         pragma Loop_Invariant
           (for all J in Key_Index'First .. I =>
              (not KS (J).In_Use or else
               KS (J).Activated_At = 0 or else
               KS (J).Expires_At >= Now));
      end loop;
   end Expire;

   ------------
   -- Revoke --
   ------------

   procedure Revoke (KS  : in out Keystore;
                     Idx : in     Key_Index) is
   begin
      if KS (Idx).Activated_At = 0 then
         --  never used: free the slot outright
         KS (Idx) := (In_Use => False, others => <>);
      else
         KS (Idx).Status := Revoked;
         KS (Idx).Sec    := (others => 0);
         KS (Idx).Secret := (others => 0);
      end if;
   end Revoke;

end Kms_Keystore;
