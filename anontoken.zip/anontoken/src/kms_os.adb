with Interfaces;
use  Interfaces;
with Interfaces.C;
with System;

package body Kms_Os
  with SPARK_Mode => Off
is

   function C_Time (T : System.Address) return Interfaces.Integer_64
     with Import, Convention => C, External_Name => "time";

   function C_Getrandom (Buf    : System.Address;
                         Buflen : Interfaces.C.size_t;
                         Flags  : Interfaces.C.unsigned)
                        return Interfaces.Integer_64
     with Import, Convention => C, External_Name => "getrandom";

   ---------------
   -- Unix_Time --
   ---------------

   function Unix_Time return Kms_Types.I64 is
   begin
      return C_Time (System.Null_Address);
   end Unix_Time;

   -----------------
   -- Random_Bytes --
   -----------------

   procedure Random_Bytes (Buf : out Kms_Types.Seed_Bytes) is
      R : Interfaces.Integer_64;
   begin
      --  getrandom with flags = 0 blocks until the pool is initialised and
      --  returns the full requested length; retry on transient EINTR.
      loop
         R := C_Getrandom (Buf'Address,
                           Interfaces.C.size_t (Buf'Length),
                           0);
         exit when R = Interfaces.Integer_64 (Buf'Length);
      end loop;
   end Random_Bytes;

end Kms_Os;