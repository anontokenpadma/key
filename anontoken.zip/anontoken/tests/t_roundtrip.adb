with Ada.Text_IO;
with Interfaces;
use  Interfaces;
with Kms_Base64;
with Kms_Http;
with Kms_Json;
with Kms_Keystore;
with Kms_Signer;
with Kms_Types;

procedure T_Roundtrip is
   use Ada.Text_IO;
   use Kms_Types;
   use Kms_Http;

   Buf   : Request_Buffer := (others => 0);
   Req   : Request;
   Res   : Parse_Result;
   Resp  : Response_Buffer := (others => 0);
   Resp_Len : N32 := 0;
   Changed : Boolean := False;
   KS    : Keystore := (others => (In_Use => False, others => <>));
   Seed  : Seed_Bytes := (1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                          11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
                          21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
                          31, 32);

   Sig_B64   : Base64_Buffer := (others => 0);
   Sig_B64_L : N32 := 0;
   Found     : Boolean;
   Idx       : Key_Index := 0;
   Rec       : Key_Record;
   Sig_Dec   : Byte_Array (0 .. 127) := (others => 0);
   Sig_Dec_L : N32 := 0;
   Valid_B64 : Boolean;
   Msg_B64   : constant Byte_Array (0 .. 7) :=
     (Character'Pos ('a'), Character'Pos ('G'), Character'Pos ('V'),
      Character'Pos ('s'), Character'Pos ('b'), Character'Pos ('G'),
      Character'Pos ('8'), Character'Pos ('='));
   Msg_Dec   : Byte_Array (0 .. 127) := (others => 0);
   Msg_Dec_L : N32 := 0;
   V_Sig     : Boolean;
   Signature : Signature_Bytes := (others => 0);

   procedure Dispatch_Raw (Raw : String) is
      L : constant N32 := N32 (Raw'Length);
   begin
      Buf := (others => 0);
      for I in 1 .. L loop
         Buf (I - 1) := Byte (Character'Pos (Raw (Positive (I))));
      end loop;
      Parse (Buf, L, Req, Res);
      Put_Line ("parsed: res=" & Parse_Result'Image (Res) &
                " kind=" & Request_Kind'Image (Req.Kind) &
                " bodylen=" & N32'Image (Req.Body_Len));
      for I in 0 .. 7 loop
         Put (Character'Val (Req.Body_Data (N32 (I))));
      end loop;
      New_Line;
      Resp := (others => 0);
      Resp_Len := 0;
      Changed := False;
      Dispatch (KS, 1_700_000_000, Seed, 90, Req, Resp, Resp_Len, Changed);
   end Dispatch_Raw;

   procedure Show_Resp (Label : String) is
   begin
      Put (Label & ": ");
      for I in 0 .. Resp_Len - 1 loop
         Put (Character'Val (Resp (I)));
      end loop;
      New_Line;
   end Show_Resp;

begin
   Kms_Keystore.Init (KS);

   Dispatch_Raw
     ("POST /keys HTTP/1.1" & ASCII.CR & ASCII.LF &
      "Host: l" & ASCII.CR & ASCII.LF &
      "Content-Length: 0" & ASCII.CR & ASCII.LF &
      "Connection: close" & ASCII.CR & ASCII.LF & ASCII.CR & ASCII.LF);
   Show_Resp ("create");

   Dispatch_Raw
     ("POST /keys/0807060504030201/sign HTTP/1.1" & ASCII.CR & ASCII.LF &
      "Host: l" & ASCII.CR & ASCII.LF &
      "Content-Length: 22" & ASCII.CR & ASCII.LF &
      "Connection: close" & ASCII.CR & ASCII.LF & ASCII.CR & ASCII.LF &
      "{""message"":""aGVsbG8=""}");
   Show_Resp ("sign");
   Put_Line ("changed(sign)=" & Boolean'Image (Changed));

   --  extract the signature string from the sign response
   Sig_B64 := (others => 0);
   Kms_Json.Find_String (Resp (0 .. Resp_Len - 1), Resp_Len,
                         "signature", Found, Sig_B64, Sig_B64_L);
   Put_Line ("signature found=" & Boolean'Image (Found) &
             " b64len=" & N32'Image (Sig_B64_L));

   Put ("HTTP sig b64: ");
   for I in 0 .. Sig_B64_L - 1 loop
      Put (Character'Val (Sig_B64 (I)));
   end loop;
   New_Line;

   --  direct Find_String probe on the parsed body of the LAST request
   declare
      F2 : Boolean := False;
      V2 : Base64_Buffer := (others => 0);
      L2 : N32 := 0;
      M2 : Boolean := True;
   begin
      --  dump the whole body with indexes
      for I in 0 .. Req.Body_Len - 1 loop
         Put (N32'Image (I) & ":");
         Put (Character'Val (Req.Body_Data (N32 (I))));
         Put (" ");
      end loop;
      New_Line;
      --  replicate the pattern check at I = 1
      declare
         Key_S : constant String := "message";
      begin
         for K in Key_S'Range loop
            if Req.Body_Data (N32 (1 + (K - Key_S'First) + 1)) /=
               Byte (Character'Pos (Key_S (K)))
            then
               M2 := False;
            end if;
         end loop;
      end;
      Put_Line ("inline match at 1: " & Boolean'Image (M2));
      Put_Line ("d(1)=" & Boolean'Image
                  (Req.Body_Data (1) = Character'Pos ('"')) &
                " d(9)=" & Boolean'Image
                  (Req.Body_Data (9) = Character'Pos ('"')) &
                " d(10)=" & Boolean'Image
                  (Req.Body_Data (10) = Character'Pos (':')));
      Kms_Json.Find_String (Req.Body_Data, Req.Body_Len, "message",
                            F2, V2, L2);
      Put_Line ("Find_String direct: found=" & Boolean'Image (F2) &
                " len=" & N32'Image (L2));
   end;

   --  decode the signature
   Kms_Base64.Decode (Sig_B64, Sig_B64_L, Sig_Dec, Sig_Dec_L, Valid_B64);
   Put_Line ("sig decode valid=" & Boolean'Image (Valid_B64) &
             " len=" & N32'Image (Sig_Dec_L));
   for K in Signature'Range loop
      Signature (K) := Sig_Dec (K);
   end loop;

   --  decode the message "hello"
   Kms_Base64.Decode (Msg_B64, 8, Msg_Dec, Msg_Dec_L, Valid_B64);
   Put_Line ("msg decode valid=" & Boolean'Image (Valid_B64) &
             " len=" & N32'Image (Msg_Dec_L));

   --  direct crypto check with the stored public key
   Kms_Keystore.Find (KS, 16#0807060504030201#, Found, Idx);
   Put_Line ("key found=" & Boolean'Image (Found));
   Kms_Keystore.Get (KS, Idx, Rec);
   Put ("sec0..7: ");
   for I in 0 .. 7 loop
      Put (Interfaces.Unsigned_8'Image (Rec.Sec (N32 (I))));
   end loop;
   New_Line;
   Put ("msg0..4: ");
   for I in 0 .. 4 loop
      Put (Interfaces.Unsigned_8'Image (Msg_Dec (N32 (I))));
   end loop;
   New_Line;
   declare
      Re_Sig : Signature_Bytes := (others => 0);
      function D (V : Natural) return Character is
      begin
         if V < 10 then
            return Character'Val (Character'Pos ('0') + V);
         else
            return Character'Val (Character'Pos ('a') + V - 10);
         end if;
      end D;
   begin
      Kms_Signer.Sign_Detached (Rec.Sec, Msg_Dec (0 .. 4), Re_Sig);
      Put ("resign sig hex: ");
      for I in 0 .. 63 loop
         Put (D (Natural (Re_Sig (N32 (I))) / 16));
         Put (D (Natural (Re_Sig (N32 (I))) mod 16));
      end loop;
      New_Line;
   end;
   Kms_Signer.Verify_Detached (Rec.Pub, Msg_Dec (0 .. Msg_Dec_L - 1),
                               Signature, V_Sig);
   Put_Line ("DIRECT VERIFY = " & Boolean'Image (V_Sig) &
             "  (must be TRUE)");

   --  negative: verify with a different message must be FALSE
   Kms_Signer.Verify_Detached (Rec.Pub, Msg_Dec (0 .. 0),
                               Signature, V_Sig);
   Put_Line ("DIRECT VERIFY wrong-msg = " & Boolean'Image (V_Sig) &
             "  (must be FALSE)");
end T_Roundtrip;