void fenceit(void);
