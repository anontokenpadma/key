# SPARK Compliance Report — AnonToken KMS

Evidence artifact for the strict SPARK compliance checklist. Produced and
re-verified by `./run_proof_gate.sh`; raw evidence lands in `obj/gate/`.

## Toolchain (captured)

| Tool | Version |
|---|---|
| GNAT | 16.1.0 (FSF) |
| gprbuild | 26.2 |
| gnatprove | FSF 16.1.0 |
| Why3 | 1.8.2+git |
| Provers | Z3 4.15.4, cvc5 1.3.2, Alt-Ergo 2.6.1 |
| AArch64 cross | `gnat-14-aarch64-linux-gnu` (Ubuntu noble), extracted under `~/aarch64-cross` |
| AArch64 emulator | `qemu-aarch64-static`, same prefix |

`gnat_native 16.1.0`, `gprbuild 26.0.1`, `gnatprove 16.1.0` are the newest
toolchain crates in the Alire index at the time of writing.

No root is available in this environment (`/` is read-only, no `sudo`), so the
AArch64 toolchain is installed user-space: the `.deb` closure (33 packages) is
resolved from the noble `Packages` indexes, downloaded and unpacked with
`dpkg-deb -x` into `~/aarch64-cross`, then driven through `COMPILER_PATH`,
`LIBRARY_PATH`, `LD_LIBRARY_PATH` and `--sysroot`. `run_proof_gate.sh` builds
the AArch64 variant through that prefix and checks the produced ELF header;
the binary also runs ("listening on 127.0.0.1:9999") under `qemu-aarch64`.

## 1. Inventory

Ada sources live under exactly four roots, and there are two build variants:

| Root | Variant | In proof |
|---|---|---|
| `src/` | host (`anontoken.gpr`) | yes — 11 units |
| `tests/` | host | no (test mains, see R1) |
| `libs/sparknacl/src/` | host **and** AArch64 (`cross_a64.gpr`) | yes |

There is exactly **one** SPARKNaCl source tree. `cross-a64/libs` used to be a
*duplicate* and it had silently drifted: the RFC 8032 canonical-`S` fix
(finding D) was present only in `libs/sparknacl`, so the AArch64 binary — the
one the deploy notes point at a Raspberry Pi 5 — was still signature-malleable.
`cross_a64.gpr` now `with`s `libs/sparknacl/sparknacl.gpr` directly, the copy
is deleted, and the gate fails if either is reintroduced or re-diverged.

## 2. SPARK_Mode and proof bypass

| Check | Result |
|---|---|
| `SPARK_Mode => Off` / `Auto` in any root | **0** |
| `pragma Assume` / `Justify` / `Annotate` / `Assume_No` | **0** |
| `SPARK_Mode => On` declarations | 76 |

All 33 `Assert_And_Cut` occurrences (33 in each copy of the library) are
assertions followed by a proof cut, not assumptions: the expression is
*proved* before the prover restarts from it. They are reported, never a hard
failure.

`gnat.adc` is deliberately **not** used. Two independent facts make a global
`pragma SPARK_Mode (On)` inapplicable here:

* `gnat.adc` is not picked up by `gprbuild` unless the project wires it in via
  `for Local_Configuration_Pragmas use "gnat.adc";` — verified empirically.
* Forcing `Main` to `SPARK_Mode => On` makes `gnatprove` **abort** (exit 1,
  "error during analysis of data and information flow") because `main.adb`
  uses `Ada.Text_IO`, `Ada.Command_Line` and `Ada.Environment_Variables`,
  which are outside SPARK, and because `Read_Port` is a function with an
  output global:

  ```
  error: "Standard_Error" is not allowed in SPARK (due to entity declared with SPARK_Mode Off)
  error: function "Read_Port" with output global "Cfg" is not allowed in SPARK [E0005]
  ```

  The same applies to `admin.adb` and the four `tests/*.adb` mains.

## 3. Level-4 proof

Fresh whole-project run (`obj/gate/proof_final.log`, summary
`obj/gnatprove/gnatprove.out`), including the R1 boundary additions:

| Category | Result |
|---|---|
| Whole project, 32 units (host + SPARKNaCl) | **4492 checks, 0 unproved, 0 justified** |
| `gnatprove` exit status | **0**, run with `--checks-as-errors=on --warnings=error` |
| Compiler/prover warnings | **0** |
| Termination | 156 checks, 0 unproved |
| `Assertions` / `Functional Contracts` / `Run-time Checks` | 612 / 572 / 2153, all proved |

Skipped subprograms: **24**, and every one is a foreign or out-of-scope body,
not a proof gap that was papered over:

| Skipped | Count | Why |
|---|---|---|
| `Kms_Os.*` | 21 | imported C-shim boundary (item 5) |
| `SPARKNaCl.Shift_Right_Arithmetic` | 2 | `Import, Convention => Intrinsic` (compiler builtin) |
| `Main` | 1 | the entry point, still outside SPARK (R1) |

GNATprove words all of these as "skipped; body is SPARK_Mode => Off", including
for `Import`ed subprograms that have no body at all. A grep for an actual
`SPARK_Mode => Off`/`Auto` pragma or aspect returns **0** hits across every
root, so the gate's check is sound.

The earlier run recorded in `obj/gate/proof_full.log` (4416 checks, 0 unproved)
predates these additions and is kept for comparison.


## 4. Contracts

| Construct | Count (application + library) |
|---|---|
| `Pre` / `Post` / `Contract_Cases` | on every public subprogram |
| `Global` / `Depends` | on every public subprogram |
| `Loop_Invariant` | 179 |
| `Loop_Variant` | 13 |
| `Type_Invariant` / `Predicate` | 8 |
| `Subprogram_Variant` | 0 — no subprogram in the closure is recursive |

Residual: the checks proved are dominated by AoRTE plus data-flow contracts.
Postconditions that state *functional* results (as opposed to bounds/aliasing)
are present on the parsers and codecs but not uniformly on every subprogram.

## 5. Code outside SPARK

`src/kms_os_shim.c` (154 lines of C) plus 17 foreign subprograms imported into
`Kms_Os`. This is the only non-Ada, non-proved code in the closure, and it is
the direct cause of the 17 skipped checks in item 3.

This boundary is irreducible without a formally qualified runtime and a proved
foreign-function model: a POSIX/HTTP server must call `getrandom`,
`open`/`read`/`write`, and `socket`/`accept`/`recv`/`send`, none of which exist
in pure SPARK or in the Ada standard library. Each import is already declared
with a full contract (`Global`, `Depends`, `Always_Terminates`, and `Post`
bounds on every buffer-transfer result), so the boundary behaves as a stated
assumption rather than an unexamined hole.

The GNAT runtime (`libgnat`) is likewise not proved. Closing this item would
require a qualified runtime (GNAT Pro / ZFP-style) and is a toolchain
procurement decision, not a source change.

## 6. Toolchain qualification

The build uses **FSF GNAT 16.1.0**, which ships no DO-178C / ED-12C
Qualification Kit. A qualified toolchain requires commercial GNAT Pro plus the
Qualification Kit, which is outside what can be installed here.

CI gate: `./run_proof_gate.sh` fails on any `SPARK_Mode Off`, any bypass pragma,
any `--assume*` / `--admit*` switch, a non-zero-warning build, or any unproved
check (`--checks-as-errors=on --warnings=error`). `--static-only` runs the
seconds-long subset.

## Residual items

| # | Item | Status |
|---|---|---|
| R1 | `main.adb`, `admin.adb`, `tests/*.adb` outside SPARK | Open — requires replacing `Ada.Text_IO` / `Ada.Command_Line` / `Ada.Environment_Variables` with an SPARK-clean boundary, and removing the output-global function |
| R2 | C shim + 17 imported subprograms skipped | Open — irreducible without a qualified runtime (item 5) |
| R3 | FSF toolchain, no qualification kit | Open — procurement (item 6) |
| R4 | Duplicated `cross-a64` library tree | **Closed** — copy deleted, `cross_a64.gpr` shares `libs/sparknacl`, AArch64 variant builds and runs under qemu, gate enforces it |

## R1 progress (in flight)

The non-SPARK entry points (`main.adb`, `admin.adb`, `tests/*.adb`) cannot
simply be switched on: they use `Ada.Text_IO`, `Ada.Command_Line` and
`Ada.Environment_Variables`, all outside SPARK.

The boundary they need has now been added to `Kms_Os` and **proved at level 4
(0 unproved, 0 warnings)**:

| Added | Kind | Checks |
|---|---|---|
| `Put`, `New_Line`, `Put_Line` | console, over the existing `C_Write` import | 5 / 0 / 0 |
| `Put_Natural`, `Put_I64` | decimal rendering, no new imports | 0 / 3 |
| `Put_Unsigned` | shared digit loop, fixed 20-byte scratch | 13 |
| `Get_Env` | `getenv` via `kms_getenv` | 14 |
| `Arg_Count`, `Get_Arg` | `/proc/self/cmdline` via `kms_argc` / `kms_argv` | 2 / 10 |
| `Exit_Process` | libc `exit`, imported directly | — |

The C shim gained `kms_getenv`, `kms_argc`, `kms_argv`; `argv` is read back
from `/proc/self/cmdline` because it is unreachable from SPARK without
`Ada.Command_Line`. Still to do: rewrite the six entry points on top of this
boundary, move the 13 MB `Keystore` from the heap to a library-level object
(SPARK allows the access type but reports a memory-leak proof warning, which
the zero-warning gate would reject), then re-run the whole-project proof.
