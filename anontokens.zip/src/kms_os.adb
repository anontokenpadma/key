------------------------------------------------------------------------------
--  Kms_Os implementation.  All low-level libc calls are imported directly
--  from the C shim (see the package spec); this body only contains the
--  pure helpers: entropy filling, path building, logging, and sockaddr
--  construction.  No 'Address attribute is used, so the whole unit is
--  provable by gnatprove at level 4.
------------------------------------------------------------------------------

package body Kms_Os
  with SPARK_Mode => On
is

   -----------------
   -- Random_Bytes --
   -----------------

   procedure Random_Bytes (Buf : out Seed_Bytes;
                           OK  :    out Boolean) is
      Tmp : Seed_Bytes := [others => 0];
      Rc  : C_Bool;
   begin
      C_Getrandom (Tmp, C_Size (Tmp'Length), Rc);
      OK  := C_Bool'Pos (Rc) /= 0;  --  shim returns 1 on success
      Buf := Tmp;
   end Random_Bytes;

   --------------
   -- Fill_*  --
   --------------

   procedure Fill_Path (Dst :    out Path_Buf;
                        Src : in     String)
   is
      N : N32;
   begin
      Dst := [others => 0];
      N := N32 (Src'Length);
      for J in 0 .. N - 1 loop
         Dst (J) := Byte (Character'Pos (Src (Src'First + Natural (J))));
      end loop;
      Dst (N) := 0;   --  NUL terminator
   end Fill_Path;

   procedure Fill_Path2 (Dst  :    out Path_Buf;
                         Src  : in     String;
                         Suf  : in     String)
   is
      N  : N32;
      NS : N32;
   begin
      Dst := [others => 0];
      N  := N32 (Src'Length);
      NS := N32 (Suf'Length);
      for J in 0 .. N - 1 loop
         Dst (J) := Byte (Character'Pos (Src (Src'First + Natural (J))));
      end loop;
      for J in 0 .. NS - 1 loop
         Dst (N + J) := Byte (Character'Pos (Suf (Suf'First + Natural (J))));
      end loop;
      Dst (N + NS) := 0;   --  NUL terminator
   end Fill_Path2;

   ------------
   -- Log    --
   ------------

   procedure Log (S : in String) is
      B : Chunk := [others => 0];
      N : N32 := 0;
      R : C_SSize;
   begin
      for J in 0 .. N32 (S'Length) - 1 loop
         exit when J >= N32 (B'Length);
         B (J) := Byte (Character'Pos (S (S'First + Natural (J))));
         N := J + 1;
      end loop;
      if N > 0 then
         C_Write (2, B, C_Size (Natural (N)), R);
      end if;
   end Log;

   -------------------
   -- Put / Put_Line --
   -------------------

   procedure Put (Fd : C_Int; S : String) is
      B : Chunk := [others => 0];
      N : N32 := 0;
      R : C_SSize;
   begin
      if S'Length > 0 then
         for J in 0 .. N32 (S'Length) - 1 loop
            exit when J >= N32 (B'Length);
            B (J) := Byte (Character'Pos (S (S'First + Natural (J))));
            N := J + 1;
         end loop;
      end if;
      if N > 0 then
         C_Write (Fd, B, C_Size (Natural (N)), R);
      end if;
   end Put;

   procedure New_Line (Fd : C_Int) is
      LF : constant String (1 .. 1) := [1 => Character'Val (10)];
   begin
      Put (Fd, LF);
   end New_Line;

   procedure Put_Line (Fd : C_Int; S : String) is
   begin
      Put (Fd, S);
      New_Line (Fd);
   end Put_Line;

   ------------------
   -- Put_Unsigned --
   ------------------
   --  Decimal rendering shared by Put_Natural / Put_I64.  Digits are
   --  produced least-significant first into a fixed 20-byte scratch and
   --  then emitted reversed, so every index is statically bounded and the
   --  digit loop needs no division-dependent invariant.

   procedure Put_Unsigned (Fd : C_Int; V : U64)
     with Global => null,
          Depends => (null => (Fd, V));

   procedure Put_Unsigned (Fd : C_Int; V : U64) is
      D : Byte_Array (0 .. 19) := [others => 0];
      O : Chunk := [others => 0];
      N : U64 := V;
      C : N32 := 0;
      R : C_SSize;
   begin
      for K in N32 range 0 .. 19 loop
         pragma Loop_Invariant (C <= K);
         if N > 0 or else K = 0 then
            D (C) := Byte (Character'Pos ('0')) + Byte (N mod 10);
            N := N / 10;
            C := C + 1;
         end if;
      end loop;
      if C > 0 then
         for J in N32 range 0 .. C - 1 loop
            pragma Loop_Invariant (J <= C);
            O (J) := D (C - 1 - J);
         end loop;
         C_Write (Fd, O, C_Size (Natural (C)), R);
      end if;
   end Put_Unsigned;

   procedure Put_Natural (Fd : C_Int; N : Natural) is
   begin
      Put_Unsigned (Fd, U64 (N));
   end Put_Natural;

   procedure Put_I64 (Fd : C_Int; N : I64) is
   begin
      if N < 0 then
         Put (Fd, "-");
         --  Negating I64'First would overflow a signed expression; use
         --  -(N + 1) + 1, which is exact for every negative value.
         Put_Unsigned (Fd, U64 (-(N + 1)) + 1);
      else
         Put_Unsigned (Fd, U64 (N));
      end if;
   end Put_I64;

   ---------------
   -- Get_Env   --
   ---------------

   procedure Get_Env (Name  : in     String;
                      Value :    out String;
                      Len   :    out Natural;
                      Found :    out Boolean)
   is
      NB : Path_Buf := [others => 0];
      V  : Path_Buf := [others => 0];
      R  : C_SSize;
      N  : Natural;
   begin
      Value := [others => Character'Val (0)];
      Len   := 0;
      Found := False;
      if Name'Length > 0 then
         for J in 0 .. N32 (Name'Length) - 1 loop
            NB (J) := Byte (Character'Pos (Name (Name'First + Natural (J))));
         end loop;
      end if;
      C_Getenv (NB, V, C_Size (V'Length), R);
      if R >= 0 and then Natural (R) <= Value'Length then
         N := Natural (R);
         for J in 0 .. N - 1 loop
            Value (Value'First + J) := Character'Val (V (N32 (J)));
            Len := J + 1;
         end loop;
         Found := True;
      end if;
   end Get_Env;

   ---------------
   -- Arg_Count --
   ---------------

   function Arg_Count return Natural is
      R : constant C_SSize := C_Argc;
   begin
      if R <= 1 then
         return 0;
      else
         return Natural (R) - 1;
      end if;
   end Arg_Count;

   ---------------
   -- Get_Arg   --
   ---------------

   procedure Get_Arg (Index : in     Positive;
                      Value :    out String;
                      Len   :    out Natural;
                      Found :    out Boolean)
   is
      V : Path_Buf := [others => 0];
      R : C_SSize;
      N : Natural;
   begin
      Value := [others => Character'Val (0)];
      Len   := 0;
      Found := False;
      C_Argv (C_SSize (Index), V, C_Size (V'Length), R);
      if R >= 0 and then Natural (R) <= Value'Length then
         N := Natural (R);
         for J in 0 .. N - 1 loop
            Value (Value'First + J) := Character'Val (V (N32 (J)));
            Len := J + 1;
         end loop;
         Found := True;
      end if;
   end Get_Arg;

   -------------------
   -- Build_Sockaddr --
   -------------------

   procedure Build_Sockaddr (Bind_Str : in     String;
                             Port     : in     Positive;
                             A        :    out Sock_Addr;
                             OK       :    out Boolean)
   is
      --  Parse "a.b.c.d" into four octets.  B (1 .. 4) receive them.
      --  V is clamped to 256 so arithmetic never overflows; N is bounded
      --  by the dot count so index checks are trivial.
      B     : array (1 .. 4) of Natural := [others => 0];
      N     : Natural := 1;     --  current octet index (1 .. 5)
      V     : Natural := 0;     --  current octet value, clamped to 256
      Have  : Boolean := False;
      Valid : Boolean := True;
   begin
      A := [others => 0];
      for I in Bind_Str'Range loop
         pragma Loop_Invariant (N >= 1 and then N <= 5);
         pragma Loop_Invariant (V <= 256);
         pragma Loop_Invariant
           (for all K in 1 .. N - 1 => B (K) <= 255);
         declare
            C : constant Character := Bind_Str (I);
         begin
            if C in '0' .. '9' then
               if V <= 255 then
                  V := V * 10 + Character'Pos (C) - Character'Pos ('0');
                  if V > 255 then
                     V := 256;   --  clamp: mark overflow without overflowing
                  end if;
               end if;
               Have := True;
            elsif C = '.' then
               if (not Have) or else V > 255 then
                  Valid := False;
               else
                  if N <= 4 then
                     B (N) := V;
                     N := N + 1;
                  end if;
                  V      := 0;
                  Have   := False;
               end if;
            else
               Valid := False;
            end if;
         end;
      end loop;
      if (not Have) or else V > 255 then
         Valid := False;
      elsif N <= 4 then
         B (N) := V;
      end if;

      OK := Valid and then N = 4;
      if OK then
         --  family AF_INET (2):  u16 little-endian
         A (0) := 2;
         A (1) := 0;
         --  port:  u16 big-endian (network byte order)
         A (2) := Byte (Port / 256);
         A (3) := Byte (Port mod 256);
         --  address:  4 octets in network (big-endian) order
         A (4) := Byte (B (1));
         A (5) := Byte (B (2));
         A (6) := Byte (B (3));
         A (7) := Byte (B (4));
      end if;
   end Build_Sockaddr;

end Kms_Os;