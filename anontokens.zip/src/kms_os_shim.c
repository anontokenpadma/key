/*------------------------------------------------------------------------------
 *  Kms_Os_Shim : minimal C syscall glue for the SPARK Kms_Os boundary.
 *
 *  The Ada package Kms_Os (SPARK_Mode => On) imports these procedures
 *  directly with Convention => C.  Buffers are passed by reference
 *  (GNAT array parameters), results are returned through an explicit
 *  output scalar (GNAT passes out scalars by reference under C
 *  convention).  No 'Address attribute is needed anywhere in Ada.
 *
 *  This file deliberately contains no logic: it forwards each call to the
 *  corresponding operating-system primitive and stores the raw result.
 *
 *  Single supported platform: POSIX/Linux (getrandom, accept4, POSIX
 *  sockets, fd semantics).  Every libc entry point used by Ada
 *  (open/close/rename/unlink/access/socket/bind/listen) goes through a
 *  kms_* wrapper defined here, so the same SPARK code compiles for both
 *  native and cross (aarch64) targets without conditional Ada code.
 *---------------------------------------------------------------------------*/

#define _GNU_SOURCE
#include <stddef.h>
#include <stdint.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/random.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

/*  read(fd, buf, count) -> bytes read / 0 EOF / -1 error  */
void kms_read(int fd, unsigned char *buf, size_t count, int64_t *res)
{
    ssize_t r = read(fd, buf, count);
    *res = (int64_t)r;
}

/*  write(fd, buf, count) -> bytes written / -1 error  */
void kms_write(int fd, const unsigned char *buf, size_t count, int64_t *res)
{
    ssize_t r = write(fd, buf, count);
    *res = (int64_t)r;
}

/*  open(path, flags, mode) -> fd >= 0 or -1  */
int kms_open(const unsigned char *path, int flags, int mode)
{
    return open((const char *)path, flags, mode);
}

int kms_close(int fd)
{
    return close(fd);
}

int kms_rename(const unsigned char *oldp, const unsigned char *newp)
{
    return rename((const char *)oldp, (const char *)newp);
}

int kms_unlink(const unsigned char *path)
{
    return unlink((const char *)path);
}

int kms_access(const unsigned char *path, int mode)
{
    return access((const char *)path, mode);
}

int kms_socket(int domain, int kind, int protocol)
{
    return socket(domain, kind, protocol);
}

int kms_bind(int fd, const unsigned char *addr, int len)
{
    return bind(fd, (const struct sockaddr *)addr, (socklen_t)len);
}

int kms_listen(int fd, int backlog)
{
    return listen(fd, backlog);
}

/*  recv(fd, buf, len, 0) -> bytes read / 0 EOF / -1 error  */
void kms_recv(int fd, unsigned char *buf, size_t len, int64_t *res)
{
    ssize_t r = recv(fd, buf, len, 0);
    *res = (int64_t)r;
}

/*  send(fd, buf, len, 0) -> bytes sent / -1 error  */
void kms_send(int fd, const unsigned char *buf, size_t len, int64_t *res)
{
    ssize_t r = send(fd, buf, len, 0);
    *res = (int64_t)r;
}

/*  accept4(fd, NULL, NULL, 0) -> client fd / -1 error  */
void kms_accept(int fd, int *client)
{
    *client = accept4(fd, NULL, NULL, 0);
}

/*  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &1, 4) -> ok = 1 / 0.  */
int kms_setsockopt_reuse(int fd)
{
    int one = 1;
    int r = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    return (r == 0) ? 1 : 0;
}

/*  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, 16) -> ok = 1 / 0.
 *  Timeout in seconds; each recv() call returns -1/EAGAIN after the
 *  deadline instead of blocking forever.  This prevents a single
 *  stalled connection from blocking the single-threaded server loop.
 */
int kms_setsockopt_rcvtimeo(int fd, int64_t seconds)
{
    struct timeval tv;
    tv.tv_sec  = (time_t)seconds;
    tv.tv_usec = 0;
    int r = setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    return (r == 0) ? 1 : 0;
}

/*  time(NULL) -> seconds since the epoch  */
int64_t kms_time(void)
{
    return (int64_t)time(NULL);
}

/*  getenv(name, buf, size) -> length of the value, or -1 when the variable
 *  is unset or does not fit in buf.  The value is copied into buf (which the
 *  Ada side has zero-initialised) and NUL-terminated, so Kms_Os never has to
 *  touch a char*: the pointer stays inside the shim.
 */
void kms_getenv(const unsigned char *name, unsigned char *buf, size_t size,
                int64_t *res)
{
    const char *v = getenv((const char *)name);
    size_t n;

    if (v == NULL) {
        *res = -1;
        return;
    }
    n = strlen(v);
    if (n + 1 > size) {
        *res = -1;
        return;
    }
    memcpy(buf, v, n);
    buf[n] = 0;
    *res = (int64_t)n;
}

/*  Command line.  argv is not reachable from SPARK without
 *  Ada.Command_Line, so the shim owns it: /proc/self/cmdline is a
 *  NUL-separated argument vector, read once and cached.  Index 0 is the
 *  program name, matching argv; the Ada side exposes Argument (1) as
 *  index 1, exactly like Ada.Command_Line.
 */
#define KMS_CMDLINE_MAX (64u * 1024u)

static unsigned char kms_cmdline[KMS_CMDLINE_MAX];
static size_t kms_cmdline_len;
static int kms_cmdline_loaded;

static void kms_load_cmdline(void)
{
    int fd;
    ssize_t r;

    if (kms_cmdline_loaded)
        return;
    kms_cmdline_loaded = 1;
    kms_cmdline_len = 0;
    fd = open("/proc/self/cmdline", O_RDONLY);
    if (fd < 0)
        return;
    while (kms_cmdline_len < KMS_CMDLINE_MAX) {
        r = read(fd, kms_cmdline + kms_cmdline_len,
                 KMS_CMDLINE_MAX - kms_cmdline_len);
        if (r <= 0)
            break;
        kms_cmdline_len += (size_t)r;
    }
    close(fd);
}

/*  Number of arguments, including the program name.  */
int64_t kms_argc(void)
{
    size_t i = 0, start;
    int64_t n = 0;

    kms_load_cmdline();
    while (i < kms_cmdline_len) {
        start = i;
        while (i < kms_cmdline_len && kms_cmdline[i] != 0)
            i++;
        if (i > start)
            n++;
        if (i < kms_cmdline_len)
            i++;
    }
    return n;
}

/*  Argument at 0-based index -> length copied into buf, or -1 when the
 *  index is out of range or the argument does not fit.
 */
void kms_argv(int64_t index, unsigned char *buf, size_t size, int64_t *res)
{
    size_t i = 0, start;
    int64_t n = 0;

    kms_load_cmdline();
    while (i < kms_cmdline_len) {
        start = i;
        while (i < kms_cmdline_len && kms_cmdline[i] != 0)
            i++;
        if (i > start) {
            size_t len = i - start;
            if (n == index) {
                if (len + 1 > size) {
                    *res = -1;
                    return;
                }
                memcpy(buf, kms_cmdline + start, len);
                buf[len] = 0;
                *res = (int64_t)len;
                return;
            }
            n++;
        }
        if (i < kms_cmdline_len)
            i++;
    }
    *res = -1;
}

/*  getrandom(buf, len, 0); retries on EINTR, fills the whole buffer.
 *  *ok = 1 on success, 0 when the kernel refused (fail-closed on the Ada
 *  side: the caller must never use buf when *ok == 0).
 */
void kms_getrandom(unsigned char *buf, size_t len, char *ok)
{
    for (;;) {
        ssize_t r = getrandom(buf, len, 0);
        if (r == (ssize_t)len) {
            *ok = 1;
            return;
        }
        if (r < 0 && errno == EINTR)
            continue;
        if (r < 0) {
            *ok = 0;                /*  kernel refused  */
            return;
        }
        buf += (size_t)r;
        len -= (size_t)r;
    }
}