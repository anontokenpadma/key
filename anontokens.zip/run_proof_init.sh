#!/usr/bin/env bash
# Re-prove the keystore / users / server units after an in-out refactor.
# Usage: launch in background + monitor: tail -f /tmp/p_init.log
# CI entry point for a full gate run is run_proof_gate.sh.
cd "$(dirname "$0")" || exit 2
export PATH="$HOME/.alire/bin:$HOME/.alire/libexec/spark/bin:$HOME/.local/share/alire/toolchains/gnat_native_16.1.0_9f74f58a/bin:$HOME/.local/share/alire/toolchains/gprbuild_26.0.1_e3f27f25/bin:$PATH"
export GPR_PROJECT_PATH="$(pwd)/libs/sparknacl"
LOG=/tmp/p_init.log
: > "$LOG"
for u in kms_users kms_keystore kms_server; do
  echo "=== $u start $(date +%H:%M:%S) ===" >> "$LOG"
  timeout 3600 gnatprove -P anontoken.gpr --level=4 -j23 --report=all \
      --prover=z3,cvc5,altergo --timeout=120 --steps=400000 --no-inlining \
      -f -u "$u" >> "$LOG" 2>&1
  echo "rc=$? end $(date +%H:%M:%S)" >> "$LOG"
done
echo "=== ALL_DONE $(date +%H:%M:%S) ===" >> "$LOG"
