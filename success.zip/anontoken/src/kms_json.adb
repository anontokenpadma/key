package body Kms_Json
  with SPARK_Mode => On
is

   HT_Byte : constant Byte := Character'Pos (ASCII.HT);

   ------------
   -- Append --
   ------------

   procedure Append (Buf : in out Byte_Array;
                     Pos : in out N32;
                     C   : in     Byte) is
   begin
      Buf (Pos) := C;
      Pos := Pos + 1;
   end Append;

   ----------------
   -- Append_Text --
   ----------------

   procedure Append_Text (Buf : in out Byte_Array;
                          Pos : in out N32;
                          S   : in     String) is
   begin
      for I in S'Range loop
         Buf (Pos + N32 (I - S'First)) := Byte (Character'Pos (S (I)));
      end loop;
      Pos := Pos + N32 (S'Length);
   end Append_Text;

   ----------------
   -- Append_Quoted --
   ----------------

   procedure Append_Quoted (Buf : in out Byte_Array;
                            Pos : in out N32;
                            S   : in     Byte_Array) is
      P0 : constant N32 := Pos;
   begin
      Buf (Pos) := Character'Pos ('"');
      Pos := Pos + 1;
      for I in S'Range loop
         if S (I) = Character'Pos ('"') or else S (I) = Character'Pos ('\') then
            Buf (Pos)     := Character'Pos ('\');
            Buf (Pos + 1) := S (I);
            Pos := Pos + 2;
         else
            Buf (Pos) := S (I);
            Pos := Pos + 1;
         end if;
         pragma Loop_Invariant (Pos >= P0 + (I - S'First) + 2);
         pragma Loop_Invariant (Pos <= P0 + 2 * (I - S'First) + 3);
      end loop;
      Buf (Pos) := Character'Pos ('"');
      Pos := Pos + 1;
   end Append_Quoted;

   ---------------------
   -- Append_Quoted_Text --
   ---------------------

   procedure Append_Quoted_Text (Buf : in out Byte_Array;
                                 Pos : in out N32;
                                 S   : in     String) is
   begin
      Append (Buf, Pos, Character'Pos ('"'));
      Append_Text (Buf, Pos, S);
      Append (Buf, Pos, Character'Pos ('"'));
   end Append_Quoted_Text;

   ---------------------
   -- Append_Quoted_Hex --
   ---------------------

   procedure Append_Quoted_Hex (Buf : in out Byte_Array;
                                Pos : in out N32;
                                H   : in     Hex_Word) is
   begin
      Buf (Pos) := Character'Pos ('"');
      for I in H'Range loop
         Buf (Pos + 1 + N32 (I - H'First)) := H (I);
         pragma Loop_Invariant
           (Pos + 1 + N32 (I - H'First) >= Pos + 1 and then
            Pos + 1 + N32 (I - H'First) <= Pos + N32 (H'Length));
      end loop;
      Buf (Pos + N32 (H'Length) + 1) := Character'Pos ('"');
      Pos := Pos + N32 (H'Length) + 2;
   end Append_Quoted_Hex;

   ----------------
   -- Append_U64 --
   ----------------

   procedure Append_U64 (Buf : in out Byte_Array;
                         Pos : in out N32;
                         V   : in     U64) is
      P0   : constant N32 := Pos;
      Dgts : Byte_Array (0 .. 19) := [others => 0];
      N    : Natural       := 0;
      X    : U64           := V;
   begin
      if V = 0 then
         Buf (Pos) := Character'Pos ('0');
         Pos := Pos + 1;
         return;
      end if;
      while X > 0 loop
         if N >= 20 then
            exit;  --  unreachable for any U64 (2**64-1 has 20 digits)
         end if;
         Dgts (N32 (N)) := Byte (Character'Pos ('0') + Natural (X mod 10));
         X := X / 10;
         N := N + 1;
         pragma Loop_Invariant (N >= 1 and then N <= 20);
      end loop;
      for I in reverse 0 .. N - 1 loop
         Buf (Pos) := Dgts (N32 (I));
         Pos := Pos + 1;
         pragma Loop_Invariant
           (Pos = P0 + N32 (N - I));
      end loop;
   end Append_U64;

   ----------------
   -- Append_Bool --
   ----------------

   procedure Append_Bool (Buf : in out Byte_Array;
                          Pos : in out N32;
                          B   : in     Boolean) is
   begin
      if B then
         Append_Text (Buf, Pos, "true");
      else
         Append_Text (Buf, Pos, "false");
      end if;
   end Append_Bool;

   ------------------
   -- Matches_Key --
   ------------------

   function Matches_Key (Data : Byte_Array;
                         I    : N32;
                         Key  : String) return Boolean
     with Pre => Data'First = 0 and then
                 Data'Length <= Max_Request_Length and then
                 Key'Length <= Max_Short_Length and then
                 I < Data'Length and then
                 I + Key'Length + 1 < Data'Length
   is
   begin
      for K in Key'Range loop
         if Data (I + N32 (K - Key'First) + 1) /=
            Byte (Character'Pos (Key (K)))
         then
            return False;
         end if;
      end loop;
      return True;
   end Matches_Key;

   -----------------
   -- Find_String --
   -----------------

   procedure Find_String (Data    : in  Byte_Array;
                          Len     : in  N32;
                          Key     : in  String;
                          Found   : out Boolean;
                          Val     : out Byte_Array;
                          Val_Len : out N32) is
      --  K/V/J/Too_Long are written inside the scan loop before first
      --  use; no initializer is needed (gnatprove flow proves this).
      K      : N32;
      V      : N32;
      J      : N32;
      Too_Long : Boolean;
   begin
      Found   := False;
      Val_Len := 0;
      --  Fully initialise the output (the caller may read the whole buffer).
      Val := [others => 0];

      if Len > Data'Length then
         return;
      end if;

      --  Scan for the pattern  "key":  (length Key'Length + 3).
      for I in 0 .. Len - 1 loop
         pragma Loop_Invariant (not Found);
         if I + Key'Length + 2 < Len and then
            Data (I) = Character'Pos ('"') and then
            Data (I + Key'Length + 1) = Character'Pos ('"') and then
            Data (I + Key'Length + 2) = Character'Pos (':') and then
            Matches_Key (Data, I, Key)
         then
            K := I + Key'Length + 3;
            --  skip whitespace
            while K < Len and then
              (Data (K) = Character'Pos (' ') or else Data (K) = HT_Byte)
            loop
               K := K + 1;
               pragma Loop_Invariant (K >= I + Key'Length + 3);
               pragma Loop_Invariant (K <= Len);
            end loop;
            if K < Len and then Data (K) = Character'Pos ('"') then
               J := K + 1;
               V := 0;
               Too_Long := False;
               while J < Len and then Data (J) /= Character'Pos ('"') loop
                  if V = Val'Length then
                     Too_Long := True;
                     exit;
                  end if;
                  Val (V) := Data (J);
                  V := V + 1;
                  J := J + 1;
                  pragma Loop_Invariant (V <= Val'Length);
                  pragma Loop_Invariant (J <= Len);
               end loop;
               if not Too_Long and then
                  J < Len and then Data (J) = Character'Pos ('"')
               then
                  Found   := True;
                  Val_Len := V;
                  return;
               end if;
            end if;
            return;  --  matched key but value malformed
         end if;
      end loop;
   end Find_String;

   ----------------
   -- Find_U64 --
   ----------------

   procedure Find_U64 (Data    : in  Byte_Array;
                       Len     : in  N32;
                       Key     : in  String;
                       Found   : out Boolean;
                       Value   : out U64) is
      --  K/V/D are written before first use inside the scan loop.
      K : N32;
      V : U64;
      D : U64;
   begin
      Found := False;
      Value := 0;

      if Len > Data'Length then
         return;
      end if;

      --  Scan for the pattern  "key":  (length Key'Length + 3).
      for I in 0 .. Len - 1 loop
         pragma Loop_Invariant (not Found);
         if I + Key'Length + 2 < Len and then
            Data (I) = Character'Pos ('"') and then
            Data (I + Key'Length + 1) = Character'Pos ('"') and then
            Data (I + Key'Length + 2) = Character'Pos (':') and then
            Matches_Key (Data, I, Key)
         then
            K := I + Key'Length + 3;
            --  skip whitespace
            while K < Len and then
              (Data (K) = Character'Pos (' ') or else Data (K) = HT_Byte)
            loop
               K := K + 1;
               pragma Loop_Invariant (K >= I + Key'Length + 3);
               pragma Loop_Invariant (K <= Len);
            end loop;
            --  value must start with a digit
            if K < Len and then
               Data (K) >= Character'Pos ('0') and then
               Data (K) <= Character'Pos ('9')
            then
               V := 0;
               while K < Len and then
                     Data (K) >= Character'Pos ('0') and then
                     Data (K) <= Character'Pos ('9')
               loop
                  D := U64 (Data (K) - Character'Pos ('0'));
                  if V > (U64'Last - D) / 10 then
                     --  overflow: treat as not found
                     return;
                  end if;
                  V := V * 10 + D;
                  K := K + 1;
                  pragma Loop_Invariant (K <= Len);
               end loop;
               Found := True;
               Value := V;
            end if;
            return;  --  matched key, value scanned (or malformed)
         end if;
      end loop;
   end Find_U64;

end Kms_Json;