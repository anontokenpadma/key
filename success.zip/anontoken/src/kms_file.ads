------------------------------------------------------------------------------
--  Kms_File : persistence of the keystore and of the account table,
--  fully SPARK (SPARK_Mode => On).
--
--  All file I/O goes through the contract-carrying C imports in Kms_Os
--  (open/read/write/rename/unlink/access); none of it uses the non-SPARK
--  Ada stream libraries.  Formats (little-endian):
--
--  Keystore: magic "ANKT" (4) + version u32 +
--    v1: fixed 64 x 122-byte slots
--    v2: one 122-byte record per live slot, in slot order
--    v3: one 195-byte record per live slot, in slot order
--
--  Users: magic "ANKU" (4) + version u32 (1) + count u32 +
--    per user: name_len u8 | name | salt 32 | digest 32
------------------------------------------------------------------------------

with Kms_Types;
use  Kms_Types;

package Kms_File
  with SPARK_Mode => On
is

   --  Load the keystore.  KS is fully overwritten (empty on failure):
   --  the file is missing or corrupt -> OK=False and KS is an empty
   --  table.  The caller never relies on a previous KS value, so the
   --  parameter is an out (the loaded value depends only on Path).
   procedure Load (Path : in  String;
                   KS   :    out Keystore;
                   OK   :    out Boolean)
     with Global => null,
          Pre  => Path'Length <= 507,
          Depends => (KS => Path, OK => Path);

   --  Atomically replace the keystore file (write temp + rename).
   procedure Save (Path : in String; KS : in Keystore)
     with Global => null,
          Pre  => Path'Length <= 507,
          Depends => (null => (Path, KS));

   --  Does Path exist on disk (access(path, F_OK))?
   function Exists (Path : String) return Boolean
     with Global => null,
          Pre  => Path'Length <= 507,
          Depends => (Exists'Result => Path);

   --  Load the account table.  OK=False when the file is missing or
   --  corrupt (T is then left untouched; callers treat it as empty).
   procedure Load_Users (Path : in  String;
                         T    : in out User_Table;
                         OK   :    out Boolean)
     with Global => null,
          Pre  => Path'Length <= 507,
          Depends => (T => (Path, T), OK => Path);

   --  Atomically replace the users file (write temp + rename).
   procedure Save_Users (Path : in String; T : in User_Table)
     with Global => null,
          Pre  => Path'Length <= 507,
          Depends => (null => (Path, T));

end Kms_File;