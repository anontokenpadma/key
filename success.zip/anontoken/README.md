# AnonToken — Hướng dẫn tích hợp (dành cho người sử dụng dịch vụ)

AnonToken là một **dịch vụ ký số qua HTTP/JSON** dùng để bảo vệ phần mềm của
bạn bằng cơ chế license. Bạn tạo key cho từng khách hàng, phần mềm của khách
hàng phone-home mỗi lần chạy để kiểm tra key còn sống không — tất cả không cần
cài đặt gì ở phía bạn, chỉ cần gọi API.

Khóa bí mật được server quản lý và **không bao giờ rời khỏi server** — bạn
chỉ nhận public key, activation secret và chữ ký. Toàn bộ logic server được
chứng minh chặt chẽ bằng SPARK (`gnatprove --level=4`, 0 unproved/0 medium/high
ở các unit server), chữ ký chuẩn **Ed25519 / RFC 8032**.

> 🔐 **Dịch vụ có bảo vệ bằng tài khoản**: mọi endpoint quản lý (trừ
> `GET /health` và `POST /keys/<id>/check`) yêu cầu **HTTP Basic Auth**. Nếu
> bạn chưa có username/password, hãy liên hệ với người vận hành để được cấp
> tài khoản.

> 👨‍💻 Bạn là người vận hành / chủ server? Xem **`ADMIN.md`** (cách chạy server,
> quản lý tài khoản bằng `admin`, cấu hình) — tài liệu này chỉ dành cho người
> **dùng** dịch vụ qua API.

---

## 1. Vai trò (3 bên) và cách hệ thống hoạt động

| Vai trò | Là ai | Tương tác với AnonToken |
|---|---|---|
| **Provider** | Người vận hành server | Cấp tài khoản cho nhà phát triển (`admin` tool) |
| **Nhà phát triển** (bạn) | Người dùng dịch vụ để bảo vệ phần mềm của họ | Có tài khoản, tạo key, ký/verify license |
| **Khách hàng cuối** | Người mua key để dùng phần mềm | Không có tài khoản; phần mềm phone-home bằng key + secret |

**Quy trình một license:**

1. Với mỗi khách hàng, bạn (nhà phát triển) **tạo một key riêng** qua
   `POST /keys` — server trả về `key_id` + `activation_secret` (chỉ hiện
   **một lần duy nhất**).
2. Bạn nhúng `key_id` + `activation_secret` (base64) vào bản cài đặt của
   khách hàng đó.
3. Mỗi lần phần mềm chạy, nó gọi `POST /keys/<id>/check` kèm `secret`.
   - **Lần đầu thành công** → key được **kích hoạt**: TTL bắt đầu đếm từ
     lúc đó.
   - Key **chưa từng được check** → sống vô hạn, không bị xoá.
   - Key đã kích hoạt quá thời hạn → bị **xoá sạch**, check tiếp theo trả
     `404` → phần mềm dừng hoạt động.
4. License ký số: bạn ký dữ liệu license bằng `POST /keys/<id>/sign`, phần
   mềm khách xác minh bằng public key nhúng sẵn (hoặc gọi `/verify`).

> **Nhiều nhà phát triển dùng chung server này:** key được **cách ly theo tài
> khoản** — bạn chỉ thấy/quản lý key do chính tài khoản của bạn tạo ra, không
> ai nhìn thấy key của người khác.

---

## 2. Base URL & đăng nhập

```bash
export BASE=https://anontokenforever.dpdns.org
export ANONTOKEN_USER=alice                      # ← do vận hành cấp
export ANONTOKEN_PASS='a-strong-password'        # ← do vận hành cấp
```

Mọi request trong tài liệu này dùng `$BASE` (chạy phía sau Cloudflare, bật
sẵn HTTPS). Endpoint không cần đăng nhập:

```bash
curl "$BASE/health"
# {"status":"ok","version":"0.3.2","keys":7}
```

Các lệnh có ✅ trong bảng phải kèm `-u "$ANONTOKEN_USER:$ANONTOKEN_PASS"`.
Sai/thiếu tài khoản → `401 unauthorized` + `WWW-Authenticate`.

---

## 3. Tổng quan API

| Method | Path | Mô tả | Auth |
|---|---|---|---|
| `GET` | `/health` | Trạng thái dịch vụ + số key | **Không** |
| `POST` | `/keys` | Tạo key cho một khách hàng | ✅ developer |
| `GET` | `/keys` | Liệt kê key **của tài khoản bạn** | ✅ developer |
| `GET` | `/keys/<id>/pub` | Public key (nhúng vào phần mềm) | ✅ developer |
| `POST` | `/keys/<id>/sign` | Ký license / message | ✅ developer |
| `POST` | `/keys/<id>/verify` | Xác minh chữ ký | ✅ developer |
| `DELETE` | `/keys/<id>` | Thu hồi key của khách hàng | ✅ developer |
| `POST` | `/keys/<id>/check` | Phone-home của phần mềm khách (kích hoạt + kiểm tra TTL) | **Secret riêng** |

Quy ước chung:

- `<id>`: 16 ký tự hex (lấy từ response tạo key).
- Mọi timestamp (`created_at`, `activated_at`, `expires_at`) là **Unix epoch
  (giây)**. `created_at`/`expires_at`/`activated_at` = `0` nghĩa là "chưa kích
  hoạt / chưa có thời hạn".
- Message và chữ ký trao đổi dạng **base64 chuẩn (có padding `=`)**.
- `secret` trong `/check` là base64 của **32 byte** (44 ký tự base64).

> ⚠️ **Quy tắc quan trọng nhất khi tích hợp:** mọi message phải **base64**
> trước khi gửi trong JSON. Ví dụ `hello` → `aGVsbG8=`.

---

## 4. Chi tiết từng endpoint

### 4.1 Tạo key cho khách hàng — `POST /keys`

```bash
curl -u "$ANONTOKEN_USER:$ANONTOKEN_PASS" -X POST "$BASE/keys"
# 201
```

```json
{
  "key_id": "84e717f6f5b0c372",
  "public_key": "UlUXDWyeD/n8bQ/xdfhdOq0D5Dw5FPlui2LgXTNg7AI=",
  "activation_secret": "q8aDeFbHypdEKz5xR2mN9Vv0YrQw6LcTgA==",
  "created_at": 1725000000,
  "ttl_seconds": 7776000
}
```

- **`activation_secret` chỉ xuất hiện ở response này** — server chỉ lưu bản
  băm, không bao giờ hiện lại. Ghi lại ngay; mất secret = không phone-home
  được, phải tạo key mới.
- **TTL**: mặc định dùng lifetime của server (90 ngày); có thể chọn riêng cho
  từng key:

```bash
curl -u "$ANONTOKEN_USER:$ANONTOKEN_PASS" -X POST \
     -d '{"lifetime_minutes": 30}'  "$BASE/keys"   # 30 phút sau khi KÍCH HOẠT
curl -u "$ANONTOKEN_USER:$ANONTOKEN_PASS" -X POST \
     -d '{"lifetime_seconds": 604800}' "$BASE/keys" # 7 ngày
```

- Giới hạn hợp lệ: `lifetime_minutes` 1–525600, `lifetime_seconds` 1–31536000.
- **TTL chỉ bắt đầu đếm khi key được kích hoạt** bởi lần `/check` đầu tiên
  của khách hàng — không phải từ lúc tạo.
- Giới hạn thực tế: tối đa ~65.536 key **đang tồn tại** (key đã kích hoạt hết
  hạn tự xoá → trong thực tế là không giới hạn). `GET /health` hiện tổng số.

### 4.2 Kiểm tra / kích hoạt key (phone-home của khách) — `POST /keys/<id>/check`

**Endpoint public** — phần mềm khách hàng gọi trực tiếp, **không cần tài
khoản**, chỉ cần `secret` của key:

```bash
curl -X POST -d '{"secret":"q8aDeFbHypdEKz5xR2mN9Vv0YrQw6LcTgA=="}' \
     "$BASE/keys/84e717f6f5b0c372/check"
```

- **Lần đầu thành công** → `200`, key được kích hoạt, TTL bắt đầu:

```json
{"key_id":"84e717f6f5b0c372","valid":true,"activated_at":1725000600,"expires_at":1725002400}
```

- **Đã kích hoạt, còn hạn** → `200` với thời hạn còn lại:

```json
{"key_id":"84e717f6f5b0c372","valid":true,"activated_at":1725000600,"expires_at":1725002400}
```

- **Mọi trường hợp không hợp lệ — sai secret, đã thu hồi, không tồn tại,
  hết hạn** → đều trả `404 not_found` GIỐNG NHAU. (`/check` là endpoint
  public; trả lời khác nhau cho từng trường hợp sẽ cho phép người ngoài dò
  trạng thái từng license — còn sống hay đã bị thu hồi.) Phần mềm khách phải
  coi `404` như license không còn hợp lệ.

> Phần mềm khách nên xác minh chữ ký trên response bằng public key nhúng sẵn
> (xem mục 7) để chống giả mạo server, và chỉ coi `valid:true` là được phép
> chạy.

### 4.3 Liệt kê key của tài khoản — `GET /keys`

```bash
curl -u "$ANONTOKEN_USER:$ANONTOKEN_PASS" "$BASE/keys"
```

```json
{"keys":[{"key_id":"84e717f6f5b0c372","status":"active","activated":false,"expires_at":0}]}
```

- Chỉ trả key của **chính tài khoản đang đăng nhập**.
- `status` ∈ `active` | `revoked`. `activated:false` = chưa từng phone-home.
- Liệt kê tối đa 1000 key; tổng số xem `GET /health`.

### 4.4 Public key — `GET /keys/<id>/pub`

```bash
curl -u "$ANONTOKEN_USER:$ANONTOKEN_PASS" "$BASE/keys/84e717f6f5b0c372/pub"
```

```json
{"key_id":"84e717f6f5b0c372","public_key":"UlUXDWyeD/n8bQ/xdfhdOq0D5Dw5FPlui2LgXTNg7AI="}
```

Public key này được **nhúng vào phần mềm của khách** để xác minh chữ ký
license offline (mục 7).

### 4.5 Ký license / message — `POST /keys/<id>/sign`

```bash
M=$(printf '{"app":"myapp","machine":"abc123","expires":"2026-01-01"}' | base64 | tr -d '\n')
curl -u "$ANONTOKEN_USER:$ANONTOKEN_PASS" -X POST \
     -d "{\"message\":\"$M\"}" "$BASE/keys/84e717f6f5b0c372/sign"
```

```json
{"key_id":"84e717f6f5b0c372","signature":"sN1XqZxvTsTsLVWmLZTa/8uUZF9/aT4r48Tqy6R3cP9bWq7QwWfLCpVhZ6v0dGUdBmB8B/n4k37uJX/1y0gYDA=="}
```

- `signature` là base64 của 64 byte chữ ký Ed25519 (RFC 8032).
- Message gốc tối đa ~768 byte (base64 ≤ 1024 ký tự).
- Key đã bị thu hồi → `403 key_unavailable`.

### 4.6 Xác minh chữ ký — `POST /keys/<id>/verify`

```bash
curl -u "$ANONTOKEN_USER:$ANONTOKEN_PASS" -X POST \
     -d '{"message":"aGVsbG8=","signature":"sN1XqZxvTsTsLVWmLZTa/8uUZF9/aT4r48Tqy6R3cP9bWq7QwWfLCpVhZ6v0dGUdBmB8B/n4k37uJX/1y0gYDA=="}' \
     "$BASE/keys/84e717f6f5b0c372/verify"
```

```json
{"key_id":"84e717f6f5b0c372","valid":true}
```

- Sai message/chữ ký → `{"valid":false}` (HTTP vẫn 200).

### 4.7 Thu hồi key khách hàng — `DELETE /keys/<id>`

```bash
curl -u "$ANONTOKEN_USER:$ANONTOKEN_PASS" -X DELETE "$BASE/keys/84e717f6f5b0c372"
```

```json
{"key_id":"84e717f6f5b0c372","status":"revoked"}
```

- Tiếp theo: `/check` → `404` (từ ngoài không phân biệt được revoked), `/sign`
  → `403 key_unavailable` (chủ key nhìn rõ trạng thái).
- `/verify` vẫn hoạt động (chỉ dùng public key) để kiểm toán chữ ký cũ.
- Key **chưa kích hoạt** bị thu hồi là bị xoá hẳn; key đã kích hoạt giữ trạng
  thái `revoked` tới hết hạn rồi tự xoá.

---

## 5. Mã lỗi

Body lỗi luôn dạng: `{"error":"<tên lỗi>"}`

| HTTP | `error` | Khi nào |
|---|---|---|
| 400 | `missing_message` | Thiếu `message` (sign/verify) |
| 400 | `missing_signature` | Thiếu `signature` (verify) |
| 400 | `bad_message` | `message` không phải base64 hợp lệ |
| 400 | `bad_signature` | `signature` không phải base64/không đúng 64 byte |
| 400 | `message_too_large` | Message quá 1024 ký tự base64 |
| 400 | `bad_lifetime` | TTL ngoài giới hạn cho phép |
| 400 | `bad_request` | Yêu cầu sai định dạng |
| 401 | `unauthorized` | Thiếu/sai Basic Auth (endpoint developer). Brute-force được phép không giới hạn — bảo mật nằm ở mật khẩu mạnh (PBKDF2 100.000 vòng, so sánh constant-time) |
| 403 | `key_unavailable` | Key đã bị thu hồi (sign) |
| 404 | `not_found` | `/check` trả 404 cho MỌI trường hợp không hợp lệ (sai secret / revoked / không tồn tại / hết hạn); các endpoint khác: key không tồn tại / không thuộc tài khoản bạn |
| 405 | `method_not_allowed` | Sai method |
| 413 | `payload_too_large` | Body quá lớn |
| 500 | `internal_error` | Lỗi nội bộ |
| 503 | `keystore_full` | Keystore đầy |

---

## 6. Ví dụ tích hợp

### Python (requests)

```python
import requests, base64

BASE = "https://anontokenforever.dpdns.org"
AUTH = ("alice", "a-strong-password")      # ← tài khoản developer

def b64(b: bytes) -> str:
    return base64.b64encode(b).decode()

# 1) tạo key cho khách hàng + lưu secret (TTL 30 phút sau khi kích hoạt)
r = requests.post(f"{BASE}/keys", json={"lifetime_minutes": 30}, auth=AUTH)
key_id  = r.json()["key_id"]
secret  = r.json()["activation_secret"]     # ← chỉ có ở đây một lần

# 2) phone-home mô phỏng (phần mềm khách làm mỗi lần chạy)
chk = requests.post(f"{BASE}/keys/{key_id}/check", json={"secret": secret})
print("valid:", chk.json()["valid"])       # True

# 3) ký license
msg = b'{"machine":"abc123"}'
sig = requests.post(f"{BASE}/keys/{key_id}/sign",
                    json={"message": b64(msg)}, auth=AUTH).json()["signature"]

# 4) xác minh
ok = requests.post(f"{BASE}/keys/{key_id}/verify",
                   json={"message": b64(msg), "signature": sig},
                   auth=AUTH).json()["valid"]
print("signature ok:", ok)
```

### Node.js (fetch)

```javascript
const BASE = "https://anontokenforever.dpdns.org";
const AUTH = "Basic " + Buffer.from("alice:a-strong-password").toString("base64");
const H = { "authorization": AUTH };

(async () => {
  // tạo key
  const k = await (await fetch(`${BASE}/keys`, { method: "POST", headers: H,
    body: JSON.stringify({ lifetime_seconds: 86400 }) })).json();
  const { key_id, activation_secret } = k;

  // phone-home
  const c = await (await fetch(`${BASE}/keys/${key_id}/check`, {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ secret: activation_secret }) })).json();
  console.log("valid:", c.valid);

  // ký + verify
  const msg = Buffer.from("license-data").toString("base64");
  const s = await (await fetch(`${BASE}/keys/${key_id}/sign`, {
    method: "POST", headers: { ...H, "content-type": "application/json" },
    body: JSON.stringify({ message: msg }) })).json();
  const v = await (await fetch(`${BASE}/keys/${key_id}/verify`, {
    method: "POST", headers: { ...H, "content-type": "application/json" },
    body: JSON.stringify({ message: msg, signature: s.signature }) })).json();
  console.log("signature ok:", v.valid);
})();
```

---

## 7. Xác minh chữ ký NƠI KHÁC (trong phần mềm khách, không cần dịch vụ)

Chữ ký là Ed25519 chuẩn (RFC 8032) — phần mềm của khách xác minh độc lập chỉ
với public key nhúng sẵn:

```python
import base64
from nacl.signing import VerifyKey   # pip install pynacl

pub = base64.b64decode("UlUXDWyeD/n8bQ/xdfhdOq0D5Dw5FPlui2LgXTNg7AI=")
sig = base64.b64decode("sN1XqZxvTsTsLVWmLZTa/8uUZF9/aT4r48Tqy6R3cP9bWq7QwWfLCpVhZ6v0dGUdBmB8B/n4k37uJX/1y0gYDA==")
msg = b"license-data"

VerifyKey(pub).verify(msg, sig)   # không ném lỗi = chữ ký hợp lệ
```

> Vì server bắt buộc online mỗi lần chạy, khuyến nghị: phần mềm khách vừa
> xác minh chữ ký của response `/check`, vừa dùng `/keys/<id>/check` (hoặc
> public key ở mục 4.4) để xác nhận license còn sống trước khi chạy.

---

## 8. Lưu ý khi tích hợp

- **Đăng nhập:** mọi endpoint quản lý phải kèm Basic Auth. Mỗi nhà phát triển
  một tài khoản — key cách ly theo tài khoản, không ai thấy key của nhau.
- **Activation secret:** chỉ xem được một lần lúc tạo key. Không lưu secret
  chung cho nhiều khách — **mỗi khách một key riêng**, đúng mô hình bạn chọn.
- **Base64:** message gửi lên phải là base64. Secret trong `/check` là base64
  của 32 byte.
- **TTL:** đếm từ lần `/check` đầu tiên (kích hoạt). Chưa kích hoạt → không
  hết hạn. Hết hạn → xoá sạch, không gia hạn.
- **Thu hồi:** muốn chặn một khách → `DELETE /keys/<id>` — hiệu lực ngay.
- **Khóa bí mật:** không bao giờ xuất ra; ai cũng chỉ nhận public key.
