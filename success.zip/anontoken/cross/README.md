# AnonToken — Cross-build binaries

Two standalone binaries cross-compiled from the **same SPARK source**
(11 units, `SPARK_Mode => On`, gnatprove level 4: **9.122 checks proved,
0 unproved, 0 `pragma Assume`**, 0 `SPARK_Mode => Off`). No code changes were
made for this build — only the C OS shim (`kms_os_shim.c`, the single
documented C exception) is compiled for the target.

Toolchain used (all latest): **GCC/GNAT 16.1.0** + **binutils 2.47** +
**aarch64-linux-gnu** cross toolchain.

## Contents

| File | Target | Runs on |
|---|---|---|
| `linux-aarch64/main`  | AArch64 Linux  | Raspberry Pi 5 (64-bit OS), other ARM64 Linux |
| `linux-aarch64/admin` | AArch64 Linux  | same |

The pair is the server (`main`) and the account manager (`admin`). They are
completely static on Linux (glibc only), so **no runtime or toolchain needs
to be installed** on the target machine.

## Linux (AArch64, e.g. Raspberry Pi)

```bash
chmod +x main admin
./main 0.0.0.0 9999 keystore.bin 90 users.bin   # bind  port  keystore  lifetime-days  users
./admin add alice s3cret                        # manage accounts (same dir)
```

> The default bind address above listens on all interfaces — use
> `127.0.0.1` when a Cloudflare Tunnel / reverse proxy on the same
> machine should be the only entry point.

## Verification notes

- `linux-aarch64/*` were executed and smoke-tested end-to-end under
  `qemu-aarch64` (server boot, health 200, admin add user, create/activate
  key, Ed25519 sign/verify roundtrip — all passed).