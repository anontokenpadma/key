------------------------------------------------------------------------------
--  Kms_Os : operating-system boundary, fully SPARK (SPARK_Mode => On).
--
--  Every direct C-library call (time, getrandom, open/close/read/write/
--  rename/unlink/access, socket/setsockopt/bind/listen/accept/recv/send)
--  is declared here as an imported subprogram with an explicit
--  Global/Depends contract, so all Kms_* units stay SPARK_Mode => On and
--  provable.
--
--  Buffer transfers go through the tiny C shim kms_os_shim.c: each shim
--  procedure receives the buffer by reference (GNAT passes arrays by
--  reference under Convention => C) and returns the raw libc result
--  through an explicit output scalar.  No 'Address attribute is used
--  anywhere, so gnatprove can prove every unit at level 4.
------------------------------------------------------------------------------

with Interfaces;
with Interfaces.C;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Os
  with SPARK_Mode => On
is

   subtype C_Int   is Interfaces.Integer_32;
   subtype C_SSize is Interfaces.Integer_64;
   subtype C_Size  is Interfaces.C.size_t;

   --  Linux flag values used by this project.
   O_RDONLY              : constant C_Int := 0;
   O_WRONLY_TRUNC_CREATE : constant C_Int := 1 + 512 + 64;  -- O_WRONLY|O_TRUNC|O_CREAT
   Path_Mode             : constant C_Int := 384;            --  0600

   AF_INET      : constant C_Int := 2;
   SOCK_STREAM  : constant C_Int := 1;
   SOL_SOCKET   : constant C_Int := 1;
   SO_REUSEADDR : constant C_Int := 2;
   F_OK         : constant C_Int := 0;
   Backlog      : constant C_Int := 16;

   ------------------
   -- Time / RNG  --
   ------------------

   --  time(NULL) -> seconds since the epoch (imported from the shim).
   function Unix_Time return I64
     with Import, Convention => C, External_Name => "kms_time",
          Global => null,
          Depends => (Unix_Time'Result => null),
          Post    => Unix_Time'Result >= 0 and then
                     Unix_Time'Result <= 2 ** 62;

   --  getrandom(buf, len, 0) fills the whole buffer (retries on EINTR).
   --  Imported from the shim; Buf is passed by reference.
   procedure C_Getrandom (Buf : in out Seed_Bytes; Len : in C_Size)
     with Import, Convention => C, External_Name => "kms_getrandom",
          Global => null,
          Always_Terminates,
          Depends => (Buf => (Buf, Len));

   procedure Random_Bytes (Buf : out Seed_Bytes)
     with Global => null,
          Depends => (Buf => null);

   ------------------------
   -- Path / log buffers --
   ------------------------

   subtype Path_Buf is Byte_Array (0 .. 511);

   procedure Fill_Path (Dst :    out Path_Buf;
                        Src : in     String)
     with Global => null,
          Pre  => Src'Length <= Path_Buf'Length - 1,
          Depends => (Dst => Src),
          Post => Dst (N32 (Src'Length)) = 0;

   procedure Fill_Path2 (Dst  :    out Path_Buf;
                         Src  : in     String;
                         Suf  : in     String)
     with Global => null,
          Pre  => Src'Length + Suf'Length <= Path_Buf'Length - 1,
          Depends => (Dst => (Src, Suf)),
          Post => Dst (N32 (Src'Length + Suf'Length)) = 0;

   -----------------------------
   --  Low-level file I/O     --
   -----------------------------

   --  open(path, flags[, mode]) -> fd (>=0) or -1 on error.
   --  Routed through the shim (kms_*) so the same SPARK code works on
   --  both POSIX and Windows (CRT/WinSock) without conditional Ada.
   function C_Open (Path : in Path_Buf; Flags : in C_Int; Mode : in C_Int)
                    return C_Int
     with Import, Convention => C, External_Name => "kms_open",
          Global => null,
          Depends => (C_Open'Result => (Path, Flags, Mode));

   function C_Close (Fd : in C_Int) return C_Int
     with Import, Convention => C, External_Name => "kms_close",
          Global => null,
          Depends => (C_Close'Result => Fd);

   --  Chunk used for all byte-buffer transfers.
   subtype Chunk is Byte_Array (0 .. 4095);

   --  read(fd, buf, count) -> bytes read > 0, 0 at EOF, -1 on error.
   --  Buf is passed by reference; Res receives the raw libc result.
   --  read(fd, buf, count) -> bytes read > 0, 0 at EOF, -1 on error.
   --  Buf is passed by reference; Res receives the raw libc result.
   --  libc guarantees 0 <= Res <= Count (or Res = -1 on error), so the
   --  shim result is bounded: callers may convert Res to N32 safely.
   procedure C_Read (Fd    : in  C_Int;
                     Buf   : in out Chunk;
                     Count : in  C_Size;
                     Res   :    out C_SSize)
     with Import, Convention => C, External_Name => "kms_read",
          Global => null,
          Always_Terminates,
          Depends => (Buf => (Buf, Fd, Count), Res => (Fd, Count)),
          Post   => Res >= -1 and then Res <= C_SSize (Count);

   --  write(fd, buf, count) -> bytes written, or -1 on error.
   procedure C_Write (Fd    : in  C_Int;
                      Buf   : in  Chunk;
                      Count : in  C_Size;
                      Res   :    out C_SSize)
     with Import, Convention => C, External_Name => "kms_write",
          Global => null,
          Always_Terminates,
          Depends => (Res => (Fd, Count), null => Buf),
          Post   => Res >= -1 and then Res <= C_SSize (Count);

   function C_Rename (Old_Path : in Path_Buf; New_Path : in Path_Buf) return C_Int
     with Import, Convention => C, External_Name => "kms_rename",
          Global => null,
          Depends => (C_Rename'Result => (Old_Path, New_Path));

   function C_Unlink (Path : in Path_Buf) return C_Int
     with Import, Convention => C, External_Name => "kms_unlink",
          Global => null,
          Depends => (C_Unlink'Result => Path);

   --  access(path, F_OK) -> 0 when the path exists.
   function C_Access (Path : in Path_Buf; Mode : in C_Int) return C_Int
     with Import, Convention => C, External_Name => "kms_access",
          Global => null,
          Depends => (C_Access'Result => (Path, Mode));

   -------------------------
   -- Socket primitives   --
   -------------------------

   --  struct sockaddr_in, little-endian u16 family + port, addr bytes.
   --  An array type so GNAT passes it by reference under Convention C.
   type Sock_Addr is array (0 .. 15) of Byte;

   --  socket(AF_INET, SOCK_STREAM, 0) -> fd or -1.
   function C_Socket (Domain   : in C_Int;
                      Kind     : in C_Int;
                      Protocol : in C_Int) return C_Int
     with Import, Convention => C, External_Name => "kms_socket",
          Global => null,
          Depends => (C_Socket'Result => (Domain, Kind, Protocol));

   --  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &1, 4); OK = success.
   --  Imported from the shim; OK is passed by reference (int).
   procedure Set_Reuse (Fd : in C_Int; OK : out Boolean)
     with Import, Convention => C, External_Name => "kms_setsockopt_reuse",
          Global => null,
          Depends => (OK => Fd);

   --  bind(fd, sockaddr_in*, 16) -> 0 / -1.
   --  (A is an array => by reference, exactly like C's const sockaddr*.)
   function C_Bind (Fd : in C_Int; A : in Sock_Addr; Len : in C_Int) return C_Int
     with Import, Convention => C, External_Name => "kms_bind",
          Global => null,
          Depends => (C_Bind'Result => (Fd, A, Len));

   function C_Listen (Fd : in C_Int; N : in C_Int) return C_Int
     with Import, Convention => C, External_Name => "kms_listen",
          Global => null,
          Depends => (C_Listen'Result => (Fd, N));

   --  accept4(fd, NULL, NULL, 0) -> new client fd or -1.
   --  Imported from the shim; Client is passed by reference (int).
   procedure C_Accept (Fd : in C_Int; Client : out C_Int)
     with Import, Convention => C, External_Name => "kms_accept",
          Global => null,
          Depends => (Client => Fd);

   --  recv(fd, buf, len, 0) -> bytes read / 0 EOF / -1 error.
   --  Buf is passed by reference; Res receives the raw libc result.
   procedure C_Recv (Fd  : in  C_Int;
                     Buf : in out Chunk;
                     Len : in  C_Size;
                     Res :    out C_SSize)
     with Import, Convention => C, External_Name => "kms_recv",
          Global => null,
          Always_Terminates,
          Depends => (Buf => (Buf, Fd, Len), Res => (Fd, Len)),
          Post => Res >= -1 and then Res <= C_SSize (Len);

   --  send(fd, buf, len, 0) -> bytes sent / -1 error.
   procedure C_Send (Fd  : in  C_Int;
                     Buf : in  Chunk;
                     Len : in  C_Size;
                     Res :    out C_SSize)
     with Import, Convention => C, External_Name => "kms_send",
          Global => null,
          Always_Terminates,
          Depends => (Res => (Fd, Len), null => Buf),
          Post => Res >= -1 and then Res <= C_SSize (Len);

   --  Build a sockaddr_in for an IPv4 dotted-quad bind address
   --  ("a.b.c.d", e.g. "127.0.0.1"); OK=False on malformed input.
   procedure Build_Sockaddr (Bind_Str : in     String;
                             Port     : in     Positive;
                             A        :    out Sock_Addr;
                             OK       :    out Boolean)
     with Global => null,
          Pre  => Bind_Str'Length <= 128 and then Port <= 65_535,
          Depends => (A => (Bind_Str, Port), OK => Bind_Str),
          Post => (if OK then
                     A (0) = 2 and then A (1) = 0 and then
                     A (2) = Byte (Port / 256) and then
                     A (3) = Byte (Port mod 256));

   -------------
   -- Logging --
   -------------

   --  Write S to standard error (fd 2).  Never raises; result ignored.
   procedure Log (S : in String)
     with Global => null,
          Depends => (null => S);

end Kms_Os;