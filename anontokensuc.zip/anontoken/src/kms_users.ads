------------------------------------------------------------------------------
--  Kms_Users : bounded table of owner-managed accounts, used to enforce
--  HTTP Basic authentication on the API.  Fully SPARK with Global => null.
--
--  A record holds only the username, a random salt and the PBKDF2 digest
--  of the password - never the password itself.  The digest comparison is
--  constant-time (see Verify); the username lookup / failure path in the
--  HTTP layer always performs a dummy password derivation so the timing
--  does not reveal whether the user exists.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Users
  with SPARK_Mode => On
is

   --  Zero every slot.  In out (not out) so flow analysis can prove the
   --  loop without a whole-array aggregate (see Kms_Keystore.Init).
   procedure Init (T : in out User_Table)
     with Global => null,
          Post => (for all I in User_Table'Range => not T (I).In_Use);

   --  Number of in-use slots.
   function Count (T : User_Table) return N32
     with Global => null,
          Post => Count'Result <= Max_Users;

   --  True when the table is not full.
   function Has_Free (T : User_Table) return Boolean
     with Global => null;

   --  Locate the slot holding Name (Name_Len bytes).  Found is False when
   --  the account does not exist (Idx is then 0).
   procedure Find (T       : in     User_Table;
                   Name    : in     User_Name_Buffer;
                   Name_Len : in    N32;
                   Found   :    out Boolean;
                   Idx     :    out N32)
     with Global => null,
          Pre  => Name_Len <= User_Name_Length,
          Post => (if Found then
                     Idx < User_Table'Length and then
                     T (Idx).In_Use and then
                     T (Idx).Name_Len = Name_Len and then
                     T (Idx).Name (0 .. Name_Len - 1) = Name (0 .. Name_Len - 1)
                   else
                     Idx = 0);

   --  Copy the record at Idx out.
   procedure Get (T   : in     User_Table;
                  Idx : in     N32;
                  Rec :    out User_Record)
     with Global => null,
          Pre  => Idx < User_Table'Length and then T (Idx).In_Use,
          Post => Rec = T (Idx);

   --  Insert a copy of Rec into the first free slot.  Added is False when
   --  the table is full or a user with the same name already exists (in
   --  either case T is unchanged).
   procedure Add (T     : in out User_Table;
                  Rec   : in     User_Record;
                  Added :    out Boolean)
     with Global => null,
          Pre  => Rec.In_Use and then Rec.Name_Len <= User_Name_Length,
          Post => (if Added then
                     (for some I in User_Table'Range =>
                        T (I).In_Use and then T (I) = Rec)
                   else
                     T = T'Old);

   --  Free the slot at Idx (In_Use := False) and zeroise its secret
   --  material (name, salt and digest).
   procedure Remove (T   : in out User_Table;
                     Idx : in     N32)
     with Global => null,
          Pre  => Idx < User_Table'Length and then T (Idx).In_Use,
          Post => not T (Idx).In_Use and then
                  (for all I in T'Range =>
                     (if I /= Idx then T (I) = T'Old (I) else
                        (T (I).Name = (User_Name_Buffer'(others => 0)) and then
                         T (I).Salt = (Digest_Bytes'(others => 0)) and then
                         T (I).Hash = (Digest_Bytes'(others => 0)))));

   --  Constant-time digest comparison: Ok is True iff Stored = Presented.
   --  The loop touches every byte regardless of where a mismatch occurs.
   procedure Verify (Stored    : in Digest_Bytes;
                     Presented : in Digest_Bytes;
                     Ok        : out Boolean)
     with Global => null,
          Post => Ok = (Stored = Presented);

   --  ------------------------------------------------------------------
   --  Per-account login lockout (anti brute-force).  Attempts is keyed by
   --  the account slot index (parallel to User_Table): an account that
   --  fails Max_Auth_Fails times in a row is locked out for
   --  Auth_Lockout_Secs, during which even a correct password is denied.
   --  Because the server sits behind a tunnel (all peers are 127.0.0.1)
   --  the lock is per account, never per IP.
   --  ------------------------------------------------------------------

   --  Reset every entry (fresh attempt table).
   procedure Init_Attempts (A : in out Attempt_Table)
     with Global => null,
          Post => (for all I in Attempt_Table'Range =>
                     A (I).Fails = 0 and then A (I).Locked_Until = 0);

   --  Called after an authentication attempt for Name (Name_Len bytes):
   --    * unknown account  -> Allow = False (never locked, auth already
   --      failed: the dummy-derivation timing in the HTTP layer hides
   --      whether the account exists);
   --    * locked account   -> Allow = False even when Auth_Ok = True;
   --    * Auth_Ok          -> failures are cleared, Allow = True;
   --    * wrong password   -> failure recorded, Allow = False (a 5th
   --      consecutive failure locks the account).
   procedure Enforce_Lockout (Users    : in     User_Table;
                              Attempts : in out Attempt_Table;
                              Name     : in     User_Name_Buffer;
                              Name_Len : in     N32;
                              Now      : in     I64;
                              Auth_Ok  : in     Boolean;
                              Allow    :    out Boolean)
     with Global => null,
          Pre  => Name_Len >= 1 and then Name_Len <= User_Name_Length and
                  then Now >= 0 and then Now <= 2 ** 62,
          Post => (if Allow then Auth_Ok);

end Kms_Users;