#!/usr/bin/env bash
# Test the v0.2.0 licensing model:
#   - multi-developer: each account only sees/manages its own keys
#   - key created with activation secret (shown once)
#   - TTL only starts counting on first successful /check (lazy activation)
#   - unactivated keys never expire; activated keys are purged at deadline
#   - revoked key: check -> 403, sign -> 403; unactivated revoke frees slot
set -u
cd "$(dirname "$0")/.." || exit 1
BIN=bin/main
ADMIN=bin/admin
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ok: $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  FAIL: $1"; }
check() { # check <desc> <expected> <actual>
  if [ "$2" = "$3" ]; then ok "$1"; else bad "$1 (expected [$2] got [$3])"; fi
}

T=$(mktemp -d)
KS="$T/ks.bin"; US="$T/users.bin"; LOG="$T/server.log"
P1=18701; P2=18702
export ANONTONKEN_KEYSTORE="$KS" ANONTONKEN_USERS="$US" ANONTONKEN_BIND_ADDR=127.0.0.1

cleanup() { pkill -9 -f "bin/main $P1" 2>/dev/null; pkill -9 -f "bin/main $P2" 2>/dev/null; rm -rf "$T"; }
trap cleanup EXIT

"$ADMIN" -f "$US" add dev_alice 'pass-alice-123' >/dev/null
"$ADMIN" -f "$US" add dev_bob   'pass-bob-4567' >/dev/null

B1="http://127.0.0.1:$P1"
A1="dev_alice:pass-alice-123"
A2="dev_bob:pass-bob-4567"

# --- start server ---
ANONTONKEN_PORT=$P1 "$BIN" 127.0.0.1 $P1 "$KS" 90 "$US" >"$LOG" 2>&1 &
SRV=$!
for i in $(seq 1 50); do curl -s -m 1 "$B1/health" >/dev/null 2>&1 && break; sleep 0.1; done

echo "== health (public) =="
H=$(curl -s "$B1/health")
case "$H" in *'"status":"ok"'*) ok "health ok";; *) bad "health: $H";; esac

echo "== no auth -> 401 =="
C=$(curl -s -o /dev/null -w '%{http_code}' "$B1/keys")
check "GET /keys without auth" 401 "$C"

echo "== create key as alice =="
R=$(curl -s -u "$A1" -X POST -d '{"lifetime_seconds": 20}' "$B1/keys")
KID=$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])' 2>/dev/null)
SEC=$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["activation_secret"])' 2>/dev/null)
if [ -n "$KID" ] && [ -n "$SEC" ]; then ok "create returned key_id+secret ($KID)"; else bad "create: $R"; fi

echo "== alice sees her key, list shows activated=false =="
L=$(curl -s -u "$A1" "$B1/keys")
case "$L" in *"$KID"*'"activated":false'*) ok "list shows key unactivated";; *) bad "list: $L";; esac

echo "== bob cannot see alice's key =="
L2=$(curl -s -u "$A2" "$B1/keys")
if echo "$L2" | grep -q "$KID"; then bad "bob sees alice's key"; else ok "bob list empty"; fi

echo "== bob cannot pub/sign/revoke alice's key (404) =="
C=$(curl -s -o /dev/null -w '%{http_code}' -u "$A2" "$B1/keys/$KID/pub")
check "bob GET pub -> 404" 404 "$C"
C=$(curl -s -o /dev/null -w '%{http_code}' -u "$A2" -X POST -d '{"message":"aGVsbG8="}' "$B1/keys/$KID/sign")
check "bob POST sign -> 404" 404 "$C"
C=$(curl -s -o /dev/null -w '%{http_code}' -u "$A2" -X DELETE "$B1/keys/$KID")
check "bob DELETE -> 404" 404 "$C"

echo "== alice can sign (unactivated key still signable) =="
C=$(curl -s -o /dev/null -w '%{http_code}' -u "$A1" -X POST -d '{"message":"aGVsbG8="}' "$B1/keys/$KID/sign")
check "alice sign -> 200" 200 "$C"

echo "== wrong secret on /check -> 404 (uniform, no existence oracle) =="
C=$(curl -s -o /dev/null -w '%{http_code}' -X POST -d '{"secret":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="}' "$B1/keys/$KID/check")
check "check wrong secret" 404 "$C"

echo "== correct secret activates (TTL starts now) =="
R=$(curl -s -X POST -d "{\"secret\":\"$SEC\"}" "$B1/keys/$KID/check")
case "$R" in *'"valid":true'*'"expires_at":'*) ok "check valid: $R";; *) bad "check: $R";; esac

echo "== after activation list shows activated=true =="
L=$(curl -s -u "$A1" "$B1/keys")
case "$L" in *"$KID"*'"activated":true'*) ok "list shows activated=true";; *) bad "list: $L";; esac

echo "== key created but never checked does NOT expire (lazy) =="
R=$(curl -s -u "$A1" -X POST -d '{"lifetime_seconds": 2}' "$B1/keys")
KID2=$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])')
SEC2=$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["activation_secret"])')
sleep 3
C=$(curl -s -o /dev/null -w '%{http_code}' -u "$A1" "$B1/keys/$KID2/pub")
check "unactivated key still alive after TTL passed" 200 "$C"

echo "== but after activation it dies at deadline =="
C=$(curl -s -o /dev/null -w '%{http_code}' -X POST -d "{\"secret\":\"$SEC2\"}" "$B1/keys/$KID2/check")
check "second key activated" 200 "$C"
sleep 4
C=$(curl -s -o /dev/null -w '%{http_code}' -u "$A1" "$B1/keys/$KID2/pub")
check "activated key purged after deadline" 404 "$C"
C=$(curl -s -o /dev/null -w '%{http_code}' -X POST -d "{\"secret\":\"$SEC2\"}" "$B1/keys/$KID2/check")
check "check on expired key -> 404" 404 "$C"

echo "== revoke unactivated key frees it; activated revoke blocks check =="
R=$(curl -s -u "$A1" -X POST -d '{"lifetime_seconds": 60}' "$B1/keys")
KID3=$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])')
SEC3=$(echo "$R" | python3 -c 'import sys,json;print(json.load(sys.stdin)["activation_secret"])')
# activate it first
curl -s -X POST -d "{\"secret\":\"$SEC3\"}" "$B1/keys/$KID3/check" >/dev/null
C=$(curl -s -o /dev/null -w '%{http_code}' -u "$A1" -X DELETE "$B1/keys/$KID3")
check "alice DELETE activated key" 200 "$C"
C=$(curl -s -o /dev/null -w '%{http_code}' -X POST -d "{\"secret\":\"$SEC3\"}" "$B1/keys/$KID3/check")
check "check revoked key -> 404 (uniform)" 404 "$C"
C=$(curl -s -o /dev/null -w '%{http_code}' -u "$A1" -X POST -d '{"message":"aGVsbG8="}' "$B1/keys/$KID3/sign")
check "sign revoked key -> 403" 403 "$C"

echo "== admin list still works (two accounts) =="
N=$("$ADMIN" -f "$US" list | tail -1)
case "$N" in *"2 account(s)"*) ok "admin list: $N";; *) bad "admin list: $N";; esac

echo
echo "RESULT: pass=$PASS fail=$FAIL"
[ "$FAIL" -eq 0 ]
