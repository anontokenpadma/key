#!/usr/bin/env bash
# Test: deleting a user with the admin tool wipes all keys created by
# that user, and they can no longer be validated (/check, /sign, /pub).
set -u
cd "$(dirname "$0")/.."
BIN=./bin/main
ADM=./bin/admin
P=9993
H=http://127.0.0.1:$P
KS=/tmp/tdup_ks.bin
US=/tmp/tdup_users.bin
LOG=/tmp/tdup_server.log

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
sleep 0.5
rm -f "$KS" "$US" "$LOG"

FAIL=0
chk() { if [ "$2" = "$3" ]; then echo "PASS  $1"; else echo "FAIL  $1 (got [$2] want [$3])"; FAIL=1; fi; }
code() { curl -s -o /dev/null -w "%{http_code}" "$@"; }

"$ADM" -f "$US" add alice 'AlicePass123' >/dev/null 2>&1
"$ADM" -f "$US" add bob   'BobPass12345'   >/dev/null 2>&1

setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1

# --- alice creates 2 keys; bob creates 1 key ---
R1=$(curl -s -u alice:AlicePass123 -X POST $H/keys)
K1=$(echo "$R1" | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])')
S1=$(echo "$R1" | python3 -c 'import sys,json;print(json.load(sys.stdin)["activation_secret"])')
R2=$(curl -s -u alice:AlicePass123 -X POST $H/keys)
K2=$(echo "$R2" | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])')
R3=$(curl -s -u bob:BobPass12345 -X POST $H/keys)
K3=$(echo "$R3" | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])')
S3=$(echo "$R3" | python3 -c 'import sys,json;print(json.load(sys.stdin)["activation_secret"])')
chk "health keys=3 before delete" "$(curl -s $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')" "3"

# --- check alice's key1 works before deletion ---
chk "check key1 before delete -> 200" "$(code -X POST -d "{\"secret\":\"$S1\"}" $H/keys/$K1/check)" "200"

# --- delete alice via admin tool ---
"$ADM" -f "$US" remove alice >/dev/null 2>&1
# trigger the per-request users reload
curl -s -o /dev/null $H/health
sleep 0.5

# --- alice's keys are gone from the keystore ---
chk "health keys=1 after delete (bob's only)" "$(curl -s $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')" "1"
chk "alice key1 /check -> 404" "$(code -X POST -d "{\"secret\":\"$S1\"}" $H/keys/$K1/check)" "404"
# /pub is a developer endpoint (Basic Auth).  Alice is gone, so with her
# own credentials it is 401; with bob's (valid) credentials the key no
# longer exists in the keystore, so it must be 404.
chk "alice key1 /pub with alice auth -> 401" "$(code -u alice:AlicePass123 $H/keys/$K1/pub)" "401"
chk "alice key1 /pub with bob auth -> 404"   "$(code -u bob:BobPass12345 $H/keys/$K1/pub)" "404"
chk "alice key2 /pub with bob auth -> 404"   "$(code -u bob:BobPass12345 $H/keys/$K2/pub)" "404"
chk "alice sign -> 401 (no auth)" "$(code -X POST -d '{"message":"aGVsbG8="}' $H/keys/$K1/sign)" "401"

# --- bob's key is untouched and still validates ---
chk "bob key /check -> 200" "$(code -X POST -d "{\"secret\":\"$S3\"}" $H/keys/$K3/check)" "200"
chk "bob key /pub -> 200"   "$(code -u bob:BobPass12345 $H/keys/$K3/pub)" "200"

# --- restart: purge is persisted ---
pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
sleep 0.5
setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1
chk "after restart: health keys=1" "$(curl -s $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')" "1"
chk "after restart: alice key /pub with bob auth -> 404" "$(code -u bob:BobPass12345 $H/keys/$K1/pub)" "404"
chk "after restart: bob key /check -> 200" "$(code -X POST -d "{\"secret\":\"$S3\"}" $H/keys/$K3/check)" "200"

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
echo "RESULT: $([ $FAIL = 0 ] && echo ALL_PASS || echo HAS_FAILURES)"
[ "$FAIL" = 0 ]