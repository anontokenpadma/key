# AnonToken — Hướng dẫn vận hành (dành cho Admin / chủ server)

Tài liệu này dành cho **người vận hành** AnonToken: cài đặt, chạy server, tạo
tài khoản cho nhà phát triển, cấu hình và bảo trì.

> 👨‍💻 Bạn là nhà phát triển **dùng** dịch vụ (tạo key, ký license)? Xem
> **`README.md`** — tài liệu này chỉ nói về việc chạy & quản lý server.

---

## 1. Tổng quan

AnonToken là một **key management + signing server** viết toàn bộ bằng
Ada/SPARK, được chứng minh bằng `gnatprove --level=4` (0 unproved / 0
medium/high ở các unit `Kms_*`). Chữ ký chuẩn **Ed25519 (RFC 8032)**.

Kiến trúc vận hành điển hình:

```
Internet → Cloudflare Tunnel → 127.0.0.1:9999 → anontoken (server)
```

Server nói **HTTP/1.1 + JSON** thuần và được thiết kế để chạy **phía sau
reverse proxy / tunnel**, bind vào `127.0.0.1` — không lộ cổng trực tiếp ra
ngoài.

Gói gồm **2 binary**:

| Binary | Vai trò |
|---|---|
| `main` (server) | Lắng nghe HTTP, quản lý key, ký/xác minh |
| `admin` (quản lý tài khoản) | Tạo / xoá / đổi mật khẩu tài khoản developer |

Trên Raspberry Pi (aarch64) hiện tại:

- `/opt/anontoken/anontoken` — server
- `/opt/anontoken/admin` — quản lý tài khoản
- `/var/lib/anontoken/keystore.bin` — các signing key
- `/var/lib/anontoken/users.bin` — tài khoản được phép gọi API
- Cấu hình runtime: `/etc/default/anontoken`
- Service systemd: `anontoken`

---

## 2. Cách chạy server (binary, không cần cài đặt gì)

Binary **chỉ phụ thuộc glibc** (có sẵn trên mọi máy Linux) — copy sang máy là
chạy, **không cần** GNAT/Ada/SPARK/toolchain. Chọn đúng bộ theo kiến trúc máy:

| Máy | Dùng file |
|---|---|
| PC/server x86_64 (Intel/AMD) | `main.x86_64` + `admin.x86_64` |
| Raspberry Pi / ARM64 | `main.pi.aarch64` + `admin.pi.aarch64` |

Kiểm tra máy thuộc loại nào: `uname -m` → `x86_64` hoặc `aarch64`.

### Cú pháp dòng lệnh

```
anontoken [bind-address] [port] [keystore-file] [lifetime-days] [users-file]
```

| Tham số | Ý nghĩa | Mặc định |
|---|---|---|
| 1 | Bind address | `127.0.0.1` |
| 2 | Port (1..65535) | `9999` |
| 3 | File keystore | `keystore.bin` |
| 4 | Default key lifetime (ngày, 1..3650) | `90` |
| 5 | File users (tài khoản) | *(trống → từ chối mọi request, trừ `/health`)* |

Hoặc qua biến môi trường (CLI ghi đè env): `ANONTONKEN_BIND_ADDR`,
`ANONTONKEN_PORT`, `ANONTONKEN_KEYSTORE`, `ANONTONKEN_LIFETIME_DAYS`,
`ANONTONKEN_USERS`.

> **`lifetime-days` KHÔNG phải thời gian server sống.** Server chạy vô thời
> hạn. Đây chỉ là **thời hạn mặc định của key** khi dev tạo key mà không ghi
> `lifetime_minutes`/`lifetime_seconds` trong request. TTL của key chỉ bắt đầu
> đếm từ lần `/check` đầu tiên của khách (kích hoạt).

### Ví dụ chạy tối giản

```bash
mkdir -p /opt/anontoken && cd /opt/anontoken
cp main.x86_64 ./main && cp admin.x86_64 ./admin
chmod +x main admin

# 1) tạo tài khoản dev đầu tiên
./admin -f users.bin add alice 'mat-khau-manh'

# 2) chạy server (bind 127.0.0.1, port 9999)
./main 127.0.0.1 9999 keystore.bin 90 users.bin
```

Test:

```bash
curl http://127.0.0.1:9999/health
# {"status":"ok","version":"0.3.0","keys":0}
```

### Chạy nền kiểu service (systemd)

```bash
sudo tee /etc/systemd/system/anontoken.service > /dev/null <<'EOF'
[Unit]
Description=AnonToken KMS server
After=network.target

[Service]
WorkingDirectory=/opt/anontoken
ExecStart=/opt/anontoken/main 127.0.0.1 9999 /opt/anontoken/keystore.bin 90 /opt/anontoken/users.bin
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now anontoken
sudo systemctl status anontoken
```

> Muốn đổi port chỉ cần sửa dòng `ExecStart` (hoặc dùng
> `EnvironmentFile=/etc/default/anontoken`) rồi
> `sudo systemctl restart anontoken`.

---

## 3. Quản lý tài khoản developer — binary `admin`

```
admin [-f <users-file>] add     <user> <password>
admin [-f <users-file>] remove  <user>
admin [-f <users-file>] setpass <user> <password>
admin [-f <users-file>] list
```

- Username: **3–24 ký tự** `a-z A-Z 0-9 . _ -`
- Password: **8–96 ký tự**
- Mật khẩu **không bao giờ được lưu plaintext** — chỉ lưu salt ngẫu nhiên 32
  byte + PBKDF2-HMAC-SHA256 (**100.000 vòng**, `Kms_Passwd` SPARK-proven).
- **Chống brute-force**: tài khoản sai mật khẩu **5 lần liên tiếp** sẽ bị
  **khóa 15 phút** (kể cả khi gõ đúng mật khẩu trong thời gian khóa). Sai mật
  khẩu cho username không tồn tại → **không bao giờ bị đếm** (và vẫn chạy
  derivation giả để thời gian trả lời không lộ tài khoản nào tồn tại). Lockout
  tính **theo tài khoản**, không theo IP (server sau tunnel nên mọi kết nối
  đều từ 127.0.0.1). `admin setpass` (ghi lại users file) **reset khóa ngay**.
- Thay đổi **có hiệu lực ngay** — server tự đọc lại users file khi file đổi
  trên đĩa, **không cần restart**.
- Users file rỗng / không tồn tại → server ở chế độ **deny-all**: mọi request
  trừ `/health` trả `401`.

⚠️ **Luôn chỉ rõ `-f` trỏ đúng file users server đang dùng**, nếu không `admin`
sẽ ghi vào file `users.bin` trong thư mục hiện tại (file sai!).

```bash
# trên Pi (file thật nằm ở /var/lib/anontoken):
sudo /opt/anontoken/admin -f /var/lib/anontoken/users.bin add alice 'mat-khau-manh'
sudo /opt/anontoken/admin -f /var/lib/anontoken/users.bin list
sudo /opt/anontoken/admin -f /var/lib/anontoken/users.bin setpass alice 'pass-moi'
sudo /opt/anontoken/admin -f /var/lib/anontoken/users.bin remove alice
```

Không có endpoint đăng ký công khai — chỉ chủ server (bạn) tạo được tài khoản.

> ⚠️ **Xóa tài khoản = xóa toàn bộ key của tài khoản đó.** Khi bạn chạy
> `admin remove <user>`, server (ở request tiếp theo, hoặc ngay lúc boot nếu
> server đang tắt) sẽ **xoá sạch mọi key do user đó tạo** khỏi keystore:
> secrets bị zeroize, slot được giải phóng, mọi `/check`, `/sign`,
> `/pub`, `/verify` của các key đó trả `404`. Không thể hoàn tác — hãy
> sao lưu `keystore.bin` trước nếu bạn có thể cần các key đó.
> Nếu file users bị mất/hỏng (chế độ deny-all), key KHÔNG bị xoá —
> chỉ xoá khi tài khoản thực sự bị xoá khỏi users file hợp lệ.

---

## 4. Cấu hình trên Raspberry Pi hiện tại

Pi chạy service systemd đọc cấu hình từ **`/etc/default/anontoken`**
(qua `EnvironmentFile` trong unit), ví dụ:

```bash
ANONTONKEN_BIND_ADDR=127.0.0.1
ANONTONKEN_PORT=9999
ANONTONKEN_KEYSTORE=/var/lib/anontoken/keystore.bin
ANONTONKEN_LIFETIME_DAYS=90
ANONTONKEN_USERS=/var/lib/anontoken/users.bin
```

Unit `ExecStart` chuyển tiếp các biến này dạng vị trí:
`anontoken ${ANONTONKEN_BIND_ADDR} ${ANONTONKEN_PORT} ${ANONTONKEN_KEYSTORE} ${ANONTONKEN_LIFETIME_DAYS} ${ANONTONKEN_USERS}`.

Thao tác vận hành hàng ngày:

```bash
systemctl status anontoken
journalctl -u anontoken -f
sudo systemctl restart anontoken
```

### Bảo mật khi vận hành

- Server **chỉ nên bind `127.0.0.1`** và đặt sau Cloudflare Tunnel / reverse
  proxy bật HTTPS. Không bind `0.0.0.0` ra mạng trực tiếp.
- File keystore chứa khóa bí mật — đảm bảo chỉ user hệ thống `anontoken` đọc
  được (`chmod 600`, thuộc đúng user).
- Sao lưu định kỳ `keystore.bin` + `users.bin` (khóa bí mật không thể tái tạo;
  mất keystore = mất toàn bộ key).
- Bạn là người duy nhất có `admin` — không chia sẻ.

---

## 5. API — tóm tắt cho người vận hành

Bảng đầy đủ + ví dụ + mã lỗi nằm trong **`README.md`** (bản dành cho nhà phát
triển). Bản tóm tắt nhanh:

```
GET    /health                 → {"status":"ok","version":"0.3.0","keys":N}   (public)
POST   /keys                   → tạo key        {"lifetime_minutes":N} | {"lifetime_seconds":N}
                                      response gồm "activation_secret" (hiện ĐÚNG 1 lần)
GET    /keys                   → liệt kê key CỦA tài khoản đang đăng nhập
GET    /keys/<id>/pub          → public key
POST   /keys/<id>/sign         → ký message     {"message":"<base64>"}
POST   /keys/<id>/verify       → xác minh       {"message":"<base64>","signature":"<base64>"}
DELETE /keys/<id>              → thu hồi key
POST   /keys/<id>/check        → phone-home khách {"secret":"<b64 32B>"}   (public)
      → 200 valid | 404 mọi trường hợp không hợp lệ (không tồn tại /
        secret sai / đã thu hồi trả 404 GIỐNG NHAU — chống dò trạng thái key)
```

Đặc tính model licensing (lazy activation):

- TTL chọn lúc tạo key, nhưng **chỉ đếm từ lần `/check` thành công đầu tiên**
  (lần đầu phần mềm khách chạy).
- Key **chưa kích hoạt** → không bao giờ tự hết hạn (nằm im tới khi dùng).
- Key đã kích hoạt → chết đúng `TTL` sau kích hoạt và bị xoá sạch (gọi sau →
  `404`).
- `DELETE` thu hồi: key đã kích hoạt bị chặn ngay (bên ngoài `/check` →
  `404`; chủ key `/sign` → `403`) và nằm lại tới deadline để kiểm toán; key
  chưa kích hoạt bị giải phóng ngay (chưa từng dùng).
- Keystore tối đa **65.536 key đồng thời**; file keystore ghi động (chỉ giữ key
  còn sống). `GET /health` hiện tổng số key.

Ví dụ nhanh khi test trên máy local:

```bash
curl -X POST -d '{"lifetime_minutes": 30}' http://127.0.0.1:9999/keys   # cần Basic Auth
```

Lifetime > 1 năm hoặc ≤ 0 → bị từ chối lỗi `bad_lifetime`.

---

## 6. Nâng cấp & migration keystore

- Keystore có version header (`ANKT 1/2/3`). Khi chạy binary mới trên file
  keystore cũ (v1/v2), server **tự động migrate** lên format mới khi load.
- Key cũ (chưa có chủ) được **claim tự động về tài khoản đầu tiên** trong
  users file (log khởi động ghi `claimed legacy keys for account '<tên>'`).
- Trước khi nâng cấp binary, luôn **sao lưu keystore**:
  `cp /var/lib/anontoken/keystore.bin /var/lib/anontoken/keystore.bin.bak`

---

## 7. Tự build từ source (không bắt buộc)

Binary kèm trong gói là bản được build sẵn — bạn **không cần** tự build. Nếu
muốn kiểm chứng source hoặc build cho kiến trúc khác:

- Yêu cầu: toolchain Ada/SPARK (GNAT + `gprbuild`, khuyên dùng qua
  [Alire](https://alire.ada.dev)) + `libs/sparknacl` kèm trong gói.
- Build server: `gprbuild -P anontoken.gpr -XKMS_MAIN=main` (điều chỉnh theo
  `anontoken.gpr`).
- Build admin: `gprbuild -P anontoken.gpr -XKMS_MAIN=admin`.
- Re-prove SPARK level 4:
  `gnatprove -P anontoken.gpr --level=4 --prover=cvc5,z3,altergo --output-dir=proof`.

---

## 8. Gỡ lỗi nhanh

| Triệu chứng | Nguyên nhân / cách xử lý |
|---|---|
| Mọi request trả `401` | Users file trống/sai đường dẫn → tạo tài khoản bằng `admin -f <file đúng>` hoặc kiểm tra `ANONTONKEN_USERS` |
| Log ghi `no keystore found ... starting empty` | Keystore chưa tồn tại (lần chạy đầu) — bình thường; key tạo từ đầu sẽ được lưu |
| Không kết nối được từ ngoài | Server bind `127.0.0.1` → phải qua tunnel/proxy; kiểm tra `cloudflared` còn chạy |
| Key cũ biến mất sau nâng cấp | Kiểm tra log `claimed legacy keys`; nếu users file chưa có tài khoản nào lúc boot, key chờ tới khi có account đầu tiên |
