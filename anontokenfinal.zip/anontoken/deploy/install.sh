#!/usr/bin/env bash
# AnonToken key management server - one-command installer (Raspberry Pi / aarch64).
#
#   sudo bash install.sh
#
# What it does:
#   1. installs the native GNAT toolchain (gnat + gprbuild) if missing
#   2. builds the server from source (all SPARK, proven at level 4)
#   3. installs the binary + systemd unit + writes /etc/default/anontoken
#   4. creates the anontoken user and state directory
#   5. starts the service (behind your Cloudflare tunnel)
#   6. smoke-tests GET /health
#
# The listen port (and other settings) are configured in
# /etc/default/anontoken - edit that file, then:
#   systemctl restart anontoken
set -euo pipefail

SERVICE_NAME="anontoken"
INSTALL_DIR="/opt/anontoken"
STATE_DIR="/var/lib/anontoken"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
BIND_ADDR="${ANONTONKEN_BIND_ADDR:-127.0.0.1}"
PORT="${ANONTONKEN_PORT:-9999}"
LIFETIME_DAYS="${ANONTONKEN_LIFETIME_DAYS:-90}"

if [[ $EUID -ne 0 ]]; then
  echo "error: run as root:  sudo bash install.sh" >&2
  exit 1
fi

#  Project root is the parent of this script's directory (deploy/..).
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd -P)"

echo "==> [1/6] toolchain"
if ! command -v gprbuild >/dev/null 2>&1 || ! command -v gnatmake >/dev/null 2>&1; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y gnat gprbuild
fi
echo "    gnat:  $(gnat --version | head -1)"
echo "    gprbuild: $(gprbuild --version | head -1)"

echo "==> [2/6] build (release, SPARK code)"
cd "$SRC_DIR"
gprbuild -P anontoken.gpr -XKMS_MAIN=main.adb -j0 -s
gprbuild -P anontoken.gpr -XKMS_MAIN=admin.adb -j0 -s

echo "==> [3/6] install files"
install -d -m 0755 "$INSTALL_DIR"
install -m 0755 bin/main "$INSTALL_DIR/${SERVICE_NAME}"
install -m 0755 bin/admin "$INSTALL_DIR/admin"
install -m 0644 deploy/anontoken.service "$SERVICE_FILE"

#  Runtime settings live in /etc/default/anontoken; the unit reads them via
#  EnvironmentFile, so changing the port is a one-file edit + restart:
#      systemctl restart anontoken
cat > "/etc/default/${SERVICE_NAME}" <<EOF
# anontoken runtime configuration
# Edit and restart:  systemctl restart ${SERVICE_NAME}
ANONTONKEN_BIND_ADDR=${BIND_ADDR}
ANONTONKEN_PORT=${PORT}
ANONTONKEN_KEYSTORE=${STATE_DIR}/keystore.bin
ANONTONKEN_LIFETIME_DAYS=${LIFETIME_DAYS}
ANONTONKEN_USERS=${STATE_DIR}/users.bin
EOF
chmod 0644 "/etc/default/${SERVICE_NAME}"

echo "==> [4/6] service user and state directory"
if ! id -u anontoken >/dev/null 2>&1; then
  useradd --system --home-dir "$STATE_DIR" --shell /usr/sbin/nologin anontoken
fi
install -d -m 0750 -o anontoken -g anontoken "$STATE_DIR"

echo "==> [5/6] enable and start"
systemctl daemon-reload
systemctl enable "${SERVICE_NAME}.service"
systemctl restart "${SERVICE_NAME}.service"

#  Create an initial owner account when none exists yet.
if [ ! -f "${STATE_DIR}/users.bin" ] && [ -n "${ANONTONKEN_INIT_USER:-}" ] && [ -n "${ANONTONKEN_INIT_PASS:-}" ]; then
  install -m 0640 -o anontoken -g anontoken /dev/null "${STATE_DIR}/users.bin" 2>/dev/null || true
  "$INSTALL_DIR/admin" -f "${STATE_DIR}/users.bin" add "$ANONTONKEN_INIT_USER" "$ANONTONKEN_INIT_PASS" || true
fi

echo "==> [6/6] smoke test GET /health"
sleep 1
for i in 1 2 3 4 5; do
  if curl -fsS "http://${BIND_ADDR}:${PORT}/health"; then
    echo
    echo "==> OK: ${SERVICE_NAME} is up on ${BIND_ADDR}:${PORT}"
    systemctl status "${SERVICE_NAME}.service" --no-pager | head -6
    exit 0
  fi
  sleep 1
done

echo "error: ${SERVICE_NAME} did not answer GET /health" >&2
journalctl -u "${SERVICE_NAME}.service" -n 30 --no-pager >&2 || true
exit 1
