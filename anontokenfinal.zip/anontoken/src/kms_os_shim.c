/*------------------------------------------------------------------------------
 *  Kms_Os_Shim : minimal C syscall glue for the SPARK Kms_Os boundary.
 *
 *  The Ada package Kms_Os (SPARK_Mode => On) imports these procedures
 *  directly with Convention => C.  Buffers are passed by reference
 *  (GNAT array parameters), results are returned through an explicit
 *  output scalar (GNAT passes out scalars by reference under C
 *  convention).  No 'Address attribute is needed anywhere in Ada.
 *
 *  This file deliberately contains no logic: it forwards each call to
 *  the corresponding libc function and stores the raw result.
 *---------------------------------------------------------------------------*/

#define _GNU_SOURCE
#include <stddef.h>
#include <stdint.h>
#include <sys/socket.h>
#include <sys/random.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

/*  read(fd, buf, count) -> bytes read / 0 EOF / -1 error  */
void kms_read(int fd, unsigned char *buf, size_t count, int64_t *res)
{
    ssize_t r = read(fd, buf, count);
    *res = (int64_t)r;
}

/*  write(fd, buf, count) -> bytes written / -1 error  */
void kms_write(int fd, const unsigned char *buf, size_t count, int64_t *res)
{
    ssize_t r = write(fd, buf, count);
    *res = (int64_t)r;
}

/*  recv(fd, buf, len, 0) -> bytes read / 0 EOF / -1 error  */
void kms_recv(int fd, unsigned char *buf, size_t len, int64_t *res)
{
    ssize_t r = recv(fd, buf, len, 0);
    *res = (int64_t)r;
}

/*  send(fd, buf, len, 0) -> bytes sent / -1 error  */
void kms_send(int fd, const unsigned char *buf, size_t len, int64_t *res)
{
    ssize_t r = send(fd, buf, len, 0);
    *res = (int64_t)r;
}

/*  accept4(fd, NULL, NULL, 0) -> client fd / -1 error  */
void kms_accept(int fd, int *client)
{
    *client = accept4(fd, NULL, NULL, 0);
}

/*  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &1, 4) -> ok = 1 / 0.
 *  GNAT maps Ada Boolean to a 1-byte char under C convention, so the
 *  output is a char pointer, not an int pointer.  */
void kms_setsockopt_reuse(int fd, char *ok)
{
    int one = 1;
    int r = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    *ok = (char)((r == 0) ? 1 : 0);
}

/*  time(NULL) -> seconds since the epoch  */
int64_t kms_time(void)
{
    return (int64_t)time(NULL);
}

/*  getrandom(buf, len, 0); retries on EINTR, fills the whole buffer.  */
void kms_getrandom(unsigned char *buf, size_t len)
{
    for (;;) {
        ssize_t r = getrandom(buf, len, 0);
        if (r == (ssize_t)len)
            return;
        if (r < 0 && errno == EINTR)
            continue;
        if (r < 0)
            return; /* kernel refused: caller keeps old contents */
        buf += (size_t)r;
        len -= (size_t)r;
    }
}