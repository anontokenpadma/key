with Interfaces;
use  Interfaces;
with Kms_Json;
with Kms_Keystore;
with Kms_Signer;
with Kms_Hex;
with Kms_Base64;
with Kms_Passwd;
with Kms_Users;

package body Kms_Http
  with SPARK_Mode => On
is

   use Kms_Types;
   use Kms_Keystore;
   use Kms_Json;
   use Kms_Base64;
   use Kms_Users;
   use Kms_Passwd;

   CR : constant Byte := 16#0D#;
   LF : constant Byte := 16#0A#;
   SP : constant Byte := Character'Pos (' ');
   HT : constant Byte := 16#09#;

   Max_Header_Length : constant := 2048;

   subtype Path_Buffer is Byte_Array (0 .. 63);

   type Http_Code is (C200, C201, C400, C401, C403, C404, C405, C413, C500, C503);

   ----------------
   -- To_Byte --
   ----------------

   function To_Byte (C : Character) return Byte is
     (Character'Pos (C));

   -------------
   -- To_Lower --
   -------------

   function To_Lower (C : Byte) return Byte is
   begin
      if C in Character'Pos ('A') .. Character'Pos ('Z') then
         return C + (Character'Pos ('a') - Character'Pos ('A'));
      else
         return C;
      end if;
   end To_Lower;

   -----------
   -- Eq_CS --
   -----------

   --  Case-sensitive comparison: Buf (Off .. Off + S'Length - 1) = S.
   function Eq_CS (Buf : Byte_Array;
                   Off : N32;
                   S   : String) return Boolean
     with Pre => Buf'First = 0 and then
                 Buf'Length <= Max_Response_Length and then
                 S'Length <= Max_Short_Length and then
                 Off <= Buf'Length and then
                 Off + S'Length <= Buf'Length
   is
   begin
      for I in S'Range loop
         if Buf (Off + N32 (I - S'First)) /= To_Byte (S (I)) then
            return False;
         end if;
      end loop;
      return True;
   end Eq_CS;

   -----------
   -- Eq_CI --
   -----------

   --  Case-insensitive comparison of ASCII letters.
   function Eq_CI (Buf : Byte_Array;
                   Off : N32;
                   S   : String) return Boolean
     with Pre => Buf'First = 0 and then
                 Buf'Length <= Max_Response_Length and then
                 S'Length <= Max_Short_Length and then
                 Off <= Buf'Length and then
                 Off + S'Length <= Buf'Length
   is
   begin
      for I in S'Range loop
         if To_Lower (Buf (Off + N32 (I - S'First))) /= To_Lower (To_Byte (S (I))) then
            return False;
         end if;
      end loop;
      return True;
   end Eq_CI;

   -------------
   -- Reason --
   -------------

   Version_Str : constant String := "0.2.0";

   function Reason (C : Http_Code) return String
     with Post => Reason'Result'Length <= 32
   is
   begin
      case C is
         when C200 => return "OK";
         when C201 => return "Created";
         when C400 => return "Bad Request";
         when C401 => return "Unauthorized";
         when C403 => return "Forbidden";
         when C404 => return "Not Found";
         when C405 => return "Method Not Allowed";
         when C413 => return "Payload Too Large";
         when C500 => return "Internal Server Error";
         when C503 => return "Service Unavailable";
      end case;
   end Reason;

   --------------
   -- Code_Num --
   --------------

   function Code_Num (C : Http_Code) return N32 is
   begin
      case C is
         when C200 => return 200;
         when C201 => return 201;
         when C400 => return 400;
         when C401 => return 401;
         when C403 => return 403;
         when C404 => return 404;
         when C405 => return 405;
         when C413 => return 413;
         when C500 => return 500;
         when C503 => return 503;
      end case;
   end Code_Num;

   ----------------
   -- Append_CRLF --
   ----------------

   procedure Append_CRLF (Buf : in out Byte_Array; Pos : in out N32)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos < Buf'Length - 1,
          Post => Pos = Pos'Old + 2
   is
   begin
      Kms_Json.Append (Buf, Pos, CR);
      Kms_Json.Append (Buf, Pos, LF);
   end Append_CRLF;

   -------------
   -- Append_Q --
   -------------

   --  Append a double-quoted ASCII string.
   procedure Append_Q (Buf : in out Byte_Array;
                       Pos : in out N32;
                       S   : in     String)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  S'Length <= Max_Short_Length and then
                  Pos <= Buf'Length and then
                  Pos + S'Length + 2 <= Buf'Length,
          Post => Pos = Pos'Old + S'Length + 2
   is
      P0 : constant N32 := Pos;
   begin
      Buf (Pos) := To_Byte ('"');
      Pos       := Pos + 1;
      for I in S'Range loop
         Buf (Pos) := To_Byte (S (I));
         Pos       := Pos + 1;
         pragma Loop_Invariant (Pos = P0 + N32 (I - S'First) + 2);
      end loop;
      Buf (Pos) := To_Byte ('"');
      Pos       := Pos + 1;
   end Append_Q;

   ----------------
   -- Status_Str --
   ----------------

   function Status_Str (S : Key_Status) return String
     with Post => Status_Str'Result'Length <= 8
   is
   begin
      case S is
         when Active  => return "active";
         when Expired => return "expired";
         when Revoked => return "revoked";
      end case;
   end Status_Str;

   ------------------
   -- Build_Error --
   ------------------

   --  Write  {"error":"<msg>"}  --  always 12 + Msg'Length bytes.
   procedure Build_Error (Buf : in out Byte_Array;
                          Pos : in out N32;
                          Msg : in     String)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Msg'Length <= Max_Short_Length and then
                  Pos <= Buf'Length and then
                  Pos + Msg'Length + 12 <= Buf'Length,
          Post => Pos = Pos'Old + Msg'Length + 12
   is
   begin
      Kms_Json.Append (Buf, Pos, To_Byte ('{'));
      Append_Q (Buf, Pos, "error");
      Kms_Json.Append (Buf, Pos, To_Byte (':'));
      Append_Q (Buf, Pos, Msg);
      Kms_Json.Append (Buf, Pos, To_Byte ('}'));
   end Build_Error;

   -------------------
   -- Write_Envelope --
   -------------------

   procedure Write_Envelope (Code     : in     Http_Code;
                             Body_Len : in     N32;
                             Add_WWW  : in     Boolean;
                             Resp     : in out Response_Buffer;
                             Env_Len  : out    N32)
     with Pre  => Body_Len <= 115_000,
          Post => Env_Len <= 256
   is
      --  Build the envelope in a fully-initialised local buffer, then copy
      --  the written prefix into the in-out buffer Resp (the caller keeps
      --  the whole buffer initialised; only the prefix is overwritten).
      Tmp : Response_Buffer := (others => 0);
      P   : N32             := 0;
   begin
      Kms_Json.Append_Text (Tmp, P, "HTTP/1.1 ");
      Kms_Json.Append_U64 (Tmp, P, U64 (Code_Num (Code)));
      Kms_Json.Append (Tmp, P, SP);
      Kms_Json.Append_Text (Tmp, P, Reason (Code));
      Append_CRLF (Tmp, P);
      Kms_Json.Append_Text (Tmp, P, "Content-Type: application/json");
      Append_CRLF (Tmp, P);
      Kms_Json.Append_Text (Tmp, P, "Content-Length: ");
      Kms_Json.Append_U64 (Tmp, P, U64 (Body_Len));
      Append_CRLF (Tmp, P);
      if Add_WWW then
         Kms_Json.Append_Text
           (Tmp, P, "WWW-Authenticate: Basic realm=""anontoken""");
         Append_CRLF (Tmp, P);
      end if;
      Kms_Json.Append_Text (Tmp, P, "Connection: close");
      Append_CRLF (Tmp, P);
      Append_CRLF (Tmp, P);
      Resp (0 .. P - 1) := Tmp (0 .. P - 1);
      Env_Len := P;
   end Write_Envelope;

   -----------
   -- Parse --
   -----------

   procedure Parse (Buf : in  Request_Buffer;
                    Len : in  N32;
                    Req : out Request;
                    Res : out Parse_Result) is
      H          : N32        := 0;
      Found_H    : Boolean    := False;
      R          : N32        := 0;
      Found_R    : Boolean    := False;
      S1         : N32        := 0;
      S2         : N32        := 0;
      Meth_GET   : Boolean    := False;
      Meth_POST  : Boolean    := False;
      Meth_DEL   : Boolean    := False;
      Meth_Other : Boolean    := False;
      CL         : N32        := 0;
      CL_Found   : Boolean    := False;
      CL_Large   : Boolean    := False;
      B0         : N32        := 0;
      Path       : Path_Buffer := (others => 0);
      Path_Len   : N32        := 0;
      Id_Hex       : Kms_Hex.Hex_Buffer := (others => 0);
      Id_Valid     : Boolean    := False;
      Value        : U64        := 0;
      J            : N32        := 0;
      Auth_Overflow : Boolean   := False;
   begin
      Req := (Kind         => Req_None,
              Id           => 0,
              Error        => Err_Bad_Request,
              Body_Data    => (others => 0),
              Body_Len     => 0,
              Auth_Present => False,
              Auth_Data    => (others => 0),
              Auth_Len     => 0);

      --  1.  find the end of headers ("\r\n\r\n")
      for I in 0 .. Len - 1 loop
         if I + 3 < Len and then
            Buf (I) = CR and then Buf (I + 1) = LF and then
            Buf (I + 2) = CR and then Buf (I + 3) = LF
         then
            H       := I;
            Found_H := True;
            exit;
         end if;
      end loop;


      if not Found_H then
         if Len = Max_Request_Length then
            Req.Error := Err_Too_Large;
            Res := Bad;
         else
            Res := Incomplete;
         end if;
         return;
      end if;

      --  2.  request line ends at the first CRLF at or before H
      for I in 0 .. H loop
         if I + 1 < Len and then Buf (I) = CR and then Buf (I + 1) = LF then
            R       := I;
            Found_R := True;
            exit;
         end if;
      end loop;

      if not Found_R or else R = 0 then
         Req.Error := Err_Bad_Request;
         Res := Bad;
         return;
      end if;

      --  3.  method token (up to first space)
      for I in 0 .. R - 1 loop
         if Buf (I) = SP then
            S1 := I;
            exit;
         end if;
      end loop;

      if S1 = 0 or else S1 >= R - 1 then
         Req.Error := Err_Bad_Request;
         Res := Bad;
         return;
      end if;

      --  4.  path token (up to second space); must end before R
      for I in S1 + 1 .. R - 1 loop
         if Buf (I) = SP then
            S2 := I;
            exit;
         end if;
      end loop;

      if S2 = 0 or else S2 >= R - 1 then
         Req.Error := Err_Bad_Request;
         Res := Bad;
         return;
      end if;

      --  5.  version must be HTTP/1.1
      if R - S2 - 1 /= 8 or else
         not Eq_CS (Buf, S2 + 1, "HTTP/1.1")
      then
         Req.Error := Err_Bad_Request;
         Res := Bad;
         return;
      end if;

      --  6.  method classification
      Meth_GET  := S1 = 3 and then Eq_CS (Buf, 0, "GET");
      Meth_POST := S1 = 4 and then Eq_CS (Buf, 0, "POST");
      Meth_DEL  := S1 = 6 and then Eq_CS (Buf, 0, "DELETE");
      Meth_Other := not (Meth_GET or Meth_POST or Meth_DEL);

      if Meth_Other then
         Req.Error := Err_Method;
         Res := Bad;
         return;
      end if;

      --  7.  Content-Length header within R+2 .. H-1
      if R + 2 <= H - 1 then
         for I in R + 2 .. H - 1 loop
            if I + 14 <= H - 1 and then
               Eq_CI (Buf, I, "content-length") and then
               Buf (I + 14) = To_Byte (':')
            then
               --  parse decimal digits into Value (cap far above all
               --  sensible body sizes; we bail out early on overflow)
               J := I + 15;
               Value := 0;
               --  skip optional whitespace after the colon (RFC 9110 OWS)
               while J <= H - 1 and then
                 (Buf (J) = SP or else Buf (J) = HT)
               loop
                  J := J + 1;
                  pragma Loop_Invariant (J <= H);
               end loop;
               while J <= H - 1 and then
                 Buf (J) in To_Byte ('0') .. To_Byte ('9')
               loop
                  if Value > 1_000_000 then
                     CL_Large := True;
                  else
                     Value := Value * 10 +
                              U64 (Buf (J) - To_Byte ('0'));
                     if Value > U64 (Max_Body_Length) then
                        CL_Large := True;
                     end if;
                  end if;
                  J := J + 1;
                  pragma Loop_Invariant (J <= H);
                  pragma Loop_Invariant (Value <= 10_000_009);
                  pragma Loop_Invariant
                    (CL_Large or else Value <= U64 (Max_Body_Length));
               end loop;
               if J > I + 15 and then not CL_Large then
                  CL       := N32 (Value);
                  CL_Found := True;
               elsif CL_Large then
                  Req.Error := Err_Too_Large;
                  Res := Bad;
                  return;
               else
                  --  colon with no digits
                  Req.Error := Err_Bad_Request;
                  Res := Bad;
                  return;
               end if;
               exit;
            end if;
         end loop;
      end if;

      if not CL_Found then
         CL := 0;
      end if;

      --  7b.  Authorization: Basic <base64token>
      --  Only the token after "Basic " is kept (Auth_Data 0 .. Auth_Len-1);
      --  an oversized or malformed header simply counts as absent.
      if R + 2 <= H - 1 then
         for I in R + 2 .. H - 1 loop
            if I + 13 <= H - 1 and then
               Eq_CI (Buf, I, "authorization") and then
               Buf (I + 13) = To_Byte (':')
            then
               J := I + 14;
               --  skip optional whitespace after the colon (RFC 9110 OWS)
               while J <= H - 1 and then
                 (Buf (J) = SP or else Buf (J) = HT)
               loop
                  J := J + 1;
                  pragma Loop_Invariant (J <= H);
               end loop;
               --  scheme must be "Basic " (case-insensitive)
               if J + 5 <= H - 1 and then Eq_CI (Buf, J, "basic ") then
                  J := J + 6;
                  Auth_Overflow := False;
                  while J <= H - 1 and then
                    Buf (J) /= CR and then Buf (J) /= LF
                  loop
                     if Req.Auth_Len < Max_Auth_Length then
                        Req.Auth_Data (Req.Auth_Len) := Buf (J);
                        Req.Auth_Len := Req.Auth_Len + 1;
                     else
                        Auth_Overflow := True;
                     end if;
                     J := J + 1;
                     pragma Loop_Invariant (J <= H);
                     pragma Loop_Invariant
                       (Req.Auth_Len <= Max_Auth_Length);
                  end loop;
                  if not Auth_Overflow and then Req.Auth_Len > 0 then
                     Req.Auth_Present := True;
                  end if;
               end if;
               exit;
            end if;
         end loop;
      end if;

      --  8.  body: H+4 .. H+3+CL must be inside the buffer
      B0 := H + 4;
      if CL > 0 and then Len < B0 + CL then
         --  not all body bytes received yet
         Res := Incomplete;
         return;
      end if;
      if CL > 0 then
         for I in 0 .. CL - 1 loop
            Req.Body_Data (I) := Buf (B0 + I);
         end loop;
      end if;
      Req.Body_Len := CL;

      --  9.  copy the path into a bounded scratch buffer
      Path_Len := S2 - S1 - 1;
      if Path_Len > Path_Buffer'Length then
         Req.Error := Err_Not_Found;
         Res := Bad;
         return;
      end if;
      if Path_Len > 0 then
         for I in 0 .. Path_Len - 1 loop
            Path (I) := Buf (S1 + 1 + I);
         end loop;
      end if;

      --  10. routing
      Req.Error := Err_None;
      if Path_Len = 7 and then Eq_CS (Path, 0, "/health") then
         if Meth_GET then
            Req.Kind := Req_Health;
         else
            Req.Error := Err_Method;
         end if;
      elsif Path_Len = 5 and then Eq_CS (Path, 0, "/keys") then
         if Meth_GET then
            Req.Kind := Req_List;
         elsif Meth_POST then
            Req.Kind := Req_Create;
         else
            Req.Error := Err_Method;
         end if;
      elsif Path_Len >= 22 and then Eq_CS (Path, 0, "/keys/") then
         --  identifier is Path (6 .. 21), suffix starts at 22
         for K in Id_Hex'Range loop
            Id_Hex (K) := Path (6 + K);
         end loop;
         Kms_Hex.From_Hex (Id_Hex, Id_Valid, Req.Id);
         if not Id_Valid then
            Req.Error := Err_Not_Found;
         elsif Path_Len = 22 then
            if Meth_DEL then
               Req.Kind := Req_Revoke;
            else
               Req.Error := Err_Method;
            end if;
         elsif Path_Len = 26 and then Eq_CS (Path, 22, "/pub") then
            if Meth_GET then
               Req.Kind := Req_Public;
            else
               Req.Error := Err_Method;
            end if;
         elsif Path_Len = 27 and then Eq_CS (Path, 22, "/sign") then
            if Meth_POST then
               Req.Kind := Req_Sign;
            else
               Req.Error := Err_Method;
            end if;
         elsif Path_Len = 29 and then Eq_CS (Path, 22, "/verify") then
            if Meth_POST then
               Req.Kind := Req_Verify;
            else
               Req.Error := Err_Method;
            end if;
         elsif Path_Len = 28 and then Eq_CS (Path, 22, "/check") then
            if Meth_POST then
               Req.Kind := Req_Check;
            else
               Req.Error := Err_Method;
            end if;
         else
            Req.Error := Err_Not_Found;
         end if;
      else
         Req.Error := Err_Not_Found;
      end if;

      if Req.Error = Err_None then
         Res := Good;
      else
         Res := Bad;
      end if;
   end Parse;

   -------------
   -- Assemble_Id --
   -------------

   --  Little-endian assembly of a 64-bit key id from the first 8 seed bytes.
   --  Equivalent to Seed(0) | Seed(1)<<8 | ... | Seed(7)<<56.
   function Assemble_Id (Seed  : Seed_Bytes;
                         Up_To : N32) return Key_Id
     with Global => null,
          Pre  => Up_To <= 7
   is
      R : Key_Id := 0;
   begin
      for I in 0 .. Up_To loop
         R := R or Key_Id (Seed (I)) * 256 ** Natural (I);
         pragma Loop_Invariant (I <= 7);
      end loop;
      return R;
   end Assemble_Id;

   ---------------
   -- Check_Auth --
   ---------------

   --  Verify a presented username/password against the owner-managed
   --  account table.  The digest comparison is constant-time; when the
   --  user does not exist a dummy derivation with a zero salt runs anyway
   --  so the timing does not reveal whether the account exists.
   procedure Check_Auth (Users     : in     User_Table;
                         Uname     : in     User_Name_Buffer;
                         Uname_Len : in     N32;
                         Pwd       : in     Password_Buffer;
                         Pwd_Len   : in     N32;
                         Ok        :    out Boolean)
     with Global => null,
          Pre  => Uname_Len >= 1 and then Uname_Len <= User_Name_Length and then
                  Pwd_Len >= 1 and then Pwd_Len <= Password_Length
   is
      F       : Boolean;
      Idx     : N32;
      Rec     : User_Record;
      Derived : Digest_Bytes := (others => 0);
      Zero    : Digest_Bytes := (others => 0);
   begin
      Kms_Users.Find (Users, Uname, Uname_Len, F, Idx);
      if F then
         Kms_Users.Get (Users, Idx, Rec);
         Kms_Passwd.Derive (Rec.Salt, Pwd (0 .. Pwd_Len - 1), Derived);
         Kms_Users.Verify (Rec.Hash, Derived, Ok);
      else
         --  timing parity: derive against a null salt, compare against a
         --  null digest, then force the failure
         Kms_Passwd.Derive (Zero, Pwd (0 .. Pwd_Len - 1), Derived);
         Kms_Users.Verify (Zero, Derived, Ok);
         Ok := False;
      end if;
   end Check_Auth;

   -------------
   -- Auth_Ok --
   -------------

   --  Resolve Basic credentials from Req into a username and password, and
   --  verify them against the account table.  Ok is True only for a valid
   --  login; then Uname holds the account name (used for key ownership).
   procedure Auth_Ok (Users : in     User_Table;
                      Req   : in     Request;
                      Uname :    out User_Name_Buffer;
                      U_Len :    out N32;
                      Ok    :    out Boolean)
     with Global => null,
          Pre  => Req.Auth_Len <= Max_Auth_Length,
          Post => (if Ok then
                     U_Len >= 1 and then U_Len <= User_Name_Length)
   is
      Creds       : Byte_Array (0 .. 127) := (others => 0);
      Creds_Len   : N32                    := 0;
      Creds_Valid : Boolean                := False;
      Colon_J     : N32                    := 0;
      P_Len       : N32                    := 0;
      Pwd         : Password_Buffer        := (others => 0);
      Cred_Lim    : constant N32 := 170;   --  3 * (In_Len / 4) <= 127
   begin
      Ok := False;
      U_Len := 0;
      Uname := (others => 0);
      if Req.Auth_Present and then Req.Auth_Len <= Cred_Lim then
         Kms_Base64.Decode (Req.Auth_Data (0 .. Req.Auth_Len - 1),
                            Req.Auth_Len, Creds, Creds_Len, Creds_Valid);
         if Creds_Valid then
            --  split at the first ':' (user : password)
            Colon_J := 0;
            while Colon_J < Creds_Len and then
                  Creds (Colon_J) /= To_Byte (':')
            loop
               Colon_J := Colon_J + 1;
               pragma Loop_Invariant (Colon_J <= Creds_Len);
            end loop;
            if Colon_J < Creds_Len then
               U_Len := Colon_J;
               P_Len := Creds_Len - Colon_J - 1;
               if U_Len >= 1 and then U_Len <= User_Name_Length and then
                  P_Len >= 1 and then P_Len <= Password_Length
               then
                  for I in 0 .. U_Len - 1 loop
                     Uname (I) := Creds (I);
                     pragma Loop_Invariant
                       (for all J2 in 0 .. I => Uname (J2) = Creds (J2));
                  end loop;
                  for I in 0 .. P_Len - 1 loop
                     Pwd (I) := Creds (Colon_J + 1 + I);
                     pragma Loop_Invariant
                       (for all J2 in 0 .. I =>
                          Pwd (J2) = Creds (Colon_J + 1 + J2));
                  end loop;
                  Check_Auth (Users, Uname, U_Len, Pwd, P_Len, Ok);
               end if;
            end if;
         end if;
      end if;
   end Auth_Ok;

   ---------------
   -- Secret_OK --
   ---------------

   --  Constant-time comparison of a stored activation secret against the
   --  one presented in the request body ("secret": "<b64 32B>").
   procedure Secret_OK (Payload   : in     Byte_Array;
                        Payload_Len : in  N32;
                        Stored    : in     Activation_Bytes;
                        Match     :    out Boolean)
     with Global => null,
          Pre  => Payload'First = 0 and then
                  Payload'Length <= Max_Request_Length and then
                  Payload_Len <= Payload'Length
   is
      B64      : Base64_Buffer := (others => 0);
      B64_Len  : N32           := 0;
      Dec      : Byte_Array (0 .. 63) := (others => 0);
      Dec_Len  : N32           := 0;
      Valid    : Boolean       := False;
      Diff     : Byte          := 0;
   begin
      Match := False;
      Kms_Json.Find_String (Payload, Payload_Len, "secret", Valid,
                            B64, B64_Len);
      --  a 32-byte secret always encodes to exactly 44 base64 chars; this
      --  also keeps the decode buffer bound below its 64-byte capacity
      if not Valid or else B64_Len /= 44 then
         return;
      end if;
      Kms_Base64.Decode (B64 (0 .. B64_Len - 1), B64_Len,
                         Dec, Dec_Len, Valid);
      if not Valid or else Dec_Len /= Activation_Bytes'Length then
         return;
      end if;
      for I in Activation_Bytes'Range loop
         Diff := Diff or (Stored (I) xor Dec (I));
         pragma Loop_Invariant
           ((Diff = 0) = (for all J in Activation_Bytes'First .. I =>
                             Stored (J) = Dec (J)));
      end loop;
      Match := Diff = 0;
   end Secret_OK;

   --------------
   -- Dispatch --
   --------------

   procedure Dispatch (KS            : in out Keystore;
                       Now           : in     I64;
                       Seed          : in     Seed_Bytes;
                       Secret_Seed   : in     Seed_Bytes;
                       Lifetime_Days : in     I64;
                       Users         : in     User_Table;
                       Req           : in     Request;
                       Resp          : in out Response_Buffer;
                       Resp_Len      : out    N32;
                       Changed       : out    Boolean) is
      Body_Buf   : Response_Buffer := (others => 0);
      Pos        : N32            := 0;
      Code       : Http_Code      := C500;
      Env_Len    : N32            := 0;
      Add_WWW    : Boolean        := False;
      F          : Boolean        := False;
      Idx        : Key_Index      := 0;
      Rec        : Key_Record;
      Msg_B64    : Base64_Buffer  := (others => 0);
      Msg_B64_Len : N32           := 0;
      Msg_Alloc  : Message_Bytes  := (others => 0);
      Msg_Len    : N32            := 0;
      Valid_B64  : Boolean        := False;
      Sig_B64    : Base64_Buffer  := (others => 0);
      Sig_B64_Len : N32           := 0;
      Sig_Dec    : Byte_Array (0 .. 127) := (others => 0);
      Sig_Len    : N32            := 0;
      Sig        : Signature_Bytes := (others => 0);
      Valid_Sig  : Boolean        := False;
      Hex_Buf    : Kms_Hex.Hex_Buffer := (others => 0);
      New_Id     : Key_Id         := 0;
      Publ       : Bytes_32       := (others => 0);
      Secre      : Bytes_64       := (others => 0);
      Created    : Boolean        := False;
      First_Key  : Boolean        := True;
      Listed     : N32            := 0;
      TTL_Secs   : I64            := 0;
      Bad_TTL    : Boolean        := False;
      F_Min      : Boolean        := False;
      V_Min      : U64            := 0;
      F_Sec      : Boolean        := False;
      V_Sec      : U64            := 0;
      Expired    : Boolean        := False;
      Authorized : Boolean        := False;
      Sec_OK     : Boolean        := False;
      Public_Req : Boolean        := False;
      Uname      : User_Name_Buffer       := (others => 0);
      U_Len      : N32                     := 0;
      New_Rec    : Key_Record := (In_Use => True, others => <>);
   begin
      Changed := False;

      --  purge activated keys past their deadline up front so every
      --  endpoint only ever sees live keys; a freed slot is persisted by
      --  the caller (Changed).
      Kms_Keystore.Expire (KS, Now, Expired);
      if Expired then
         Changed := True;
      end if;

      --  public endpoints: /health and /keys/<id>/check need no Basic auth
      Public_Req := Req.Kind = Req_Health or else Req.Kind = Req_Check;

      if Public_Req or else Req.Kind = Req_None then
         Authorized := True;
      else
         Auth_Ok (Users, Req, Uname, U_Len, Authorized);
      end if;
      --  missing / malformed credentials leave Authorized = False (401)

      if not Authorized then
         Code    := C401;
         Add_WWW := True;
         Build_Error (Body_Buf, Pos, "unauthorized");
      else
      case Req.Kind is

         when Req_Health =>
            Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
            Append_Q (Body_Buf, Pos, "status");
            Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
            Append_Q (Body_Buf, Pos, "ok");
            Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
            Append_Q (Body_Buf, Pos, "version");
            Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
            Append_Q (Body_Buf, Pos, Version_Str);
            Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
            Append_Q (Body_Buf, Pos, "keys");
            Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
            Kms_Json.Append_U64 (Body_Buf, Pos, U64 (Kms_Keystore.Count (KS)));
            Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
            Code := C200;

         when Req_List =>
            pragma Assert (Pos + 7000 <= Body_Buf'Length);
            Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
            Append_Q (Body_Buf, Pos, "keys");
            Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
            Kms_Json.Append (Body_Buf, Pos, To_Byte ('['));
            for I in Key_Index loop
               exit when Listed = List_Cap;
               if KS (I).In_Use and then
                  Kms_Keystore.Owned (KS, I, Uname, U_Len)
               then
                  if First_Key then
                     First_Key := False;
                  else
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                  end if;
                  Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
                   Kms_Json.Append_Quoted_Text (Body_Buf, Pos, "key_id");
                   Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                   Kms_Json.Append_Quoted_Hex (Body_Buf, Pos,
                                               Kms_Hex.To_Hex (KS (I).Id));
                   Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                   Kms_Json.Append_Quoted_Text (Body_Buf, Pos, "status");
                   Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                   Kms_Json.Append_Quoted_Text
                     (Body_Buf, Pos, Status_Str (KS (I).Status));
                   Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                   Kms_Json.Append_Quoted_Text (Body_Buf, Pos, "activated");
                   Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                   Kms_Json.Append_Bool
                     (Body_Buf, Pos, KS (I).Activated_At /= 0);
                   Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                   Kms_Json.Append_Quoted_Text (Body_Buf, Pos, "expires_at");
                  Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                  Kms_Json.Append_U64
                    (Body_Buf, Pos,
                     (if KS (I).Expires_At >= 0 then U64 (KS (I).Expires_At)
                      else 0));
                  Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
                  Listed := Listed + 1;
               end if;
               pragma Loop_Invariant (Listed <= List_Cap);
               pragma Loop_Invariant (Pos <= 110 * Listed + 40);
            end loop;
            Kms_Json.Append (Body_Buf, Pos, To_Byte (']'));
            Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
            Code := C200;

         when Req_Create =>
            --  Per-key TTL: lifetime_minutes / lifetime_seconds override the
            --  server-wide default lifetime.  Both are capped at 1 year.
            --  The TTL only starts counting once the key is ACTIVATED by
            --  its first successful /keys/<id>/check call.
            TTL_Secs := Lifetime_Days * 86_400;
            Bad_TTL  := False;
            Kms_Json.Find_U64 (Req.Body_Data, Req.Body_Len,
                               "lifetime_minutes", F_Min, V_Min);
            if F_Min then
               if V_Min >= 1 and then V_Min <= 525_600 then
                  TTL_Secs := I64 (V_Min) * 60;
               else
                  Bad_TTL := True;
               end if;
            else
               Kms_Json.Find_U64 (Req.Body_Data, Req.Body_Len,
                                  "lifetime_seconds", F_Sec, V_Sec);
               if F_Sec then
                  if V_Sec >= 1 and then V_Sec <= 31_536_000 then
                     TTL_Secs := I64 (V_Sec);
                  else
                     Bad_TTL := True;
                  end if;
               end if;
            end if;
            if Bad_TTL then
               Code := C400;
               Build_Error (Body_Buf, Pos, "bad_lifetime");
            elsif not Kms_Keystore.Has_Free (KS) then
               Code := C503;
               Build_Error (Body_Buf, Pos, "keystore_full");
            else
               New_Id := Assemble_Id (Seed, 7);
               Kms_Keystore.Find (KS, New_Id, F, Idx);
               if F then
                  Code := C500;
                  Build_Error (Body_Buf, Pos, "id_collision");
               else
                  Kms_Signer.Generate (Seed, Publ, Secre);
                  --  owner = the authenticated developer account
                  New_Rec :=
                    (In_Use       => True,
                     Id           => New_Id,
                     Owner_Len    => U_Len,
                     Owner        => Uname,
                     Pub          => Publ,
                     Sec          => Secre,
                     Secret       => Secret_Seed,
                     Created_At   => Now,
                     Activated_At => 0,
                     Expires_At   => 0,
                     Ttl_Secs     => TTL_Secs,
                     Status       => Active);
                  Kms_Keystore.Insert (KS, New_Rec, Created);
                  if not Created then
                     Code := C503;
                     Build_Error (Body_Buf, Pos, "keystore_full");
                  else
                     Changed := True;
                     Code    := C201;
                     Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
                     Append_Q (Body_Buf, Pos, "key_id");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Json.Append_Quoted (Body_Buf, Pos,
                                             Kms_Hex.To_Hex (New_Id));
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                     Append_Q (Body_Buf, Pos, "public_key");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Base64.Encode (Publ, Sig_B64, Sig_B64_Len);
                     Kms_Json.Append_Quoted (Body_Buf, Pos,
                                             Sig_B64 (0 .. Sig_B64_Len - 1));
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                     Append_Q (Body_Buf, Pos, "activation_secret");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Base64.Encode (Secret_Seed, Sig_B64, Sig_B64_Len);
                     Kms_Json.Append_Quoted (Body_Buf, Pos,
                                             Sig_B64 (0 .. Sig_B64_Len - 1));
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                     Append_Q (Body_Buf, Pos, "created_at");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Json.Append_U64 (Body_Buf, Pos, U64 (Now));
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                     Append_Q (Body_Buf, Pos, "ttl_seconds");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Json.Append_U64 (Body_Buf, Pos, U64 (TTL_Secs));
                     Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
                  end if;
               end if;
            end if;

         when Req_Check =>
            --  Public phone-home: validate the activation secret and, on
            --  the first successful call, ACTIVATE the key (TTL starts).
            Kms_Keystore.Find (KS, Req.Id, F, Idx);
            if not F then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            else
               Kms_Keystore.Get (KS, Idx, Rec);
               if Rec.Status = Revoked then
                  Code := C403;
                  Build_Error (Body_Buf, Pos, "revoked");
               else
                  Secret_OK (Req.Body_Data, Req.Body_Len, Rec.Secret,
                             Sec_OK);
                  if not Sec_OK then
                     Code := C401;
                     Build_Error (Body_Buf, Pos, "bad_secret");
                  elsif Rec.Activated_At = 0 then
                     --  first activation: TTL starts counting now.
                     --  Ttl_Secs is written by us at creation and always
                     --  within bounds; the guard keeps the arithmetic
                     --  provable even for a (corrupt) keystore file.
                     if Rec.Ttl_Secs >= 0 and then
                        Rec.Ttl_Secs <= 2 ** 62 - Now
                     then
                        Kms_Keystore.Activate (KS, Idx, Now);
                        Changed := True;
                        Code := C200;
                        Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
                        Append_Q (Body_Buf, Pos, "key_id");
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                        Kms_Json.Append_Quoted (Body_Buf, Pos,
                                                Kms_Hex.To_Hex (Rec.Id));
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                        Append_Q (Body_Buf, Pos, "valid");
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                        Kms_Json.Append_Bool (Body_Buf, Pos, True);
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                        Append_Q (Body_Buf, Pos, "activated_at");
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                        Kms_Json.Append_U64 (Body_Buf, Pos, U64 (Now));
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                        Append_Q (Body_Buf, Pos, "expires_at");
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                        Kms_Json.Append_U64
                          (Body_Buf, Pos, U64 (Now + Rec.Ttl_Secs));
                        Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
                     else
                        --  defensive: a corrupt slot must not be activated
                        Code := C500;
                        Build_Error (Body_Buf, Pos, "corrupt_keystore");
                     end if;
                  else
                     --  already activated: report remaining validity
                     Code := C200;
                     Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
                     Append_Q (Body_Buf, Pos, "key_id");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Json.Append_Quoted (Body_Buf, Pos,
                                             Kms_Hex.To_Hex (Rec.Id));
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                     Append_Q (Body_Buf, Pos, "valid");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Json.Append_Bool (Body_Buf, Pos, True);
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                     Append_Q (Body_Buf, Pos, "activated_at");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Json.Append_U64
                       (Body_Buf, Pos,
                        (if Rec.Activated_At >= 0 then U64 (Rec.Activated_At)
                         else 0));
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                     Append_Q (Body_Buf, Pos, "expires_at");
                     Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                     Kms_Json.Append_U64
                       (Body_Buf, Pos,
                        (if Rec.Expires_At >= 0 then U64 (Rec.Expires_At)
                         else 0));
                     Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
                  end if;
               end if;
            end if;

         when Req_Public =>
            Kms_Keystore.Find (KS, Req.Id, F, Idx);
            if not F then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            elsif not Kms_Keystore.Owned (KS, Idx, Uname, U_Len) then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            else
               Kms_Keystore.Get (KS, Idx, Rec);
               Code := C200;
               Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
               Append_Q (Body_Buf, Pos, "key_id");
               Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
               Kms_Json.Append_Quoted (Body_Buf, Pos,
                                       Kms_Hex.To_Hex (Rec.Id));
               Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
               Append_Q (Body_Buf, Pos, "public_key");
               Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
               Kms_Base64.Encode (Rec.Pub, Sig_B64, Sig_B64_Len);
               Kms_Json.Append_Quoted (Body_Buf, Pos,
                                       Sig_B64 (0 .. Sig_B64_Len - 1));
               Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
            end if;

         when Req_Sign =>
            Kms_Keystore.Find (KS, Req.Id, F, Idx);
            if not F then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            elsif not Kms_Keystore.Owned (KS, Idx, Uname, U_Len) then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            else
               Kms_Keystore.Get (KS, Idx, Rec);
               if Rec.Status /= Active then
                  Code := C403;
                  Build_Error (Body_Buf, Pos, "key_unavailable");
               else
                  Kms_Json.Find_String (Req.Body_Data, Req.Body_Len,
                                        "message", F, Msg_B64, Msg_B64_Len);
                  if not F then
                     Code := C400;
                     Build_Error (Body_Buf, Pos, "missing_message");
                  elsif Msg_B64_Len > 1024 then
                     Code := C400;
                     Build_Error (Body_Buf, Pos, "message_too_large");
                  else
                     Kms_Base64.Decode (Msg_B64, Msg_B64_Len,
                                        Msg_Alloc, Msg_Len, Valid_B64);
                     if not Valid_B64 then
                        Code := C400;
                        Build_Error (Body_Buf, Pos, "bad_message");
                     else
                        Kms_Signer.Sign_Detached
                          (Rec.Sec, Msg_Alloc (0 .. Msg_Len - 1), Sig);
                        Kms_Base64.Encode (Sig, Sig_B64, Sig_B64_Len);
                        Code := C200;
                        Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
                        Append_Q (Body_Buf, Pos, "key_id");
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                        Kms_Json.Append_Quoted (Body_Buf, Pos,
                                                Kms_Hex.To_Hex (Rec.Id));
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                        Append_Q (Body_Buf, Pos, "signature");
                        Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                        Kms_Json.Append_Quoted
                          (Body_Buf, Pos,
                           Sig_B64 (0 .. Sig_B64_Len - 1));
                        Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
                     end if;
                  end if;
               end if;
            end if;

         when Req_Verify =>
            Kms_Keystore.Find (KS, Req.Id, F, Idx);
            if not F then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            elsif not Kms_Keystore.Owned (KS, Idx, Uname, U_Len) then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            else
               Kms_Keystore.Get (KS, Idx, Rec);
               Kms_Json.Find_String (Req.Body_Data, Req.Body_Len,
                                     "message", F, Msg_B64, Msg_B64_Len);
               if not F then
                  Code := C400;
                  Build_Error (Body_Buf, Pos, "missing_message");
               elsif Msg_B64_Len > 1024 then
                  Code := C400;
                  Build_Error (Body_Buf, Pos, "message_too_large");
               else
                  Kms_Base64.Decode (Msg_B64, Msg_B64_Len,
                                     Msg_Alloc, Msg_Len, Valid_B64);
                  if not Valid_B64 then
                     Code := C400;
                     Build_Error (Body_Buf, Pos, "bad_message");
                  else
                     Kms_Json.Find_String (Req.Body_Data, Req.Body_Len,
                                           "signature", F, Sig_B64,
                                           Sig_B64_Len);
                     if not F then
                        Code := C400;
                        Build_Error (Body_Buf, Pos, "missing_signature");
                     elsif Sig_B64_Len > 96 then
                        Code := C400;
                        Build_Error (Body_Buf, Pos, "bad_signature");
                     else
                        Kms_Base64.Decode (Sig_B64, Sig_B64_Len,
                                           Sig_Dec, Sig_Len, Valid_B64);
                        if not Valid_B64 or else Sig_Len /= 64 then
                           Code := C400;
                           Build_Error (Body_Buf, Pos, "bad_signature");
                        else
                           for K in Signature_Bytes'Range loop
                              Sig (K) := Sig_Dec (K);
                              pragma Loop_Invariant
                                (for all J in Sig'First .. K =>
                                   Sig (J) = Sig_Dec (J));
                           end loop;
                           Kms_Signer.Verify_Detached
                             (Rec.Pub,
                              Msg_Alloc (0 .. Msg_Len - 1),
                              Sig,
                              Valid_Sig);
                           Code := C200;
                           Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
                           Append_Q (Body_Buf, Pos, "key_id");
                           Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                           Kms_Json.Append_Quoted (Body_Buf, Pos,
                                                   Kms_Hex.To_Hex (Rec.Id));
                           Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
                           Append_Q (Body_Buf, Pos, "valid");
                           Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
                           Kms_Json.Append_Bool (Body_Buf, Pos, Valid_Sig);
                           Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
                        end if;
                     end if;
                  end if;
               end if;
            end if;

         when Req_Revoke =>
            Kms_Keystore.Find (KS, Req.Id, F, Idx);
            if not F then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            elsif not Kms_Keystore.Owned (KS, Idx, Uname, U_Len) then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            else
               Kms_Keystore.Revoke (KS, Idx);
               Changed := True;
               Code := C200;
               Kms_Json.Append (Body_Buf, Pos, To_Byte ('{'));
               Append_Q (Body_Buf, Pos, "key_id");
               Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
               Kms_Json.Append_Quoted (Body_Buf, Pos,
                                       Kms_Hex.To_Hex (Req.Id));
               Kms_Json.Append (Body_Buf, Pos, To_Byte (','));
               Append_Q (Body_Buf, Pos, "status");
               Kms_Json.Append (Body_Buf, Pos, To_Byte (':'));
               Append_Q (Body_Buf, Pos, "revoked");
               Kms_Json.Append (Body_Buf, Pos, To_Byte ('}'));
            end if;

         when Req_None =>
            --  Parse failed: report the precise error class.
            if Req.Error = Err_Method then
               Code := C405;
               Build_Error (Body_Buf, Pos, "method_not_allowed");
            elsif Req.Error = Err_Not_Found then
               Code := C404;
               Build_Error (Body_Buf, Pos, "not_found");
            elsif Req.Error = Err_Too_Large then
               Code := C413;
               Build_Error (Body_Buf, Pos, "payload_too_large");
            elsif Req.Error = Err_Bad_Request then
               Code := C400;
               Build_Error (Body_Buf, Pos, "bad_request");
            else
               Code := C500;
               Build_Error (Body_Buf, Pos, "internal_error");
            end if;
      end case;
      end if;

      pragma Assert (Pos <= 115_000);
      Write_Envelope (Code, Pos, Add_WWW, Resp, Env_Len);
      for I in 0 .. Pos - 1 loop
         Resp (Env_Len + I) := Body_Buf (I);
      end loop;
      Resp_Len := Env_Len + Pos;
   end Dispatch;

end Kms_Http;
