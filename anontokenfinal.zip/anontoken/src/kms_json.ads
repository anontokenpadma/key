------------------------------------------------------------------------------
--  Kms_Json : minimal JSON object builder and field lookup.
--  Only the subset needed by the HTTP API is supported.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Json
  with SPARK_Mode => On
is

   --  Append one byte at Pos and advance Pos.
   procedure Append (Buf : in out Byte_Array;
                     Pos : in out N32;
                     C   : in     Byte)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos < Buf'Length,
          Post => Pos = Pos'Old + 1;

   --  Append raw ASCII text (no quoting, no escaping).
   procedure Append_Text (Buf : in out Byte_Array;
                          Pos : in out N32;
                          S   : in     String)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  S'Length <= Max_Short_Length and then
                  Pos <= Buf'Length and then
                  Pos + S'Length <= Buf'Length,
          Post => Pos = Pos'Old + S'Length;

   --  Append "\"" S "\"" where S is an ASCII byte array (0-based).
   --  '"' and '\' inside S are escaped (so the worst case needs 2x+2).
   procedure Append_Quoted (Buf : in out Byte_Array;
                            Pos : in out N32;
                            S   : in     Byte_Array)
     with Global => null,
          Pre  => Buf'First = 0 and then S'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  S'Length <= Max_Short_Length and then
                  Pos <= Buf'Length and then
                  Pos + 2 * S'Length + 2 <= Buf'Length,
          Post => Pos >= Pos'Old + S'Length + 1 and then
                  Pos <= Pos'Old + 2 * S'Length + 2;

   --  Same, but for an Ada String (no escaping; the callers only pass
   --  plain ASCII like JSON keys and status names).
   procedure Append_Quoted_Text (Buf : in out Byte_Array;
                                 Pos : in out N32;
                                 S   : in     String)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  S'Length <= Max_Short_Length and then
                  Pos <= Buf'Length and then
                  Pos + S'Length + 2 <= Buf'Length,
          Post => Pos = Pos'Old + S'Length + 2;

   --  16-character hex string (a base-16 key id).
   subtype Hex_Word is Byte_Array (0 .. 2 * Key_Id_Length - 1);

   --  Append "\"" H "\"" where H is a fixed-length hex string (16 ASCII
   --  chars, e.g. a key id).  Hex characters never need escaping, so the
   --  postcondition is exact - this keeps the per-entry size bound of the
   --  /keys list loop tight enough to prove.
   procedure Append_Quoted_Hex (Buf : in out Byte_Array;
                                Pos : in out N32;
                                H   : in     Hex_Word)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos <= Buf'Length and then
                  Pos + 2 * Key_Id_Length + 2 <= Buf'Length,
          Post => Pos = Pos'Old + 2 * Key_Id_Length + 2;

   --  Append the decimal representation of an unsigned 64-bit value.
   procedure Append_U64 (Buf : in out Byte_Array;
                         Pos : in out N32;
                         V   : in     U64)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos <= Buf'Length and then
                  Pos + 20 <= Buf'Length,
          Post => Pos > Pos'Old and then Pos <= Pos'Old + 20;

   --  Append "true" or "false".
   procedure Append_Bool (Buf : in out Byte_Array;
                          Pos : in out N32;
                          B   : in     Boolean)
     with Global => null,
          Pre  => Buf'First = 0 and then
                  Buf'Length <= Max_Response_Length and then
                  Pos <= Buf'Length and then
                  Pos + 5 <= Buf'Length,
          Post => Pos > Pos'Old and then Pos <= Pos'Old + 5;

   --  Look up the string value of Key inside a flat JSON object stored in
   --  Data (0 .. Len-1).  Pattern searched:  "key" :  "value".
   --  Found is False when the key is absent or its value is malformed or
   --  longer than Val'Length.
   procedure Find_String (Data    : in  Byte_Array;
                          Len     : in  N32;
                          Key     : in  String;
                          Found   : out Boolean;
                          Val     : out Byte_Array;
                          Val_Len : out N32)
     with Global => null,
          Pre  => Data'First = 0 and then
                  Data'Length <= Max_Request_Length and then
                  Len <= Data'Length and then
                  Key'Length <= Max_Short_Length and then
                  Val'First = 0 and then
                  Val'Length <= Max_Response_Length,
          Post => (if not Found then Val_Len = 0) and then
                  Val_Len <= Val'Length;

   --  Look up the unsigned integer value of Key.  Pattern searched:
   --  "key" :  <digits>.  Found is False when the key is absent, its value
   --  is not a plain decimal number, or the number overflows U64.
   procedure Find_U64 (Data    : in  Byte_Array;
                       Len     : in  N32;
                       Key     : in  String;
                       Found   : out Boolean;
                       Value   : out U64)
     with Global => null,
          Pre  => Data'First = 0 and then
                  Data'Length <= Max_Request_Length and then
                  Len <= Data'Length and then
                  Key'Length <= Max_Short_Length,
          Post => (if not Found then Value = 0);

end Kms_Json;
