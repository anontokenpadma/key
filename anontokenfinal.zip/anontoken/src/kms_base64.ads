------------------------------------------------------------------------------
--  Kms_Base64 : RFC 4648 base64 (with padding) for byte arrays.
--  All arrays are 0-based.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Base64
  with SPARK_Mode => On
is

   --  The base64 alphabet (RFC 4648), as a String.
   Alphabet_Str : constant String :=
     "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

   --  Character for a 6-bit value; Pre requires V <= 63.
   function Alphabet_Char (V : Natural) return Byte
     with Global => null,
          Pre => V <= 63 and then V >= 0,
          Post   => (if V <= 25 then Alphabet_Char'Result =
                       Byte (Character'Pos ('A') + V)
                     elsif V <= 51 then Alphabet_Char'Result =
                       Byte (Character'Pos ('a') + V - 26)
                     elsif V <= 61 then Alphabet_Char'Result =
                       Byte (Character'Pos ('0') + V - 52)
                     elsif V = 62 then Alphabet_Char'Result =
                       Character'Pos ('+')
                     else Alphabet_Char'Result = Character'Pos ('/'));

   --  Decoded byte value for an alphabet character; returns -1 when C is
   --  not a valid base64 character ('=' excluded).
   function Decode_Char (C : Byte) return Integer
     with Global => null,
          Post   => Decode_Char'Result in -1 .. 63;

   --  Encode M (0-based, length <= Max_Message_Length) into Out_Buf.
   --  Out_Len is always 4 * ((M'Length + 2) / 3).
   procedure Encode (M       : in  Byte_Array;
                     Out_Buf : out Base64_Buffer;
                     Out_Len : out N32)
     with Global => null,
          Pre  => M'First = 0 and then
                  M'Length <= Max_Message_Length and then
                  Out_Buf'First = 0 and then
                  Out_Buf'Length >= 4 * ((M'Length + 2) / 3),
          Post => Out_Len = 4 * ((M'Length + 2) / 3);

   --  Decode In_Buf (0 .. In_Len-1) into Out_Buf.  Valid is True only when
   --  the input is well-formed base64 (length multiple of 4, '=' only as a
   --  proper suffix).  Requires Out_Buf'Length >= 3 * (In_Len / 4).
   procedure Decode (In_Buf  : in  Byte_Array;
                     In_Len  : in  N32;
                     Out_Buf : out Byte_Array;
                     Out_Len : out N32;
                     Valid   : out Boolean)
     with Global => null,
          Pre  => In_Buf'First = 0 and then
                  In_Buf'Length <= Max_Base64_Length and then
                  In_Len <= In_Buf'Length and then
                  Out_Buf'First = 0 and then
                  Out_Buf'Length <= Max_Response_Length and then
                  Out_Buf'Length >= 3 * (In_Len / 4),
          Post => (if not Valid then Out_Len = 0)
                  and then Out_Len <= 3 * (In_Len / 4);

end Kms_Base64;