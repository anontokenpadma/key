with SPARKNaCl;
with SPARKNaCl.Sign;
with SPARKNaCl.Sign.Utils;

package body Kms_Signer
  with SPARK_Mode => On
is

   --------------
   -- Generate --
   --------------

   procedure Generate (Seed : in  Kms_Types.Seed_Bytes;
                       Pub  : out Kms_Types.Bytes_32;
                       Sec  : out Kms_Types.Bytes_64) is
      SK : SPARKNaCl.Sign.Signing_SK;
      PK : SPARKNaCl.Sign.Signing_PK;
   begin
      SPARKNaCl.Sign.Keypair (SK_Raw => SPARKNaCl.Bytes_32 (Seed),
                              PK     => PK,
                              SK     => SK);
      Pub := Kms_Types.Bytes_32 (SPARKNaCl.Sign.Serialize (PK));
      Sec := Kms_Types.Bytes_64 (SPARKNaCl.Sign.Serialize (SK));
      SPARKNaCl.Sign.Sanitize (PK);
      SPARKNaCl.Sign.Sanitize (SK);
   end Generate;

   ------------------
   -- Sign_Detached --
   ------------------

   procedure Sign_Detached (Sec : in  Kms_Types.Bytes_64;
                            Msg : in  Kms_Types.Byte_Array;
                            Sig : out Kms_Types.Signature_Bytes) is
      SK : SPARKNaCl.Sign.Signing_SK;
      SM : SPARKNaCl.Byte_Seq (0 .. Msg'Length + 63);
      M  : SPARKNaCl.Byte_Seq (0 .. Msg'Length - 1);
   begin
      SPARKNaCl.Sign.Utils.Construct (X => SPARKNaCl.Bytes_64 (Sec),
                                      Y => SK);
      M  := SPARKNaCl.Byte_Seq (Msg);
      SPARKNaCl.Sign.Sign (SM => SM,
                           M  => M,
                           SK => SK);
      Sig := (others => 0);
      for I in Sig'Range loop
         Sig (I) := SM (I);
         pragma Loop_Invariant
           (for all J in Sig'First .. I => Sig (J) = SM (J));
      end loop;
      SPARKNaCl.Sign.Sanitize (SK);
   end Sign_Detached;

   ---------------------
   -- Verify_Detached --
   ---------------------

   procedure Verify_Detached (Pub   : in  Kms_Types.Bytes_32;
                              Msg   : in  Kms_Types.Byte_Array;
                              Sig   : in  Kms_Types.Signature_Bytes;
                              Valid : out Boolean) is
      PK     : SPARKNaCl.Sign.Signing_PK;
      SM     : SPARKNaCl.Byte_Seq (0 .. Msg'Length + 63);
      M      : SPARKNaCl.Byte_Seq (0 .. Msg'Length + 63);
      MLen   : SPARKNaCl.I32;
      Status : Boolean;
      Same   : Boolean := True;
   begin
      SPARKNaCl.Sign.PK_From_Bytes (PK_Raw => SPARKNaCl.Bytes_32 (Pub),
                                    PK     => PK);

      SM := (others => 0);
      --  SM = Sig || Msg
      for I in Sig'Range loop
         SM (I) := Sig (I);
         pragma Loop_Invariant
           (for all J in Sig'First .. I => SM (J) = Sig (J));
      end loop;
      for I in 0 .. Kms_Types.N32 (Msg'Length) - 1 loop
         SM (Kms_Types.N32 (I) + 64) := Msg (I);
         pragma Loop_Invariant
           (for all J in 0 .. I =>
              SM (Kms_Types.N32 (J) + 64) = Msg (J));
      end loop;

      SPARKNaCl.Sign.Open (M      => M,
                           Status => Status,
                           MLen   => MLen,
                           SM     => SM,
                           PK     => PK);

      Valid := Status and then MLen = Msg'Length;
      if Valid then
         for I in 0 .. Kms_Types.N32 (Msg'Length) - 1 loop
            if M (I) /= Msg (I) then
               Same := False;
            end if;
            pragma Loop_Invariant
              (Same = (for all J in 0 .. I => M (J) = Msg (J)));
         end loop;
         Valid := Valid and Same;
      end if;

      SPARKNaCl.Sign.Sanitize (PK);
   end Verify_Detached;

end Kms_Signer;