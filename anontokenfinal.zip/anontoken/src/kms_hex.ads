------------------------------------------------------------------------------
--  Kms_Hex : hexadecimal encoding of 64-bit key identifiers.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Hex
  with SPARK_Mode => On
is

   subtype Hex_Buffer is Byte_Array (0 .. 2 * Key_Id_Length - 1);

   --  Returns True when C is one of 0-9, a-f, A-F.
   function Is_Hex_Digit (C : Byte) return Boolean
     with Global => null;

   --  Numeric value of a hex digit; Pre requires Is_Hex_Digit.
   function Hex_Value (C : Byte) return Natural
     with Global => null,
          Pre  => C in 48 .. 57 or C in 97 .. 102 or C in 65 .. 70,
          Post => Hex_Value'Result <= 15;

   --  Character for a nibble; Pre requires 0 <= V <= 15.
   function Nibble_To_Char (V : Natural) return Byte
     with Global => null,
          Pre  => V <= 15;

   --  Encode Id as 16 lowercase hex characters, most significant first.
   function To_Hex (Id : Key_Id) return Hex_Buffer
     with Global => null;

   --  Decode 16 hex characters into Id.  Valid is False when any character
   --  is not a hex digit.
   procedure From_Hex (S     : in  Hex_Buffer;
                       Valid : out Boolean;
                       Id    : out Key_Id)
     with Global => null;

end Kms_Hex;