------------------------------------------------------------------------------
--  Kms_Passwd : password digest derivation (PBKDF2-HMAC-SHA256, RFC 2898).
--
--  Used identically by both binaries:
--    * the ``admin`` tool derives a digest when an account is created or
--      its password is changed (salt is fresh random 32 bytes);
--    * the server re-derives the digest from the presented password and
--      the stored salt on every authenticated request, then compares it
--      with the stored digest using a constant-time comparison.
--
--  Only the 32-byte digest and the salt ever reach disk - never the
--  password itself.  The derivation runs on the fully SPARK-proven
--  SPARKNaCl MAC (HMAC) so no new cryptography is written here.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Passwd
  with SPARK_Mode => On
is

   --  Derive Output = PBKDF2-HMAC-SHA256 (Pass, Salt, blocksize=1) with
   --  Pbkdf2_Iterations rounds.  Pass must be 0-based and non-empty.
   procedure Derive (Salt   : in     Digest_Bytes;
                     Pass   : in     Byte_Array;
                     Output :    out Digest_Bytes)
     with Global => null,
          Pre  => Pass'First = 0 and then
                  Pass'Length >= 1 and then
                  Pass'Length <= Password_Length;

end Kms_Passwd;