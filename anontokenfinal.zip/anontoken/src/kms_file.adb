------------------------------------------------------------------------------
--  Kms_File implementation (fully SPARK, SPARK_Mode => On).
--  Every filesystem operation goes through the Kms_Os C imports which
--  carry Global/Depends contracts; no exceptions, no stream libraries.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;

with Kms_Os;

package body Kms_File
  with SPARK_Mode => On
is

   use Kms_Os;
   use Kms_Types;

   Version_V1 : constant := 1;                     --  fixed 64-slot file
   Version_V2 : constant := 2;                     --  dynamic (live slots only)
   Version_V3 : constant := 3;                     --  dynamic, v3 slots

   Header_Size : constant := 8;
   Slot_Size   : constant := 195;                  --  v3 slot
   Legacy_Slot : constant := 122;                  --  v1/v2 slot

   --  v1 files always had exactly 64 fixed slots.
   Legacy_Keys  : constant := 64;
   subtype Legacy_Index is Key_Index range 0 .. Legacy_Keys - 1;

   --  Users file (magic "ANKU", version 1).
   Users_Max_Entry : constant := 1 + User_Name_Length + 2 * Digest_Length;
   Users_File_Max  : constant := 12 + Max_Users * Users_Max_Entry;

   subtype Slot_Bytes   is Byte_Array (0 .. Slot_Size - 1);
   subtype Legacy_Bytes is Byte_Array (0 .. Legacy_Slot - 1);
   subtype Users_Bytes  is Byte_Array (0 .. Users_File_Max - 1);

   -------------------
   -- Byte helpers --
   -------------------

   procedure Set_B (A : in out Byte_Array; Off : in N32; V : Byte)
     with Pre => A'First = 0 and then Off <= A'Last
   is
   begin
      A (Off) := V;
   end Set_B;

   function B (A : Byte_Array; Off : N32) return Byte is (A (Off))
     with Pre => A'First = 0 and then Off <= A'Last;

   procedure Put_U64_LE (A : in out Byte_Array; Off : in N32; V : U64)
     with Pre => A'First = 0 and then A'Last >= 7 and then
                 Off <= A'Last - 7
   is
      X : U64 := V;
   begin
      for I in N32 range 0 .. 7 loop
         pragma Loop_Invariant (Off + I <= A'Last);
         Set_B (A, Off + I, Byte (X mod 256));
         X := X / 256;
      end loop;
   end Put_U64_LE;

   function Get_U64_LE (A : Byte_Array; Off : N32) return U64
     with Pre => A'First = 0 and then A'Last >= 7 and then
                 Off <= A'Last - 7
   is
      V : U64 := 0;
   begin
      for I in reverse N32 range 0 .. 7 loop
         pragma Loop_Invariant (Off + I <= A'Last);
         V := V * 256 + U64 (B (A, Off + I));
      end loop;
      return V;
   end Get_U64_LE;

   procedure Put_I64_LE (A : in out Byte_Array; Off : in N32; V : I64)
     with Pre => A'First = 0 and then A'Last >= 7 and then
                 Off <= A'Last - 7
   is
   begin
      --  two's complement round-trip: no range check needed
      Put_U64_LE (A, Off, U64'Mod (V));
   end Put_I64_LE;

   function Get_I64_LE (A : Byte_Array; Off : N32) return I64
     with Pre => A'First = 0 and then A'Last >= 7 and then
                 Off <= A'Last - 7
   is
      V : constant U64 := Get_U64_LE (A, Off);
   begin
      --  two's complement round-trip: no range check needed
      if V < U64 (2 ** 62) + U64 (2 ** 62) then
         return I64 (V);
      else
         --  V >= 2**63: result is negative; split the subtraction so no
         --  intermediate value leaves the I64 range.
         return (I64 (V - (U64 (2 ** 62) + U64 (2 ** 62)))
                 - I64 (2 ** 62) - I64 (2 ** 62));
      end if;
   end Get_I64_LE;

   function Get_U32_LE (A : Byte_Array; Off : N32) return Interfaces.Unsigned_32
     with Pre => A'First = 0 and then A'Last >= 3 and then
                 Off <= A'Last - 3
   is
      V : Interfaces.Unsigned_32 := 0;
   begin
      for I in reverse N32 range 0 .. 3 loop
         pragma Loop_Invariant (Off + I <= A'Last);
         V := V * 256 + Interfaces.Unsigned_32 (B (A, Off + I));
      end loop;
      return V;
   end Get_U32_LE;

   -------------------
   -- Status code   --
   -------------------

   function Status_To_Byte (S : Key_Status) return Byte is
   begin
      case S is
         when Active  => return 0;
         when Expired => return 1;
         when Revoked => return 2;
      end case;
   end Status_To_Byte;

   function Byte_To_Status (B : Byte) return Key_Status is
   begin
      case B is
         when 0 => return Active;
         when 1 => return Expired;
         when others => return Revoked;
      end case;
   end Byte_To_Status;

   ----------------
   -- v3 slots   --
   ----------------

   --  Layout (195 bytes):  in_use u8 | owner_len u8 | owner 24b | id u64 |
   --  pub 32b | sec 64b | secret 32b | created i64 | activated i64 |
   --  expires i64 | ttl i64 | status u8
   --  Offsets: 0 in_use, 1 owner_len, 2..25 owner, 26..33 id,
   --           34..65 pub, 66..129 sec, 130..161 secret,
   --           162..169 created, 170..177 activated, 178..185 expires,
   --           186..193 ttl, 194 status.

   procedure Fill_Slot (S : out Slot_Bytes; R : in Key_Record) is
   begin
      S := (others => 0);
      Set_B (S, 0, 1);                                  --  in-use
      Set_B (S, 1, Byte (R.Owner_Len));
      for I in N32 range 0 .. N32 (User_Name_Length) - 1 loop
         Set_B (S, 2 + I, R.Owner (I));
      end loop;
      Put_U64_LE (S, 26, U64 (R.Id));
      for I in R.Pub'Range loop
         Set_B (S, 34 + (I - R.Pub'First), R.Pub (I));
      end loop;
      for I in R.Sec'Range loop
         Set_B (S, 66 + (I - R.Sec'First), R.Sec (I));
      end loop;
      for I in R.Secret'Range loop
         Set_B (S, 130 + (I - R.Secret'First), R.Secret (I));
      end loop;
      Put_I64_LE (S, 162, R.Created_At);
      Put_I64_LE (S, 170, R.Activated_At);
      Put_I64_LE (S, 178, R.Expires_At);
      Put_I64_LE (S, 186, R.Ttl_Secs);
      Set_B (S, 194, Status_To_Byte (R.Status));
   end Fill_Slot;

   procedure Parse_Slot (S : in Slot_Bytes; R : out Key_Record) is
      L : N32;
   begin
      R := (In_Use => False, others => <>);
      if B (S, 0) = 0 then
         return;
      end if;
      R.In_Use     := True;
      L := N32 (B (S, 1));
      if L > N32 (User_Name_Length) then
         L := 0;
      end if;
      R.Owner_Len := L;
      for J in 0 .. L - 1 loop
         R.Owner (J) := B (S, 2 + J);
      end loop;
      R.Id         := Key_Id (Get_U64_LE (S, 26));
      for I in R.Pub'Range loop
         R.Pub (I) := B (S, 34 + (I - R.Pub'First));
      end loop;
      for I in R.Sec'Range loop
         R.Sec (I) := B (S, 66 + (I - R.Sec'First));
      end loop;
      for I in R.Secret'Range loop
         R.Secret (I) := B (S, 130 + (I - R.Secret'First));
      end loop;
      R.Created_At   := Get_I64_LE (S, 162);
      R.Activated_At := Get_I64_LE (S, 170);
      R.Expires_At   := Get_I64_LE (S, 178);
      R.Ttl_Secs     := Get_I64_LE (S, 186);
      R.Status       := Byte_To_Status (B (S, 194));
   end Parse_Slot;

   --------------------------------
   --  Low-level fd helpers      --
   --------------------------------

   --  Atomic write of the N first bytes of W; returns True when the
   --  whole chunk was accepted by the kernel.
   function Write_All (Fd : C_Int; W : in Chunk; N : N32) return Boolean is
      R : C_SSize;
   begin
      if N = 0 then
         return True;
      end if;
      C_Write (Fd, W, C_Size (Natural (N)), R);
      return R = C_SSize (N);
   end Write_All;

   --  Read up to Want bytes into Out_Buf (0 .. Got-1).  Got < Want means
   --  the file ended early; Got = 0 is a clean EOF at a boundary.
   --  Reading is chunked through the 4 KiB C buffer, and Want is bounded
   --  so the chunk never overflows and Out_Buf is never overrun.
   procedure Read_Some (Fd      : in  C_Int;
                        Out_Buf : out Byte_Array;
                        Want    : in  N32;
                        Got     : out N32)
     with Pre => Out_Buf'First = 0 and then
                 Want >= 1 and then Want - 1 <= Out_Buf'Last and then
                 Want <= N32 (Chunk'Length)
   is
      C    : Chunk := (others => 0);
      R    : C_SSize;
      Pos  : N32 := 0;
      Take : N32;
   begin
      Out_Buf := (others => 0);
      while Pos < Want loop
         pragma Loop_Invariant (Pos <= Want);
         --  Want <= Chunk'Length and Pos < Want, so a single chunk
         --  always holds the remaining bytes: no Min needed here.
         Take := Want - Pos;
         C_Read (Fd, C, C_Size (Natural (Take)), R);
         exit when R <= 0;
         for I in 0 .. N32 (R) - 1 loop
            pragma Loop_Invariant (Pos + I <= Want - 1);
            Out_Buf (Pos + I) := C (I);
         end loop;
         Pos := Pos + N32 (R);
      end loop;
      Got := Pos;
   end Read_Some;

   procedure Read_Rec (Fd : C_Int; B : out Byte_Array; Sz : N32; OK_Rec : out Boolean)
     with Pre => B'First = 0 and then
                 Sz >= 1 and then Sz - 1 <= B'Last and then
                 Sz <= N32 (Chunk'Length)
   is
      Got : N32;
   begin
      Read_Some (Fd, B, Sz, Got);
      OK_Rec := Got = Sz;
   end Read_Rec;

   ----------
   -- Load --
   ----------

   --  v1 files: header + exactly 64 fixed 122-byte slots.  v1 keys count
   --  their TTL from creation; migrate them as activated-at-creation.
   procedure Load_V1 (Fd : C_Int; KS : in out Keystore; Res : out Boolean) is
      S : Legacy_Bytes;
      R : Key_Record;
      OK_Rec : Boolean;
   begin
      for I in Key_Index'Range loop
         KS (I) := (In_Use => False, others => <>);
      end loop;
      for I in Legacy_Index loop
         Read_Rec (Fd, S, N32 (Legacy_Slot), OK_Rec);
         if not OK_Rec then
            Res := False;
            return;
         end if;
         if B (S, 0) /= 0 then
            R := (In_Use => True, others => <>);
            R.Id          := Key_Id (Get_U64_LE (S, 1));
            for J in R.Pub'Range loop
               R.Pub (J) := B (S, 9 + (J - R.Pub'First));
            end loop;
            for J in R.Sec'Range loop
               R.Sec (J) := B (S, 41 + (J - R.Sec'First));
            end loop;
            R.Created_At   := Get_I64_LE (S, 105);
            R.Expires_At   := Get_I64_LE (S, 113);
            R.Status       := Byte_To_Status (B (S, 121));
            R.Activated_At := R.Created_At;
            --  guard: both timestamps non-negative (legacy v1/v2 files may
            --  hold arbitrary I64s), then the U64 difference cannot
            --  overflow; convert back only when it fits comfortably.
            if R.Created_At >= 0 and then R.Expires_At >= R.Created_At then
               declare
                  Diff : constant U64 :=
                    U64 (R.Expires_At) - U64 (R.Created_At);
               begin
                  if Diff <= U64 (2 ** 62) then
                     R.Ttl_Secs := I64 (Diff);
                  end if;
               end;
            end if;
            KS (I) := R;
         end if;
         pragma Loop_Invariant (I in Legacy_Index);
      end loop;
      Res := True;
   end Load_V1;

   --  v2 files: header + one 122-byte record per live slot, in slot order.
   procedure Load_V2 (Fd : C_Int; KS : in out Keystore; Res : out Boolean) is
      S   : Legacy_Bytes;
      R   : Key_Record;
      Got : N32;
   begin
      for I in Key_Index'Range loop
         KS (I) := (In_Use => False, others => <>);
      end loop;
      for I in Key_Index'Range loop
         Read_Some (Fd, S, N32 (Legacy_Slot), Got);
         exit when Got = 0;                        --  clean end of file
         if Got /= N32 (Legacy_Slot) then
            Res := False;                          --  partial record: corrupt
            return;
         end if;
         if B (S, 0) /= 0 then
            R := (In_Use => True, others => <>);
            R.Id          := Key_Id (Get_U64_LE (S, 1));
            for J in R.Pub'Range loop
               R.Pub (J) := B (S, 9 + (J - R.Pub'First));
            end loop;
            for J in R.Sec'Range loop
               R.Sec (J) := B (S, 41 + (J - R.Sec'First));
            end loop;
            R.Created_At   := Get_I64_LE (S, 105);
            R.Expires_At   := Get_I64_LE (S, 113);
            R.Status       := Byte_To_Status (B (S, 121));
            R.Activated_At := R.Created_At;
            --  guard: both timestamps non-negative (legacy v1/v2 files may
            --  hold arbitrary I64s), then the U64 difference cannot
            --  overflow; convert back only when it fits comfortably.
            if R.Created_At >= 0 and then R.Expires_At >= R.Created_At then
               declare
                  Diff : constant U64 :=
                    U64 (R.Expires_At) - U64 (R.Created_At);
               begin
                  if Diff <= U64 (2 ** 62) then
                     R.Ttl_Secs := I64 (Diff);
                  end if;
               end;
            end if;
            KS (I) := R;
         end if;
      end loop;
      Res := True;
   end Load_V2;

   --  v3 files: header + one 195-byte record per live slot, in slot order.
   procedure Load_V3 (Fd : C_Int; KS : in out Keystore; Res : out Boolean) is
      S   : Slot_Bytes;
      R   : Key_Record;
      Got : N32;
   begin
      for I in Key_Index'Range loop
         KS (I) := (In_Use => False, others => <>);
      end loop;
      for I in Key_Index'Range loop
         Read_Some (Fd, S, N32 (Slot_Size), Got);
         exit when Got = 0;                        --  clean end of file
         if Got /= N32 (Slot_Size) then
            Res := False;                          --  partial record: corrupt
            return;
         end if;
         Parse_Slot (S, R);
         KS (I) := R;
      end loop;
      Res := True;
   end Load_V3;

   procedure Load (Path : in  String;
                   KS   : in out Keystore;
                   OK   :    out Boolean)
   is
      PB  : Path_Buf;
      Fd  : C_Int;
      H   : Chunk := (others => 0);
      V   : U64 := 0;
      Got : N32;
      Res : Boolean := False;
      R   : C_Int;
   begin
      for I in Key_Index'Range loop
         KS (I) := (In_Use => False, others => <>);
      end loop;
      Fill_Path (PB, Path);
      Fd := C_Open (PB, O_RDONLY, 0);
      if Fd < 0 then
         OK := False;
         return;
      end if;
      --  header: "ANKT" + u32 version
      Read_Some (Fd, H, N32 (Header_Size), Got);
      if Got = N32 (Header_Size)
        and then H (0) = Character'Pos ('A')
        and then H (1) = Character'Pos ('N')
        and then H (2) = Character'Pos ('K')
        and then H (3) = Character'Pos ('T')
      then
         for I in reverse N32 range 0 .. 3 loop
            V := V * 256 + U64 (H (4 + I));
         end loop;
         if V = U64 (Version_V1) then
            Load_V1 (Fd, KS, Res);
         elsif V = U64 (Version_V2) then
            Load_V2 (Fd, KS, Res);
         elsif V = U64 (Version_V3) then
            Load_V3 (Fd, KS, Res);
         end if;
      end if;
      R := C_Close (Fd);
      pragma Unreferenced (R);
      OK := Res;
   end Load;

   ----------
   -- Save --
   ----------

   procedure Save (Path : in String; KS : in Keystore) is
      TP  : Path_Buf;
      Fd  : C_Int;
      H   : Chunk := (others => 0);
      C   : U64 := U64 (Version_V3);
      S   : Slot_Bytes;
      W   : Chunk := (others => 0);
      R   : C_Int;
      Fail : Boolean := False;
   begin
      Fill_Path2 (TP, Path, ".tmp");
      Fd := C_Open (TP, O_WRONLY_TRUNC_CREATE, Path_Mode);
      if Fd < 0 then
         return;
      end if;
      --  header
      H (0) := Character'Pos ('A');
      H (1) := Character'Pos ('N');
      H (2) := Character'Pos ('K');
      H (3) := Character'Pos ('T');
      for I in N32 range 0 .. 3 loop
         H (4 + I) := Byte (C mod 256);
         C := C / 256;
      end loop;
      if not Write_All (Fd, H, N32 (Header_Size)) then
         Fail := True;
      else
         for I in Key_Index'Range loop
            if KS (I).In_Use then
               Fill_Slot (S, KS (I));
               for J in N32 range 0 .. N32 (Slot_Size) - 1 loop
                  W (J) := S (J);
               end loop;
               if not Write_All (Fd, W, N32 (Slot_Size)) then
                  Fail := True;
                  exit;
               end if;
            end if;
         end loop;
      end if;
      R := C_Close (Fd);
      declare
         PB : Path_Buf;
      begin
         Fill_Path (PB, Path);
         if Fail then
            R := C_Unlink (TP);
         else
            R := C_Rename (TP, PB);
            if R /= 0 then
               R := C_Unlink (TP);
            end if;
         end if;
      end;
      pragma Unreferenced (R);
   end Save;

   ------------
   -- Exists --
   ------------

   function Exists (Path : String) return Boolean is
      PB : Path_Buf;
   begin
      Fill_Path (PB, Path);
      return C_Access (PB, F_OK) = 0;
   end Exists;

   ----------------
   -- Load_Users --
   ----------------

   procedure Parse_Users (Blob : in Users_Bytes;
                          N    : in N32;
                          T    : in out User_Table;
                          OK   : out Boolean)
     with Pre => N <= Blob'Length
   is
      Off   : N32 := 0;
      Count : N32;
      N_Len : N32;
   begin
      T  := (others => (In_Use => False, others => <>));
      OK := False;
      if N < 12 then
         return;
      end if;
      if not (Blob (0) = Character'Pos ('A') and then
              Blob (1) = Character'Pos ('N') and then
              Blob (2) = Character'Pos ('K') and then
              Blob (3) = Character'Pos ('U'))
      then
         return;
      end if;
      if Get_U32_LE (Blob, 4) /= 1 then
         return;
      end if;
      if Get_U32_LE (Blob, 8) > Unsigned_32 (Max_Users) then
         return;
      end if;
      Count := N32 (Get_U32_LE (Blob, 8));
      Off := 12;
      for I in 0 .. Count - 1 loop
         pragma Loop_Invariant (Off <= N);
         if Off + N32 (Users_Max_Entry) > N then
            return;
         end if;
         pragma Assert (Off + N32 (Users_Max_Entry) <= N);
         N_Len := N32 (Blob (Off));
         if N_Len = 0 or else N_Len > N32 (User_Name_Length) then
            return;
         end if;
         for J in 0 .. N_Len - 1 loop
            pragma Loop_Invariant (Off + 1 + J <= N - 1);
            T (I).Name (J) := Blob (Off + 1 + J);
         end loop;
         for J in T (I).Salt'Range loop
            pragma Loop_Invariant
              (Off + 1 + N32 (User_Name_Length) + J <= N - 1);
            T (I).Salt (J) :=
              Blob (Off + 1 + N32 (User_Name_Length) + J);
         end loop;
         for J in T (I).Hash'Range loop
            pragma Loop_Invariant
              (Off + 1 + N32 (User_Name_Length) + N32 (Digest_Length) + J
               <= N - 1);
            T (I).Hash (J) :=
              Blob (Off + 1 + N32 (User_Name_Length) +
                    N32 (Digest_Length) + J);
         end loop;
         T (I).In_Use   := True;
         T (I).Name_Len := N_Len;
         Off := Off + N32 (Users_Max_Entry);
      end loop;
      OK := True;
   end Parse_Users;

   procedure Load_Users (Path : in  String;
                         T    : in out User_Table;
                         OK   :    out Boolean)
   is
      PB      : Path_Buf;
      Fd      : C_Int;
      Blob    : Users_Bytes := (others => 0);
      Got     : N32 := 0;
      Parse_OK : Boolean;
      C       : Chunk := (others => 0);
      R       : C_SSize;
      RC      : C_Int;
      Take    : N32;
   begin
      Fill_Path (PB, Path);
      Fd := C_Open (PB, O_RDONLY, 0);
      if Fd < 0 then
         OK := False;
         return;
      end if;
      --  read the whole file (bounded by Users_File_Max), in 4 KiB chunks
      Blob := (others => 0);
      while Got < N32 (Users_File_Max) loop
         pragma Loop_Invariant (Got <= N32 (Users_File_Max));
         Take := N32'Min (N32 (Users_File_Max) - Got, N32 (Chunk'Length));
         C_Read (Fd, C, C_Size (Natural (Take)), R);
         exit when R <= 0;
         for I in 0 .. N32 (R) - 1 loop
            pragma Loop_Invariant
              (Got + I <= N32 (Users_File_Max) - 1);
            Blob (Got + I) := C (I);
         end loop;
         Got := Got + N32 (R);
      end loop;
      RC := C_Close (Fd);
      pragma Unreferenced (RC);
      Parse_Users (Blob, Got, T, Parse_OK);
      OK := Parse_OK;
   end Load_Users;

   ----------------
   -- Save_Users --
   ----------------

   procedure Save_Users (Path : in String; T : in User_Table) is
      TP    : Path_Buf;
      PB    : Path_Buf;
      Fd    : C_Int;
      Blob  : Users_Bytes := (others => 0);
      Off   : N32 := 0;
      C     : Interfaces.Unsigned_32;
      W     : Chunk := (others => 0);
      R     : C_Int;
      Fail  : Boolean := False;
      N     : N32 := 0;
      Total : N32;
      Pos   : N32 := 0;
      Take  : N32;
   begin
      Fill_Path2 (TP, Path, ".tmp");
      Fd := C_Open (TP, O_WRONLY_TRUNC_CREATE, Path_Mode);
      if Fd < 0 then
         return;
      end if;
      --  header
      Blob (0) := Character'Pos ('A');
      Blob (1) := Character'Pos ('N');
      Blob (2) := Character'Pos ('K');
      Blob (3) := Character'Pos ('U');
      C := 1;
      for I in N32 range 0 .. 3 loop
         Blob (4 + I) := Byte (C mod 256);
         C := C / 256;
      end loop;
      N := 0;
      for I in T'Range loop
         pragma Loop_Invariant (N <= I);
         if T (I).In_Use then
            N := N + 1;
         end if;
      end loop;
      C := Interfaces.Unsigned_32 (N);
      for I in N32 range 0 .. 3 loop
         Blob (8 + I) := Byte (C mod 256);
         C := C / 256;
      end loop;
      Off := 12;
      for I in T'Range loop
         pragma Loop_Invariant
           (Off <= 12 + N32 (I) * N32 (Users_Max_Entry));
         if T (I).In_Use then
            pragma Assert
              (Off + 1 + N32 (User_Name_Length) +
               N32 (Digest_Length) + N32 (Digest_Length) - 1
               <= N32 (Users_File_Max) - 1);
            Blob (Off) := Byte (T (I).Name_Len);
            for J in 0 .. T (I).Name_Len - 1 loop
               Blob (Off + 1 + J) := T (I).Name (J);
            end loop;
            Blob (Off + 1 + N32 (User_Name_Length) ..
                  Off + N32 (User_Name_Length) + N32 (Digest_Length)) :=
              T (I).Salt;
            Blob (Off + 1 + N32 (User_Name_Length) + N32 (Digest_Length) ..
                  Off + N32 (User_Name_Length) + 2 * N32 (Digest_Length)) :=
              T (I).Hash;
            Off := Off + N32 (Users_Max_Entry);
         end if;
      end loop;
      Total := Off;

      --  flush in 4096-byte chunks
      while Pos < Total loop
         pragma Loop_Invariant (Pos <= Total);
         Take := Total - Pos;
         if Take > N32 (Chunk'Length) then
            Take := N32 (Chunk'Length);
         end if;
         for J in 0 .. Take - 1 loop
            pragma Loop_Invariant (Pos + J <= Total - 1);
            W (J) := Blob (Pos + J);
         end loop;
         if not Write_All (Fd, W, Take) then
            Fail := True;
            exit;
         end if;
         Pos := Pos + Take;
      end loop;
      R := C_Close (Fd);
      Fill_Path (PB, Path);
      if Fail then
         R := C_Unlink (TP);
      else
         R := C_Rename (TP, PB);
         if R /= 0 then
            R := C_Unlink (TP);
         end if;
      end if;
      pragma Unreferenced (R);
   end Save_Users;

end Kms_File;