with Interfaces;
use  Interfaces;

package body Kms_Base64
  with SPARK_Mode => On
is

   ---------------
   -- Alphabet_Char --
   ---------------

   function Alphabet_Char (V : Natural) return Byte is
   begin
      return Byte (Character'Pos (Alphabet_Str (V + 1)));
   end Alphabet_Char;

   ---------------
   -- Decode_Char --
   ---------------

   function Decode_Char (C : Byte) return Integer is
   begin
      if C in Character'Pos ('A') .. Character'Pos ('Z') then
         return Integer (C - Character'Pos ('A'));
      elsif C in Character'Pos ('a') .. Character'Pos ('z') then
         return Integer (C - Character'Pos ('a')) + 26;
      elsif C in Character'Pos ('0') .. Character'Pos ('9') then
         return Integer (C - Character'Pos ('0')) + 52;
      elsif C = Character'Pos ('+') then
         return 62;
      elsif C = Character'Pos ('/') then
         return 63;
      else
         return -1;
      end if;
   end Decode_Char;

   ------------
   -- Encode --
   ------------

   procedure Encode (M       : in  Byte_Array;
                     Out_Buf : out Base64_Buffer;
                     Out_Len : out N32) is
      N : constant N32 := M'Length;
      O : N32         := 0;
   begin
      --  Fully initialise the output (the caller may read the whole buffer).
      Out_Buf := (others => 0);

      if N = 0 then
         Out_Len := 0;
         return;
      end if;

      declare
         Groups : constant N32 := N / 3;
         Remain : constant N32 := N mod 3;
      begin
         for G in 0 .. Groups - 1 loop
            declare
               B0 : constant Byte := M (3 * G);
               B1 : constant Byte := M (3 * G + 1);
               B2 : constant Byte := M (3 * G + 2);
            begin
               Out_Buf (O)     := Alphabet_Char (Natural (B0) / 4);
               Out_Buf (O + 1) := Alphabet_Char
                 (Natural (B0 mod 4) * 16 + Natural (B1) / 16);
               Out_Buf (O + 2) := Alphabet_Char
                 (Natural (B1 mod 16) * 4 + Natural (B2) / 64);
               Out_Buf (O + 3) := Alphabet_Char (Natural (B2 mod 64));
            end;
            O := O + 4;
            pragma Loop_Invariant (O = 4 * (G + 1));
         end loop;

         if Remain = 1 then
            declare
               B0 : constant Byte := M (3 * Groups);
            begin
               Out_Buf (O)     := Alphabet_Char (Natural (B0) / 4);
               Out_Buf (O + 1) := Alphabet_Char (Natural (B0 mod 4) * 16);
               Out_Buf (O + 2) := Character'Pos ('=');
               Out_Buf (O + 3) := Character'Pos ('=');
               O := O + 4;
            end;
         elsif Remain = 2 then
            declare
               B0 : constant Byte := M (3 * Groups);
               B1 : constant Byte := M (3 * Groups + 1);
            begin
               Out_Buf (O)     := Alphabet_Char (Natural (B0) / 4);
               Out_Buf (O + 1) := Alphabet_Char
                 (Natural (B0 mod 4) * 16 + Natural (B1) / 16);
               Out_Buf (O + 2) := Alphabet_Char (Natural (B1 mod 16) * 4);
               Out_Buf (O + 3) := Character'Pos ('=');
               O := O + 4;
            end;
         end if;

         Out_Len := O;
      end;
   end Encode;

   ------------
   -- Decode --
   ------------

   procedure Decode (In_Buf  : in  Byte_Array;
                     In_Len  : in  N32;
                     Out_Buf : out Byte_Array;
                     Out_Len : out N32;
                     Valid   : out Boolean) is
   begin
      --  Fully initialise the output (the caller may read the whole buffer).
      Out_Buf := (others => 0);

      if In_Len mod 4 /= 0 then
         Valid   := False;
         Out_Len := 0;
         return;
      end if;

      declare
         Groups : constant N32 := In_Len / 4;
         O      : N32         := 0;
         Ok     : Boolean     := True;
      begin
         for G in 0 .. Groups - 1 loop
            declare
               C0 : constant Byte := In_Buf (4 * G);
               C1 : constant Byte := In_Buf (4 * G + 1);
               C2 : constant Byte := In_Buf (4 * G + 2);
               C3 : constant Byte := In_Buf (4 * G + 3);
               V0 :          Integer := Decode_Char (C0);
               V1 :          Integer := Decode_Char (C1);
               V2 :          Integer := Decode_Char (C2);
               V3 :          Integer := Decode_Char (C3);
               Pad :         Natural;
            begin
               --  '=' is only legal as a suffix of the whole payload, i.e.
               --  only in the last group, in the last 1 or 2 positions.
               if G /= Groups - 1 then
                  if C2 = Character'Pos ('=') or else C3 = Character'Pos ('=') then
                     Ok := False;
                  end if;
               end if;

               --  First two characters must always be alphabet characters.
               if V0 < 0 or else V1 < 0 then
                  Ok := False;
               end if;

               if V3 < 0 then
                  --  C3 is '=' or invalid: only '=' is acceptable there.
                  if C3 /= Character'Pos ('=') then
                     Ok := False;
                  end if;
                  Pad := 1;
                  --  if C2 is '=' then pad is 2
                  if C2 = Character'Pos ('=') then
                     Pad := 2;
                  elsif V2 < 0 then
                     Ok := False;
                  end if;
               elsif V2 < 0 then
                  Ok := False;
                  Pad := 0;
               else
                  Pad := 0;
               end if;

               if Ok then
                  --  Pad = 0: V0, V1, V2, V3 all in 0 .. 63 here.  When
                  --  Pad = 1 or 2 only V0 and V1 are used (V2 may be -1).
                  if Pad = 0 then
                     Out_Buf (O)     := Byte (V0 * 4 + V1 / 16);
                     Out_Buf (O + 1) := Byte ((V1 mod 16) * 16 + V2 / 4);
                     Out_Buf (O + 2) := Byte ((V2 mod 4) * 64 + V3);
                     O := O + 3;
                  elsif Pad = 1 then
                     Out_Buf (O)     := Byte (V0 * 4 + V1 / 16);
                     Out_Buf (O + 1) := Byte ((V1 mod 16) * 16 + V2 / 4);
                     O := O + 2;
                  else
                     Out_Buf (O) := Byte (V0 * 4 + V1 / 16);
                     O := O + 1;
                  end if;
               end if;
            end;
            pragma Loop_Invariant (O <= 3 * (G + 1));
         end loop;

         if Ok then
            Out_Len := O;
         else
            Out_Len := 0;
         end if;
         Valid := Ok;
         pragma Assert (Out_Len <= 3 * Groups);
         pragma Assert (Out_Len <= 3 * (In_Len / 4));
      end;
   end Decode;

end Kms_Base64;