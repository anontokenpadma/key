------------------------------------------------------------------------------
--  Kms_Signer : Ed25519 key generation, detached signing, verification.
--  Thin SPARK wrappers over the fully-proven SPARKNaCl.Sign.
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Signer
  with SPARK_Mode => On
is

   --  Generate an Ed25519 key pair from a 32-byte random seed.
   --  Sec is the SPARKNaCl serialised secret key (64 bytes).
   procedure Generate (Seed : in  Seed_Bytes;
                       Pub  : out Bytes_32;
                       Sec  : out Bytes_64)
     with Global => null;

   --  Detached signature over Msg (0-based, length <= Max_Message_Length).
   procedure Sign_Detached (Sec : in  Bytes_64;
                            Msg : in  Byte_Array;
                            Sig : out Signature_Bytes)
     with Global => null,
          Pre  => Msg'First = 0 and then
                  Msg'Length <= Max_Message_Length;

   --  Verify a detached signature.  Valid is True iff the signature is
   --  valid for (Pub, Msg).
   procedure Verify_Detached (Pub   : in  Bytes_32;
                              Msg   : in  Byte_Array;
                              Sig   : in  Signature_Bytes;
                              Valid : out Boolean)
     with Global => null,
          Pre  => Msg'First = 0 and then
                  Msg'Length <= Max_Message_Length;

end Kms_Signer;