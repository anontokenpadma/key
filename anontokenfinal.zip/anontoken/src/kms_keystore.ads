------------------------------------------------------------------------------
--  Kms_Keystore : bounded, pure data structure holding Ed25519 key pairs.
--  All operations are SPARK with Global => null.
--
--  Lifecycle of a slot (licensing model):
--    * Insert  : key is created by a developer account (Owner) with a
--                chosen Ttl_Secs, an activation Secret (shown once) and
--                Activated_At = 0 / Expires_At = 0 - it never dies until
--                the first successful phone-home check activates it.
--    * Activate: first /check with the right secret sets Activated_At and
--                Expires_At = Activated_At + Ttl_Secs.
--    * Expire  : only *activated* keys past their deadline are purged;
--                unactivated keys stay forever (until revoked).
--    * Revoke  : kills the key.  An unactivated key is freed outright
--                (nothing was ever used); an activated key is marked
--                Revoked and purged at its deadline (audit trail).
------------------------------------------------------------------------------

with Interfaces;
use  Interfaces;
with Kms_Types;
use  Kms_Types;

package Kms_Keystore
  with SPARK_Mode => On
is

   --  Clear every slot.  In out (not out) so the loop-body reads inside
   --  the loop invariant are reads of already-initialized memory - flow
   --  analysis then proves every check without a whole-array aggregate
   --  (which would need a multi-MB stack temporary at run time).
   procedure Init (KS : in out Keystore)
     with Global => null,
          Post   => Count (KS) = 0 and then
                    (for all I in Key_Index => not KS (I).In_Use);

   --  Number of in-use slots.
   function Count (KS : Keystore) return N32
     with Global => null,
          Post => Count'Result <= Max_Keys and then
                  (if (for all I in Key_Index => not KS (I).In_Use)
                   then Count'Result = 0);

   --  True when the keystore is not full.
   function Has_Free (KS : Keystore) return Boolean
     with Global => null;

   --  Insert a copy of Rec into the first free slot.  Created is False when
   --  the keystore is full (in which case KS is unchanged).
   procedure Insert (KS      : in out Keystore;
                     Rec     : in     Key_Record;
                     Created : out    Boolean)
     with Global => null,
          Pre  => Rec.In_Use,
          Post => (if Created then
                     (for some I in Key_Index =>
                        KS (I).In_Use and then KS (I) = Rec)
                   else
                     KS = KS'Old);

   --  Locate the slot holding Id.
   procedure Find (KS    : in     Keystore;
                   Id    : in     Key_Id;
                   Found : out    Boolean;
                   Idx   : out    Key_Index)
     with Global => null,
          Post => (if Found then
                     KS (Idx).In_Use and then KS (Idx).Id = Id);

   --  Copy the record at Idx out.
   procedure Get (KS  : in     Keystore;
                  Idx : in     Key_Index;
                  Rec : out    Key_Record)
     with Global => null,
          Pre  => KS (Idx).In_Use,
          Post => Rec = KS (Idx);

   --  True iff the slot at Idx belongs to the account named Name.
   function Owned (KS       : in Keystore;
                   Idx      : in Key_Index;
                   Name     : in User_Name_Buffer;
                   Name_Len : in N32) return Boolean
     with Global => null,
          Pre  => KS (Idx).In_Use and then
                  Name_Len >= 1 and then Name_Len <= User_Name_Length,
          Post => Owned'Result =
                    (KS (Idx).Owner_Len = Name_Len and then
                     (for all I in 0 .. Name_Len - 1 =>
                        KS (Idx).Owner (I) = Name (I)));

   --  Activate the key at Idx: the TTL starts counting now.
   procedure Activate (KS  : in out Keystore;
                       Idx : in     Key_Index;
                       Now : in     I64)
     with Global => null,
          Pre  => KS (Idx).In_Use and then
                  KS (Idx).Activated_At = 0 and then
                  KS (Idx).Ttl_Secs >= 0 and then
                  Now >= 0 and then Now <= 2 ** 62 and then
                  KS (Idx).Ttl_Secs <= 2 ** 62 - Now,
          Post => KS (Idx).Activated_At = Now and then
                  KS (Idx).Expires_At = Now + KS'Old (Idx).Ttl_Secs and then
                  (for all I in Key_Index =>
                     (if I /= Idx then KS (I) = KS'Old (I)));

   --  Remove every in-use, *activated* key whose deadline has passed
   --  (Expires_At < Now): its slot is freed and its secret material is
   --  zeroised.  Unactivated keys are untouched.  Freed is set True iff at
   --  least one slot was released.
   procedure Expire (KS    : in out Keystore;
                     Now   : in     I64;
                     Freed : out    Boolean)
     with Global => null,
          Post => (for all I in Key_Index =>
                     (not KS (I).In_Use or else
                      KS (I).Activated_At = 0 or else
                      KS (I).Expires_At >= Now));

   --  Revoke the key at Idx: its secrets are zeroised.  An unactivated key
   --  is freed outright (slot released); an activated key is marked
   --  Revoked and stays until its deadline (audit).
   procedure Revoke (KS  : in out Keystore;
                     Idx : in     Key_Index)
     with Global => null,
          Pre  => KS (Idx).In_Use,
          Post => (if KS'Old (Idx).Activated_At = 0 then
                     not KS (Idx).In_Use
                   else
                     KS (Idx).In_Use and then
                     KS (Idx).Status = Revoked and then
                     (for all B in Bytes_64'Range =>
                        KS (Idx).Sec (B) = 0));

end Kms_Keystore;
