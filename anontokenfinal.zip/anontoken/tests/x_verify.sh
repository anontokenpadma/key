#!/usr/bin/env bash
set -u
cd "$(dirname "$0")/.."
pkill -f "bin/main" 2>/dev/null
sleep 0.3
rm -f /tmp/ks-x.bin
setsid bash -c "./bin/main 127.0.0.1 9998 /tmp/ks-x.bin 90 > /tmp/ks-x.log 2>&1" < /dev/null > /dev/null 2>&1 &
sleep 1.2
python3 tests/x_verify.py
rc=$?
pkill -f "bin/main" 2>/dev/null
exit $rc
