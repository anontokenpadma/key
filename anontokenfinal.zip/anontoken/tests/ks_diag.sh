#!/bin/bash
# Diagnostic: check keystore load with TTL build
echo "=== KS DIAG ==="
ls -la /var/lib/anontoken/keystore.bin
echo "--- copy ---"
cp -f /var/lib/anontoken/keystore.bin /tmp/ks3.bin
stat -c 'copy size=%s' /tmp/ks3.bin
echo "--- run server on 9997 with copy ---"
/opt/anontoken/anontoken 127.0.0.1 9997 /tmp/ks3.bin 90 > /tmp/ks3.log 2>&1 &
SPID=$!
sleep 2
echo "--- log ---"
cat /tmp/ks3.log
echo "--- health ---"
curl -s http://127.0.0.1:9997/health
echo
echo "--- killing $SPID ---"
kill $SPID 2>/dev/null
echo "=== KS DIAG END ==="