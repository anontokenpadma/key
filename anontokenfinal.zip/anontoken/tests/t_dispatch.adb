with Ada.Text_IO;
with Interfaces;
use  Interfaces;
with Ada.Strings.Unbounded;
with Kms_Http;
with Kms_Keystore;
with Kms_Types;

procedure T_Dispatch is
   use Ada.Text_IO;
   use Kms_Types;
   use Kms_Http;

   Buf   : Request_Buffer := (others => 0);
   Req   : Request;
   Res   : Parse_Result;
   Resp  : Response_Buffer := (others => 0);
   Resp_Len : N32 := 0;
   Changed : Boolean := False;
   KS    : Keystore := (others => (In_Use => False, others => <>));
   Seed  : Seed_Bytes := (1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                          11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
                          21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
                          31, 32);
   Secret_Seed : Seed_Bytes := (others => 7);

   procedure Send (Raw : String; Expected : Boolean) is
      L : constant N32 := N32 (Raw'Length);
   begin
      Buf := (others => 0);
      for I in 1 .. L loop
         Buf (I - 1) := Byte (Character'Pos (Raw (Positive (I))));
      end loop;
      Kms_Http.Parse (Buf, L, Req, Res);
      New_Line;
      Put_Line ("--- request: " & Raw (1 .. Raw'Length));
      Put_Line ("parse=" & Parse_Result'Image (Res) &
                " kind=" & Request_Kind'Image (Req.Kind) &
                " err=" & Parse_Error'Image (Req.Error));
      Resp := (others => 0);
      Resp_Len := 0;
      Changed := False;
      Kms_Http.Dispatch (KS, 1_700_000_000, Seed, Secret_Seed, 90,
                         Req, Resp, Resp_Len, Changed);
      Put_Line ("changed=" & Boolean'Image (Changed));
      for I in 0 .. Resp_Len - 1 loop
         Put (Character'Val (Resp (I)));
      end loop;
      New_Line;
   end Send;

begin
   Kms_Keystore.Init (KS);

   Send ("GET /health HTTP/1.1" & ASCII.CR & ASCII.LF &
         "Host: l" & ASCII.CR & ASCII.LF &
         "Connection: close" & ASCII.CR & ASCII.LF & ASCII.CR & ASCII.LF,
         True);

   Send ("POST /keys HTTP/1.1" & ASCII.CR & ASCII.LF &
         "Host: l" & ASCII.CR & ASCII.LF &
         "Content-Length: 0" & ASCII.CR & ASCII.LF &
         "Connection: close" & ASCII.CR & ASCII.LF & ASCII.CR & ASCII.LF,
         True);

   Send ("POST /keys/b9d80dccf3984a9e/sign HTTP/1.1" & ASCII.CR & ASCII.LF &
         "Host: l" & ASCII.CR & ASCII.LF &
         "Content-Length: 20" & ASCII.CR & ASCII.LF &
         "Connection: close" & ASCII.CR & ASCII.LF & ASCII.CR & ASCII.LF &
         "{""message"":""aGVsbG8=""}",
         True);

   Send ("POST /keys/b9d80dccf3984a9e/verify HTTP/1.1" & ASCII.CR & ASCII.LF &
         "Host: l" & ASCII.CR & ASCII.LF &
         "Content-Length: 130" & ASCII.CR & ASCII.LF &
         "Connection: close" & ASCII.CR & ASCII.LF & ASCII.CR & ASCII.LF &
         "{""message"":""aGVsbG8="",""signature"":""xxxxxxxxxxxxx""}",
         True);
end T_Dispatch;