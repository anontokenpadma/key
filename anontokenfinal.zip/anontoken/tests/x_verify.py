#!/usr/bin/env python3
"""Cross-check: sign via the Ada server over HTTP, then verify the
signature with Python's OpenSSL-backed Ed25519 implementation."""
import base64
import json
import subprocess
import sys
import time
import urllib.request

PORT = 9998
BASE = f"http://127.0.0.1:{PORT}"


def req(method, path, body=None):
    data = body.encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method)
    with urllib.request.urlopen(r, timeout=5) as resp:
        return resp.status, resp.read()


# create a key
st, raw = req("POST", "/keys")
print("create:", raw.decode())
key = json.loads(raw)
kid, pub_b64 = key["key_id"], key["public_key"]

# sign "hello"
st, raw = req("POST", f"/keys/{kid}/sign", body='{"message":"aGVsbG8="}')
sig_b64 = json.loads(raw)["signature"]

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

pub = base64.b64decode(pub_b64)
sig = base64.b64decode(sig_b64)
pk = Ed25519PublicKey.from_public_bytes(pub)
pk.verify(sig, b"hello")
print("PYTHON/OPENSSL VERIFY OF HTTP SIGNATURE: OK")

# negative: wrong message must fail
try:
    pk.verify(sig, b"hell")
    print("wrong-message: ACCEPTED (BAD)")
    sys.exit(1)
except Exception:
    print("wrong-message: rejected (good)")
