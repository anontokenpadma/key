#!/bin/bash
# TTL tests: lifetime_seconds, lifetime_minutes, expiry behavior
H=http://127.0.0.1:9999
echo "=== TTL TEST ==="
echo "--- default (no TTL) ---"
curl -s -X POST $H/keys | head -c 200
echo
echo "--- lifetime_minutes=1 ---"
curl -s -X POST -d '{"lifetime_minutes":1}' $H/keys | head -c 200
echo
echo "--- lifetime_seconds=2 ---"
K=$(curl -s -X POST -d '{"lifetime_seconds":2}' $H/keys)
echo "$K"
KID=$(echo "$K" | sed -n 's/.*"key_id":"\([^"]*\)".*/\1/p')
echo "key_id=$KID"
echo "--- keys list (all 3 new) ---"
curl -s $H/keys | head -c 400
echo
echo "--- wait 4s then check expired ---"
sleep 4
curl -s $H/keys | python3 -c "import sys,json; d=json.load(sys.stdin); [print(k['key_id'],k['status']) for k in d['keys']]"
echo "--- try sign on expired key (should fail) ---"
M=$(printf 'hi' | base64)
curl -s -X POST -d "{\"message\":\"$M\"}" $H/keys/$KID/sign
echo
echo "--- health ---"
curl -s $H/health
echo
echo "=== TTL TEST END ==="