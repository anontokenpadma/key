#!/usr/bin/env bash
# Port/env configuration tests for anontoken main.adb.
cd "$(dirname "$0")/.."
BIN=./bin/main

pkill -9 -f "bin/[m]ain 127" 2>/dev/null
pkill -9 -f "bin/main 127" 2>/dev/null
sleep 0.5

FAIL=0
check() { # check <name> <expected_substring> <file>
  if grep -q "$2" "$3"; then echo "PASS  $1"; else echo "FAIL  $1 (missing: $2 in $3)"; FAIL=1; fi
}

# T1: default (no env, no args beyond path) -> 9999
rm -f /tmp/kst1.bin /tmp/t1.log
setsid bash -c "$BIN 127.0.0.1 9999 /tmp/kst1.bin 90 > /tmp/t1.log 2>&1" < /dev/null &
sleep 1
R=$(curl -s -m 3 http://127.0.0.1:9999/health)
echo "T1 default 9999 -> $R"
echo "$R" | grep -q "status.*ok" && echo "PASS  T1 default port 9999" || { echo "FAIL  T1"; FAIL=1; }

# T2: env ANONTONKEN_PORT=8123 (no CLI port given)
rm -f /tmp/t2.log
ANONTONKEN_PORT=8123 ANONTONKEN_KEYSTORE=/tmp/kst2.bin setsid bash -c "$BIN > /tmp/t2.log 2>&1" < /dev/null &
sleep 1
R=$(curl -s -m 3 http://127.0.0.1:8123/health)
echo "T2 env port 8123 -> $R"
echo "$R" | grep -q "status.*ok" && echo "PASS  T2 env ANONTONKEN_PORT=8123" || { echo "FAIL  T2"; FAIL=1; }
grep -q "8123" /tmp/t2.log && echo "PASS  T2 log shows 8123" || { echo "FAIL  T2 log"; FAIL=1; }

# T3: env 8123 but CLI port 8124 -> CLI wins
rm -f /tmp/t3.log
ANONTONKEN_PORT=8123 setsid bash -c "$BIN 127.0.0.1 8124 /tmp/kst3.bin 90 > /tmp/t3.log 2>&1" < /dev/null &
sleep 1
R=$(curl -s -m 3 http://127.0.0.1:8124/health)
echo "T3 cli override 8124 -> $R"
echo "$R" | grep -q "status.*ok" && echo "PASS  T3 CLI arg overrides env" || { echo "FAIL  T3"; FAIL=1; }
grep -q "8124" /tmp/t3.log && echo "PASS  T3 log shows 8124" || { echo "FAIL  T3 log"; FAIL=1; }

# T4: env keystore + lifetime + port, no CLI args
rm -f /tmp/kst4.bin /tmp/t4.log
ANONTONKEN_PORT=9998 ANONTONKEN_KEYSTORE=/tmp/kst4.bin ANONTONKEN_LIFETIME_DAYS=5 \
  setsid bash -c "$BIN > /tmp/t4.log 2>&1" < /dev/null &
sleep 1
R=$(curl -s -m 3 http://127.0.0.1:9998/health)
echo "T4 env keystore+lifetime -> $R"
echo "$R" | grep -q "status.*ok" && echo "PASS  T4 env port 9998" || { echo "FAIL  T4"; FAIL=1; }
grep -q "/tmp/kst4.bin" /tmp/t4.log && echo "PASS  T4 keystore from env" || { echo "FAIL  T4 keystore (log: $(cat /tmp/t4.log))"; FAIL=1; }
grep -q "lifetime= 5d" /tmp/t4.log && echo "PASS  T4 lifetime from env" || { echo "FAIL  T4 lifetime (log: $(cat /tmp/t4.log))"; FAIL=1; }

# T5: bad env port -> clean error, no listen
rm -f /tmp/t5.log
ANONTONKEN_PORT=99999 "$BIN" 127.0.0.1 9999 /tmp/x.bin 90 > /tmp/t5.log 2>&1
E=$?
echo "T5 bad env port 99999 -> exit=$E : $(cat /tmp/t5.log)"
[ "$E" = "0" ] && grep -q "bad ANONTONKEN_PORT" /tmp/t5.log && echo "PASS  T5 bad env port rejected" || { echo "FAIL  T5"; FAIL=1; }

# T6: bad CLI port -> clean error
ANONTONKEN_PORT=8123 "$BIN" 127.0.0.1 70000 /tmp/x.bin 90 > /tmp/t6.log 2>&1
E=$?
echo "T6 bad cli port 70000 -> exit=$E : $(cat /tmp/t6.log)"
[ "$E" = "0" ] && grep -q "bad port" /tmp/t6.log && echo "PASS  T6 bad CLI port rejected" || { echo "FAIL  T6"; FAIL=1; }

pkill -9 -f "bin/[m]ain 127" 2>/dev/null
pkill -9 -f "bin/main 127" 2>/dev/null
echo "RESULT: $([ $FAIL = 0 ] && echo ALL_PASS || echo HAS_FAILURES)"