#!/usr/bin/env bash
# Expiry-purge behaviour (v0.2.0 lazy activation):
#   - an UNACTIVATED key never expires, no matter its TTL
#   - once ACTIVATED by its first /check, the TTL counts from that moment
#   - an activated key past its deadline vanishes (slot freed, 404)
#   - an activated revoked key stays (403) until its deadline
#   - revoking an unactivated key frees the slot outright
cd "$(dirname "$0")/.."
BIN=./bin/main
P=9996
H=http://127.0.0.1:$P
KS=/tmp/kse_purge.bin
LOG=/tmp/kse_purge.log
US=/tmp/kse_purge_users.bin
A="-u testuser:TestPass123"

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
pkill -9 -f "bin/main 127" 2>/dev/null
sleep 0.5
rm -f "$KS" "$LOG" "$US"
./bin/admin -f "$US" add testuser TestPass123 >/dev/null 2>&1 || true

setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1

FAIL=0
chk() { if [ "$2" = "$3" ]; then echo "PASS  $1"; else echo "FAIL  $1 (got [$2] want [$3])"; FAIL=1; fi; }
mkk() { # mkk <name> <ttl> ; echoes "KID:SEC"
  local r
  r=$(curl -s $A -X POST -d "{\"lifetime_seconds\":$2}" $H/keys)
  echo "$(echo "$r" | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])'):$(echo "$r" | python3 -c 'import sys,json;print(json.load(sys.stdin)["activation_secret"])')"
}
act() { curl -s -X POST -d "{\"secret\":\"$2\"}" $H/keys/$1/check > /dev/null; }

K1S=$(mkk K1 60);    K1=${K1S%%:*}; S1=${K1S##*:}
K2S=$(mkk K2 1);     K2=${K2S%%:*}; S2=${K2S##*:}
echo "created K1=$K1 (60s, not activated) K2=$K2 (1s, not activated)"
chk "health keys=2" "$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')" "2"

# an unactivated key with a 1s TTL must NOT expire (lazy semantics)
sleep 2
chk "unactivated K2 still alive after 2s" "$(curl -s $A -o /dev/null -w '%{http_code}' $H/keys/$K2/pub)" "200"
chk "unactivated K2 still listed" "$(curl -s $A $H/keys | python3 -c "import sys,json; ks=[k['key_id'] for k in json.load(sys.stdin)['keys']]; print('$K2' in ks)")" "True"

# now activate K2 (1s TTL counts from activation), then it must die quickly
act "$K2" "$S2"
echo "activated K2"
sleep 3
chk "activated K2 gone from list" "$(curl -s $A $H/keys | python3 -c "import sys,json; ks=[k['key_id'] for k in json.load(sys.stdin)['keys']]; print('$K2' in ks)")" "False"
chk "health keys drops to 1" "$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')" "1"
chk "sign expired -> 404" "$(curl -s $A -o /dev/null -w '%{http_code}' -X POST -d '{\"message\":\"aGVsbG8=\"}' $H/keys/$K2/sign)" "404"
chk "pub expired -> 404" "$(curl -s $A -o /dev/null -w '%{http_code}' $H/keys/$K2/pub)" "404"
chk "check expired -> 404" "$(curl -s -o /dev/null -w '%{http_code}' -X POST -d "{\"secret\":\"$S2\"}" $H/keys/$K2/check)" "404"

# slot reuse: create again, count stays 2 (was 1)
K3S=$(mkk K3 60); K3=${K3S%%:*}
chk "new key after expiry (slot reuse)" "$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')" "2"

# activate K1 then revoke: 403 for sign, key stays listed as revoked
act "$K1" "$S1"
curl -s $A -X DELETE $H/keys/$K1 > /dev/null
chk "sign revoked (activated) -> 403" "$(curl -s $A -o /dev/null -w '%{http_code}' -X POST -d '{\"message\":\"aGVsbG8=\"}' $H/keys/$K1/sign)" "403"
chk "check revoked -> 403" "$(curl -s -o /dev/null -w '%{http_code}' -X POST -d "{\"secret\":\"$S1\"}" $H/keys/$K1/check)" "403"
chk "revoked still listed" "$(curl -s $A $H/keys | python3 -c "import sys,json; ks=[k['status'] for k in json.load(sys.stdin)['keys'] if k['key_id']=='$K1']; print(ks[0] if ks else 'missing')")" "revoked"

# revoking an unactivated key frees it outright (no audit trail needed)
K4S=$(mkk K4 60); K4=${K4S%%:*}
curl -s $A -X DELETE $H/keys/$K4 > /dev/null
chk "revoked-unactivated gone from list" "$(curl -s $A $H/keys | python3 -c "import sys,json; ks=[k['key_id'] for k in json.load(sys.stdin)['keys']]; print('$K4' in ks)")" "False"

# restart: expired stayed gone, persisted state intact
pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
sleep 0.5
setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1
chk "after restart K2 still absent" "$(curl -s $A $H/keys | python3 -c "import sys,json; ks=[k['key_id'] for k in json.load(sys.stdin)['keys']]; print('$K2' in ks)")" "False"
chk "after restart keys=2 (K1 revoked + K3)" "$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')" "2"

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
echo "RESULT: $([ $FAIL = 0 ] && echo ALL_PASS || echo HAS_FAILURES)"
