with Ada.Text_IO;
with Interfaces;
use  Interfaces;
with Kms_Signer;
with Kms_Types;

procedure T_Vectors is
   use Ada.Text_IO;
   use Kms_Types;

   Failures : Natural := 0;

   procedure Check (Name : String; Cond : Boolean) is
   begin
      if Cond then
         Put_Line ("PASS: " & Name);
      else
         Put_Line ("FAIL: " & Name);
         Failures := Failures + 1;
      end if;
   end Check;

   function Hex (B : Byte) return String is
      Hi : constant Natural := Natural (B) / 16;
      Lo : constant Natural := Natural (B) mod 16;
      function D (V : Natural) return Character is
      begin
         if V < 10 then
            return Character'Val (Character'Pos ('0') + V);
         else
            return Character'Val (Character'Pos ('a') + V - 10);
         end if;
      end D;
   begin
      return D (Hi) & D (Lo);
   end Hex;

   function To_String (Arr : Byte_Array) return String is
      R : String (1 .. Arr'Length * 2);
   begin
      for I in Arr'Range loop
         R (Natural (I - Arr'First) * 2 + 1 ..
           Natural (I - Arr'First) * 2 + 2) := Hex (Arr (I));
      end loop;
      return R;
   end To_String;

   --  RFC 8032 TEST 1: empty message
   Seed_1 : constant Seed_Bytes :=
     (16#9D#, 16#61#, 16#B1#, 16#9D#, 16#EF#, 16#FD#, 16#5A#, 16#60#,
      16#BA#, 16#84#, 16#4A#, 16#F4#, 16#92#, 16#EC#, 16#2C#, 16#C4#,
      16#44#, 16#49#, 16#C5#, 16#69#, 16#7B#, 16#32#, 16#69#, 16#19#,
      16#70#, 16#3B#, 16#AC#, 16#03#, 16#1C#, 16#AE#, 16#7F#, 16#60#);
   Pub_1  : constant String :=
     "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a";
   Sig_1  : constant String :=
     "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e06522490155" &
     "5fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b";

   --  RFC 8032 TEST 3: seed c5aa8df4..., message af82 (2 bytes)
   Seed_3 : constant Seed_Bytes :=
     (16#C5#, 16#AA#, 16#8D#, 16#F4#, 16#3F#, 16#9F#, 16#83#, 16#7B#,
      16#ED#, 16#B7#, 16#44#, 16#2F#, 16#31#, 16#DC#, 16#B7#, 16#B1#,
      16#66#, 16#D3#, 16#85#, 16#35#, 16#07#, 16#6F#, 16#09#, 16#4B#,
      16#85#, 16#CE#, 16#3A#, 16#2E#, 16#0B#, 16#44#, 16#58#, 16#F7#);
   Pub_3  : constant String :=
     "fc51cd8e6218a1a38da47ed00230f0580816ed13ba3303ac5deb911548908025";
   Msg_3  : constant Byte_Array (0 .. 1) :=
     (16#AF#, 16#82#);
   Sig_3  : constant String :=
     "6291d657deec24024827e69c3abe01a30ce548a284743a445e3680d7db5ac3ac" &
     "18ff9b538d16f290ae67f760984dc6594a7c15e9716ed28dc027beceea1ec40a";

   Pub  : Bytes_32 := (others => 0);
   Sec  : Bytes_64 := (others => 0);
   Sig  : Signature_Bytes := (others => 0);
   Sig2 : Signature_Bytes := (others => 0);
   V    : Boolean;

begin
   --  TEST 1
   Kms_Signer.Generate (Seed_1, Pub, Sec);
   Check ("test1 public key", To_String (Pub) = Pub_1);
   Kms_Signer.Sign_Detached (Sec, Msg_3 (0 .. -1), Sig);
   Check ("test1 empty-message signature", To_String (Sig) = Sig_1);
   Kms_Signer.Verify_Detached (Pub, Msg_3 (0 .. -1), Sig, V);
   Check ("test1 verify(empty) = true", V);

   --  tampered signature must not verify
   Sig2 := Sig;
   Sig2 (0) := Sig2 (0) xor 16#01#;
   Kms_Signer.Verify_Detached (Pub, Msg_3 (0 .. -1), Sig2, V);
   Check ("test1 tampered sig rejected", not V);

   --  TEST 3
   Kms_Signer.Generate (Seed_3, Pub, Sec);
   Check ("test3 public key", To_String (Pub) = Pub_3);
   Kms_Signer.Sign_Detached (Sec, Msg_3, Sig);
   Check ("test3 af82 signature", To_String (Sig) = Sig_3);
   Kms_Signer.Verify_Detached (Pub, Msg_3, Sig, V);
   Check ("test3 verify(af82) = true", V);

   --  wrong message must not verify
   Kms_Signer.Verify_Detached (Pub, Msg_3 (0 .. 0), Sig, V);
   Check ("test3 wrong message rejected", not V);

   --  5-byte message roundtrip with a fresh key (like the HTTP flow)
   declare
      Seed_H : constant Seed_Bytes :=
        (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
         17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32);
      Hello  : constant Byte_Array (0 .. 4) :=
        (Character'Pos ('h'), Character'Pos ('e'), Character'Pos ('l'),
         Character'Pos ('l'), Character'Pos ('o'));
      P_H : Bytes_32 := (others => 0);
      S_H : Bytes_64 := (others => 0);
      G_H : Signature_Bytes := (others => 0);
      V_H : Boolean;
   begin
      Kms_Signer.Generate (Seed_H, P_H, S_H);
      Kms_Signer.Sign_Detached (S_H, Hello, G_H);
      Put_Line ("hello sig (hex): " & To_String (G_H));
      Put_Line ("hello pub (hex): " & To_String (P_H));
      Kms_Signer.Verify_Detached (P_H, Hello, G_H, V_H);
      Check ("5-byte hello roundtrip verify", V_H);
      Kms_Signer.Verify_Detached (P_H, Hello (0 .. 3), G_H, V_H);
      Check ("5-byte wrong message rejected", not V_H);
   end;

   if Failures = 0 then
      Put_Line ("ALL VECTOR TESTS PASSED");
   else
      Put_Line (Natural'Image (Failures) & " FAILURE(S)");
   end if;
end T_Vectors;