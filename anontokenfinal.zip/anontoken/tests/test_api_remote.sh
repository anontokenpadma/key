#!/bin/bash
K=$(curl -s -X POST http://127.0.0.1:9999/keys | python3 -c "import sys,json;print(json.load(sys.stdin)['key_id'])")
echo "key=$K"
M=$(printf hello | base64)
BODY_SIGN=$(printf '{"message":"%s"}' "$M")
echo "--- sign ---"
R1=$(curl -s -X POST -d "$BODY_SIGN" http://127.0.0.1:9999/keys/$K/sign)
echo "$R1"
S=$(echo "$R1" | python3 -c "import sys,json;print(json.load(sys.stdin)['signature'])")
echo "--- verify good ---"
BODY_VERIFY=$(printf '{"message":"%s","signature":"%s"}' "$M" "$S")
curl -s -X POST -d "$BODY_VERIFY" http://127.0.0.1:9999/keys/$K/verify; echo
echo "--- verify bad ---"
BODY_BAD=$(printf '{"message":"%s","signature":"%s"}' "$M" "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==")
curl -s -X POST -d "$BODY_BAD" http://127.0.0.1:9999/keys/$K/verify; echo
echo "--- pub ---"
curl -s http://127.0.0.1:9999/keys/$K/pub; echo
echo "--- revoke ---"
curl -s -X DELETE http://127.0.0.1:9999/keys/$K; echo
echo "--- sign after revoke ---"
curl -s -o /dev/null -w "%{http_code}" -X POST -d "$BODY_SIGN" http://127.0.0.1:9999/keys/$K/sign; echo
echo "--- health ---"
curl -s http://127.0.0.1:9999/health; echo
