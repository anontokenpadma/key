#!/bin/bash
cd "$(dirname "$0")/.."
BIN=./bin/main
PORT=9994
rm -f /tmp/ksl.bin /tmp/ksl1.log /tmp/ksl2.log
"$BIN" 127.0.0.1 $PORT /tmp/ksl.bin 90 > /tmp/ksl1.log 2>&1 &
P1=$!
sleep 1.5
echo "--- create ---"
curl -s -X POST http://127.0.0.1:$PORT/keys
echo
sleep 0.5
kill $P1
wait $P1 2>/dev/null
echo "--- file ---"
ls -la /tmp/ksl.bin
"$BIN" 127.0.0.1 $PORT /tmp/ksl.bin 90 > /tmp/ksl2.log 2>&1 &
P2=$!
sleep 1.5
echo "--- reload log ---"
cat /tmp/ksl2.log
echo "--- health after reload ---"
curl -s http://127.0.0.1:$PORT/health
echo
kill $P2
wait $P2 2>/dev/null
echo DONE