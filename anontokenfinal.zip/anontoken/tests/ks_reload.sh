#!/bin/bash
# Fresh save -> reload cycle with the TTL build
echo "=== RELOAD TEST ==="
rm -f /tmp/ks4.bin
/opt/anontoken/anontoken 127.0.0.1 9996 /tmp/ks4.bin 90 > /tmp/ks4a.log 2>&1 &
P1=$!
sleep 2
echo "--- start 1 (empty) ---"
cat /tmp/ks4a.log
echo "--- create key ---"
curl -s -X POST http://127.0.0.1:9996/keys
echo
sleep 1
kill $P1 2>/dev/null
wait $P1 2>/dev/null
echo "--- file after save ---"
ls -la /tmp/ks4.bin 2>&1
/opt/anontoken/anontoken 127.0.0.1 9996 /tmp/ks4.bin 90 > /tmp/ks4b.log 2>&1 &
P2=$!
sleep 2
echo "--- start 2 (reload) ---"
cat /tmp/ks4b.log
echo "--- health ---"
curl -s http://127.0.0.1:9996/health
echo
kill $P2 2>/dev/null
echo "=== RELOAD TEST END ==="