#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
BIN=$(find ~/.local/share/alire/toolchains -maxdepth 2 -type d -name bin | tr '\n' ':')
export PATH="$BIN$PATH"
gprbuild -q -P anontoken.gpr 2>&1 | grep -E "error" | head -5 || true
pkill -f "bin/main" 2>/dev/null || true
sleep 0.3
setsid bash -c './bin/main 127.0.0.1 9999 /tmp/anontoken-ks.bin 90 > /tmp/anontoken.log 2>&1' < /dev/null &
sleep 1
python3 tests/debug_probe.py || true
sleep 0.3
echo "=== server log ==="
tail -30 /tmp/anontoken.log
pkill -f "bin/main" 2>/dev/null || true