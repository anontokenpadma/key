#!/usr/bin/env bash
# Local smoke test for the anontoken server.
set -u

cd "$(dirname "$0")/.."
BIN=./bin/main
PORT="${PORT:-9999}"
KS=/tmp/anontoken-ks.bin
LOG=/tmp/anontoken.log
US=/tmp/anontoken-users.bin
U=testuser; P=TestPass123
A="-u $U:$P"

pkill -f "bin/main" 2>/dev/null
sleep 0.3
rm -f "$KS" "$US"
./bin/admin -f "$US" add "$U" "$P" >/dev/null 2>&1 || true

setsid bash -c "$BIN 127.0.0.1 $PORT $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1.0

echo "== health =="
curl -s --max-time 3 $A http://127.0.0.1:$PORT/health
echo

echo "== create key 1 =="
R1=$(curl -s --max-time 3 $A -X POST http://127.0.0.1:$PORT/keys)
echo "$R1"
KID=$(echo "$R1" | python3 -c "import sys,json; print(json.load(sys.stdin)['key_id'])")

echo "== create key 2 =="
curl -s --max-time 3 $A -X POST http://127.0.0.1:$PORT/keys
echo

echo "== list =="
curl -s --max-time 3 $A http://127.0.0.1:$PORT/keys
echo

echo "== public key =="
PUB=$(curl -s --max-time 3 $A http://127.0.0.1:$PORT/keys/$KID/pub)
echo "$PUB"

echo "== sign hello =="
SIGN=$(curl -s --max-time 3 $A -X POST -d '{"message":"aGVsbG8="}' http://127.0.0.1:$PORT/keys/$KID/sign)
echo "$SIGN"
SIG=$(echo "$SIGN" | python3 -c "import sys,json; print(json.load(sys.stdin)['signature'])")

echo "== verify good =="
curl -s --max-time 3 $A -X POST -d "{\"message\":\"aGVsbG8=\",\"signature\":\"$SIG\"}" http://127.0.0.1:$PORT/keys/$KID/verify
echo

echo "== verify bad (tampered sig) =="
SIGBAD="${SIG%?}A"
curl -s --max-time 3 $A -X POST -d "{\"message\":\"aGVsbG8=\",\"signature\":\"$SIGBAD\"}" http://127.0.0.1:$PORT/keys/$KID/verify
echo

echo "== 404 unknown key =="
curl -s --max-time 3 $A -o /dev/null -w "%{http_code}\n" http://127.0.0.1:$PORT/keys/ffffffffffffffff/pub

echo "== 405 wrong method =="
curl -s --max-time 3 $A -o /dev/null -w "%{http_code}\n" -X DELETE http://127.0.0.1:$PORT/keys

echo "== 400 bad json =="
curl -s --max-time 3 $A -o /dev/null -w "%{http_code}\n" -X POST -d 'garbage' http://127.0.0.1:$PORT/keys/$KID/sign

echo "== activate key 1 (phone-home with its secret) =="
SEC=$(echo "$R1" | python3 -c "import sys,json; print(json.load(sys.stdin)['activation_secret'])")
curl -s --max-time 3 -X POST -d "{\"secret\":\"$SEC\"}" http://127.0.0.1:$PORT/keys/$KID/check
echo

# add a second key and revoke it WITHOUT activating: the slot is freed
# outright, so later ops on it are 404
echo "== create key 3 (never activated) =="
R3=$(curl -s --max-time 3 $A -X POST http://127.0.0.1:$PORT/keys)
KID3=$(echo "$R3" | python3 -c "import sys,json; print(json.load(sys.stdin)['key_id'])")
curl -s --max-time 3 $A -X DELETE http://127.0.0.1:$PORT/keys/$KID3
echo "revoked-unactivated, subsequent sign -> 404"
curl -s --max-time 3 $A -o /dev/null -w "%{http_code}\n" -X POST -d '{"message":"aGVsbG8="}' http://127.0.0.1:$PORT/keys/$KID3/sign

echo "== revoke (activated) =="
curl -s --max-time 3 $A -X DELETE http://127.0.0.1:$PORT/keys/$KID
echo

echo "== sign after revoke (expect 403) =="
curl -s --max-time 3 $A -o /dev/null -w "%{http_code}\n" -X POST -d '{"message":"aGVsbG8="}' http://127.0.0.1:$PORT/keys/$KID/sign

echo "== server log errors (should be empty) =="
grep -c "connection error" "$LOG" || true

pkill -f "bin/main" 2>/dev/null
echo "== keystore file =="
ls -la "$KS"