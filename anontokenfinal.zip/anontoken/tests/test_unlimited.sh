#!/usr/bin/env bash
# Unlimited-keys verification (v0.2.0):
#  - more than 64 concurrent keys can be created (no hard cap at 64)
#  - keystore file grows dynamically (8 + n*195), not fixed 7816 bytes
#  - activated keys are purged automatically once past their deadline
#  - legacy v1 (fixed 64-slot) and v2 keystore files still load (migration)
cd "$(dirname "$0")/.."
BIN=./bin/main
P=9994
H=http://127.0.0.1:$P
KS=/tmp/kse_unl.bin
LOG=/tmp/kse_unl.log
US=/tmp/kse_unl_users.bin
A="-u testuser:TestPass123"

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
pkill -9 -f "bin/main 127" 2>/dev/null
sleep 0.5
rm -f "$KS" "$LOG" "$US"
./bin/admin -f "$US" add testuser TestPass123 >/dev/null 2>&1 || true

setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1

FAIL=0
chk() { if [ "$2" = "$3" ]; then echo "PASS  $1"; else echo "FAIL  $1 (got [$2] want [$3])"; FAIL=1; fi; }
mkk() { # create key with ttl seconds, echo "KID:SEC"
  local r
  r=$(curl -s $A -X POST -d "{\"lifetime_seconds\":$1}" $H/keys)
  echo "$(echo "$r" | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])'):$(echo "$r" | python3 -c 'import sys,json;print(json.load(sys.stdin)["activation_secret"])')"
}

# --- create 70 keys with 30s TTL: proves no 64 cap ---
N=70
SECS=""
for i in $(seq 1 $N); do
  SECS="$SECS $(mkk 30)"
done
C=$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')
chk "create $N keys (>64) -> count=$N" "$C" "$N"
LIST=$(curl -s $A $H/keys | python3 -c 'import sys,json;print(len(json.load(sys.stdin)["keys"]))')
chk "GET /keys lists all $N" "$LIST" "$N"

# --- dynamic file size: ~8 + 70*195 = 13658 bytes (not fixed 7816) ---
SZ=$(python3 -c "import os;print(os.path.getsize('$KS'))")
chk "dynamic file size ~13658 (got $SZ)" "$SZ" "13658"

# --- restart: v2/v3 reload keeps all 70 ---
pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
sleep 0.5
setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1
grep -q "keystore loaded" "$LOG" && echo "PASS  keystore reloaded" || { echo "FAIL  reload (log: $(cat $LOG))"; FAIL=1; }
C=$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')
chk "reload keeps $N keys" "$C" "$N"

# --- activate all 70 keys, then wait for expiry purge ---
for ks in $SECS; do
  curl -s -X POST -d "{\"secret\":\"${ks##*:}\"}" $H/keys/${ks%%:*}/check > /dev/null
done
sleep 32
C=$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')
chk "all activated keys purged -> 0" "$C" "0"
chk "file shrinks to 8 bytes" "$(python3 -c "import os;print(os.path.getsize('$KS'))")" "8"

# --- v1 migration: a legacy fixed-format file with 2 live keys must load ---
python3 - <<'PYEOF'
import struct, time
now = int(time.time())
def u64le(v):
    return struct.pack('<Q', v)
slots = b''
for i in range(2):
    s = bytearray(122)
    s[0] = 1                                    # in_use
    s[1:9] = u64le(0x1000 + i)                  # id
    s[9:41] = bytes(range(32))                  # pub (dummy)
    s[41:105] = bytes(range(64))                # sec (dummy)
    s[105:113] = u64le(now - 100)               # created
    s[113:121] = u64le(now + 3600)              # expires: 1h in the future
    s[121] = 0                                  # status: active
    slots += bytes(s)
open('/tmp/kse_v1.bin', 'wb').write(b'ANKT' + struct.pack('<I', 1) + slots + bytes(122 * 62))
print('v1 fixture written:', 8 + 122 * 64, 'bytes')
PYEOF
pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
sleep 0.5
setsid bash -c "$BIN 127.0.0.1 $P /tmp/kse_v1.bin 90 $US > $LOG 2>&1" < /dev/null &
sleep 1
grep -q "keystore loaded" "$LOG" && echo "PASS  v1 file migrated" || { echo "FAIL  v1 migration (log: $(cat $LOG))"; FAIL=1; }
C1=$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')
chk "v1 keys reloaded (count=$C1)" "$C1" "2"
# trigger save -> file becomes dynamic v3: size = 8 + n*195
curl -s $A -X POST -d '{"lifetime_seconds":300}' $H/keys > /dev/null
C2=$(curl -s $A $H/health | python3 -c 'import sys,json;print(json.load(sys.stdin)["keys"])')
EXP=$((8 + C2 * 195))
SZ2=$(python3 -c "import os;print(os.path.getsize('/tmp/kse_v1.bin'))")
chk "after save file dynamic v3 (size=$SZ2 expect~$EXP)" "$SZ2" "$EXP"

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
echo "RESULT: $([ $FAIL = 0 ] && echo ALL_PASS || echo HAS_FAILURES)"
