#!/usr/bin/env bash
# Auth verification:
#  - admin tool: add/remove/list/setpass + validation + password never on disk
#  - server: /health stays public; every other endpoint needs Basic auth
#  - wrong/missing/malformed credentials -> 401 (+ WWW-Authenticate)
#  - admin changes are picked up WITHOUT a server restart (file reload)
cd "$(dirname "$0")/.."
BIN=./bin/main
ADM=./bin/admin
P=9997
H=http://127.0.0.1:$P
KS=/tmp/ka_ks.bin
US=/tmp/ka_users.bin
LOG=/tmp/ka_server.log

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
pkill -9 -f "bin/main 127" 2>/dev/null
sleep 0.5
rm -f "$KS" "$US" "$LOG"

FAIL=0
chk() { if [ "$2" = "$3" ]; then echo "PASS  $1"; else echo "FAIL  $1 (got [$2] want [$3])"; FAIL=1; fi; }
code() { curl -s -o /dev/null -w "%{http_code}" "$@"; }

ALICE="alice"
APASS="AlicePass123"

# ---------- admin tool ----------
L=$("$ADM" -f "$US" list 2>&1 | tail -1)
chk "admin list (empty) -> ' 0 account(s)'" "$(echo $L)" "0 account(s) in $US"

"$ADM" -f "$US" add "$ALICE" "$APASS" >/dev/null 2>&1
chk "admin add alice -> rc=0" "$?" "0"

# duplicate detection: exit status must be 1
"$ADM" -f "$US" add "$ALICE" "$APASS" >/dev/null 2>&1
RC=$?
if [ "$RC" = "1" ]; then echo "PASS  admin add duplicate rejected (rc=1)"; else echo "FAIL  duplicate rc=$RC want 1"; FAIL=1; fi

L=$("$ADM" -f "$US" list 2>&1 | head -1)
chk "admin list has alice" "$L" "$ALICE"

# username / password validation
"$ADM" -f "$US" add "ab" "ValidPass123" >/dev/null 2>&1
chk "reject short username" "$?" "1"
"$ADM" -f "$US" add "bad@name" "ValidPass123" >/dev/null 2>&1
chk "reject bad charset" "$?" "1"
"$ADM" -f "$US" add "bobuser" "short" >/dev/null 2>&1
chk "reject short password" "$?" "1"

# password must NOT be stored in plaintext
if grep -q "$APASS" "$US" 2>/dev/null; then
  echo "FAIL  plaintext password found in users file"; FAIL=1
else
  echo "PASS  password not stored in plaintext"
fi

# ---------- server: no users file => deny all (except /health) ----------
setsid bash -c "$BIN 127.0.0.1 $P $KS 90 > $LOG 2>&1" < /dev/null &
sleep 1
chk "health public (no users file)" "$(code $H/health)" "200"
chk "GET /keys without auth -> 401" "$(code $H/keys)" "401"
if curl -s -D - -o /dev/null $H/keys | grep -qi "www-authenticate"; then
  echo "PASS  401 carries WWW-Authenticate header"
else
  echo "FAIL  401 missing WWW-Authenticate"; FAIL=1
fi
pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
sleep 0.5

# ---------- server: with users file ----------
setsid bash -c "$BIN 127.0.0.1 $P $KS 90 $US > $LOG 2>&1" < /dev/null &
sleep 1
grep -q "users loaded" "$LOG" && echo "PASS  server loaded users file" || { echo "FAIL  users load log missing: $(cat $LOG)"; FAIL=1; }
chk "health public" "$(code $H/health)" "200"
chk "no auth -> 401" "$(code $H/keys)" "401"
chk "wrong password -> 401" "$(code -u $ALICE:WrongPass123 $H/keys)" "401"
chk "unknown user -> 401" "$(code -u ghost:SamePass123 $H/keys)" "401"
chk "malformed auth header -> 401" "$(code -H 'Authorization: Basic !!!notb64' $H/keys)" "401"
chk "right credentials -> 200" "$(code -u $ALICE:$APASS $H/keys)" "200"

# create/sign/verify with auth
K=$(curl -s -u $ALICE:$APASS -X POST -d '{"lifetime_seconds":600}' $H/keys | python3 -c 'import sys,json;print(json.load(sys.stdin)["key_id"])')
chk "create key with auth" "${#K}" "16"
M=$(printf 'hello-auth' | base64)
MSG="{\"message\":\"$M\"}"
SIG=$(curl -s -u $ALICE:$APASS -X POST -d "$MSG" $H/keys/$K/sign | python3 -c 'import sys,json;print(json.load(sys.stdin)["signature"])')
R=$(curl -s -u $ALICE:$APASS -X POST -d "{\"message\":\"$M\",\"signature\":\"$SIG\"}" $H/keys/$K/verify | python3 -c 'import sys,json;print(json.load(sys.stdin)["valid"])')
chk "sign+verify with auth" "$R" "True"
chk "sign without auth -> 401" "$(code -X POST -d "$MSG" $H/keys/$K/sign)" "401"

# ---------- reload without restart: add bob while server is running ----------
"$ADM" -f "$US" add bobuser "BobPass123" >/dev/null 2>&1
sleep 0.3
chk "new user works w/o restart (200)" "$(code -u bobuser:BobPass123 $H/keys)" "200"
grep -q "users reloaded" "$LOG" && echo "PASS  server auto-reloaded users file" || echo "note: users reloaded not logged (may have been quick)"

# ---------- remove + setpass ----------
"$ADM" -f "$US" remove "$ALICE" >/dev/null 2>&1
sleep 0.3
chk "removed user -> 401" "$(code -u $ALICE:$APASS $H/keys)" "401"
chk "other user still works" "$(code -u bobuser:BobPass123 $H/keys)" "200"
"$ADM" -f "$US" setpass bobuser "NewBobPass456" >/dev/null 2>&1
sleep 0.3
chk "old password -> 401" "$(code -u bobuser:BobPass123 $H/keys)" "401"
chk "new password -> 200" "$(code -u bobuser:NewBobPass456 $H/keys)" "200"

pkill -9 -f "bin/[m]ain 127.0.0.1 $P" 2>/dev/null
echo "RESULT: $([ $FAIL = 0 ] && echo ALL_PASS || echo HAS_FAILURES)"