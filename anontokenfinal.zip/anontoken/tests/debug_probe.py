import socket, time

s = socket.create_connection(("127.0.0.1", 9999), timeout=3)
s.sendall(b"GET /health HTTP/1.1\r\nHost: l\r\nConnection: close\r\n\r\n")
s.settimeout(1.5)
try:
    d = s.recv(65536)
    print("fast response:", d[:120])
except socket.timeout:
    print("no response yet - sending second packet")
    s.sendall(b"\n")
    s.settimeout(2)
    try:
        d = s.recv(65536)
        print("after second packet:", d[:120])
    except socket.timeout:
        print("still nothing")
s.close()