#!/usr/bin/env bash
# Full SPARK level-4 proof of every unit in the project (all SPARK_Mode => On).
cd /home/jovyan/work/anontoken || exit 1
export PATH=/home/jovyan/.local/share/alire/toolchains/gnat_native_16.1.0_9f74f58a/bin:/tmp/gp/gnatprove_16.1.0_82528bef/bin:/tmp/gp/gnatprove_16.1.0_82528bef/libexec/spark/bin:$PATH
LOG=/tmp/proof_v5.log
: > "$LOG"
for u in kms_os kms_file kms_server kms_base64 kms_hex kms_json \
         kms_keystore kms_signer kms_users kms_passwd kms_http; do
  echo "=== $u start $(date +%H:%M:%S) ===" >> "$LOG"
  timeout 7200 gnatprove -P anontoken.gpr --level=4 -j23 --report=all \
      --prover=z3,cvc5,altergo --timeout=120 --steps=400000 --no-inlining \
      -u "$u" >> "$LOG" 2>&1
  echo "rc=$? end $(date +%H:%M:%S)" >> "$LOG"
done
echo "=== ALL_DONE $(date +%H:%M:%S) ===" >> "$LOG"