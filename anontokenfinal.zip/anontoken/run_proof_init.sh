#!/usr/bin/env bash
# Re-prove the two Init units fresh after in out refactor.
export PATH=/home/jovyan/.local/share/alire/toolchains/gnat_native_16.1.0_9f74f58a/bin:/home/jovyan/.local/share/alire/toolchains/gprbuild_26.0.1_e3f27f25/bin:/tmp/gp/gnatprove_16.1.0_82528bef/bin:/tmp/gp/gnatprove_16.1.0_82528bef/libexec/spark/bin:$PATH
cd /home/jovyan/work/anontoken || exit 1
LOG=/tmp/p_init.log
: > "$LOG"
for u in kms_users kms_keystore kms_server; do
  echo "=== $u start $(date +%H:%M:%S) ===" >> "$LOG"
  timeout 3600 gnatprove -P anontoken.gpr --level=4 -j23 --report=all \
      --prover=z3,cvc5,altergo --timeout=120 --steps=400000 --no-inlining \
      -f -u "$u" >> "$LOG" 2>&1
  echo "rc=$? end $(date +%H:%M:%S)" >> "$LOG"
done
echo "=== ALL_DONE $(date +%H:%M:%S) ===" >> "$LOG"
